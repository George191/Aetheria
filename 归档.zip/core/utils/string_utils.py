"""
封装字符串相关函数:UUID字符串,字符串加密解密
"""
import uuid as UUID
import base64
from urllib.parse import urlparse, urlunparse


CHAR_SET = ("a", "b", "c", "d", "e", "f",
            "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s",
            "t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5",
            "6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I",
            "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V",
            "W", "X", "Y", "Z")


def uuid():
    """
    返回一个UUID对象
    :return:
    """
    return UUID.uuid4()


def uuid_36():
    """
    返回36字符的UUID字符串(十六进制,含有-)  bc5debab-95c3-4430-933f-2e3b6407ac30
    :return:
    """
    return str(UUID.uuid4())


def uuid_32():
    """
    返回32字符的UUID字符串(十六进制)  bc5debab95c34430933f2e3b6407ac30
    :return:
    """
    return uuid_36().replace('-', '')


def uuid_8():
    """
    返回8字符的UUID字符串(非进制)  3FNWjtlD
    :return:
    """
    s = uuid_32()
    result = ''
    for i in range(0, 8):
        sub = s[i * 4: i * 4 + 4]
        x = int(sub, 16)
        result += CHAR_SET[x % 0x3E]
    return result


def uuid_16():
    """
    返回16字符的UUID字符串(非进制)  3FNWjtlD3FNWjtlD
    :return:
    """
    return uuid_8() + uuid_8()


def bas64_encode_text(text):
    """
    base64加密字符串
    :param text:
    :return:
    """
    if isinstance(text, str):
        return str(base64.b64encode(text.encode('utf-8')), 'utf-8')
    return text


def bas64_decode_text(text):
    """
    base64解密字符串
    :param text:
    :return:
    """
    if isinstance(text, str):
        return str(base64.decodebytes(bytes(text, encoding="utf8")), 'utf-8')
    return text


def decode_text(text, crypto=""):
    """
    解密字符串
    :param text: 字符串
    :param crypto: 解密算法
    :return:
    """
    if crypto and crypto.lower() == 'base64':
        text = bas64_decode_text(text)
    return text


def encode_text(text, crypto=""):
    """
    加密字符串
    :param text: 字符串
    :param crypto: 加密算法
    :return:
    """
    if crypto and crypto.lower() == 'base64':
        text = bas64_encode_text(text)
    return text


# uri 隐藏
def mask_uri(uri, mask_char='*'):
    parsed_uri = urlparse(uri)
    masked_netloc = parsed_uri.netloc
    masked_path = mask_char * len(parsed_uri.path)
    masked_query = mask_char * len(parsed_uri.query)
    masked_fragment = mask_char * len(parsed_uri.fragment)
    
    masked_tuple = (
        parsed_uri.scheme,
        masked_netloc,
        masked_path,
        parsed_uri.params,
        masked_query,
        masked_fragment
    )
    
    masked_uri = urlunparse(masked_tuple)
    return masked_uri

# 部分隐藏
def partial_mask_string(string, start, end, mask_char='*'):
    masked_chars = mask_char * (end - start)
    return string[:start] + masked_chars + string[end:]

# 全部隐藏
def full_mask_string(string, mask_char='*'):
    return mask_char * len(string)

# 部分保留
def partial_reserve_string(string, start, end, mask_char='*'):
    reserved_chars = string[start:end]
    masked_chars = mask_char * (len(string) - (end - start))
    return reserved_chars + masked_chars

# 自定义掩码规则
def custom_mask_string(string, reserve_indices, mask_char='*'):
    masked_chars = [mask_char if i not in reserve_indices else string[i] for i in range(len(string))]
    return ''.join(masked_chars)

def mask_last_name(username, mask_char='*'):
    # 假设姓氏是由一个单词组成
    name_parts = username.split()
    first_name = name_parts[0]
    last_name = name_parts[-1]

    masked_last_name = mask_char * len(last_name)
    masked_username = first_name + " " + masked_last_name

    return masked_username

def mask_first_name(username, mask_char='*'):
    # 假设姓氏是由一个单词组成
    name_parts = username.split()
    first_name = name_parts[0]
    last_name = name_parts[-1]

    masked_first_name = mask_char * len(first_name)
    masked_username = masked_first_name + " " + last_name

    return masked_username

def mask_string(string, mask_ratio: float=.7, mask_char='*'):
    if mask_ratio <= 0 or mask_ratio >= 1 and string == '-1':
        return

    masked = str(string)
    mask_length = int(len(masked) * mask_ratio)

    if mask_length > 0:
        masked = masked[:len(masked) - mask_length] + mask_char * mask_length

    return masked


if __name__ == '__main__':

    phone_number = "13812345678"
    masked_phone_number = partial_mask_string(phone_number, 3, 7)
    print(masked_phone_number)  # 输出: 138****5678

    id_number = "320123198001010012"
    masked_id_number = full_mask_string(id_number)
    print(masked_id_number)  # 输出: ***************

    email = "example@example.com"
    masked_email = partial_reserve_string(email, 0, 3)
    print(masked_email)  # 输出: exa*********@example.com

    bank_card = "6222600123456789"
    reserved_indices = [0, 1, 2, 3, 12, 13, 14, 15]
    masked_bank_card = custom_mask_string(bank_card, reserved_indices)
    print(masked_bank_card)  # 输出: 6222********6789

    uri = "https://www.example.com/path?param1=value1&param2=value2#fragment"
    masked_uri = mask_uri(uri)
    print(masked_uri)

    username = "John B. Doe"
    masked_username = mask_last_name(username)
    print(masked_username)

    username = "John B. Doe"
    masked_username = mask_first_name(username)
    print(masked_username)

    number = 1234567890
    masked_number = mask_string(number)
    print(masked_number)
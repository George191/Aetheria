from consul import Consul


class ConsulUtils:
    
    def __init__(self, consul_host='localhost', consul_port=8500):
        self.consul = Consul(host=consul_host, port=consul_port)
    
    def register_service(self, service_name, service_id, address, port, tags=None, check_grpc=False):
        tags = tags or []
        check = None
        if check_grpc:
            check = {
                "name": f"gRPC check on {service_name}",
                "grpc": f"{address}:{port}",
                "interval": "10s",
                "timeout": "1s"
            }
        
        self.consul.agent.service.register(
            service_name,
            service_id=service_id,
            address=address,
            port=port,
            tags=tags,
            check=check
        )

    def deregister_service(self, service_id):
        self.consul.agent.service.deregister(service_id)
    
    def get_service_info(self, service_name):
        return self.consul.catalog.service(service_name)

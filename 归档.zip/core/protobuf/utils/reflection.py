

import datetime
from google.protobuf.internal.containers import (
    RepeatedScalarFieldContainer, RepeatedCompositeFieldContainer,
)
from google.protobuf.timestamp_pb2 import Timestamp


def assign_to_field(target_object, field_name, val):
    if val is None:
        return
    
    if not hasattr(target_object, field_name):
        raise ValueError(f'The argument {field_name} is not part of the {target_object} solver parameters!')
    else:
        tgt = getattr(target_object, field_name)

        if isinstance(tgt, (RepeatedScalarFieldContainer, list)):
            tgt.extend(val)

        elif isinstance(tgt, (RepeatedCompositeFieldContainer,)):
            tgt = tgt.add()
            tgt.CopyFrom(val)

        elif isinstance(tgt, (int, float, bool, str, bytes)):  # dict -> ScalarMap
            setattr(target_object, field_name, val)

        elif isinstance(tgt, Timestamp):
            if isinstance(val, datetime.date) and not isinstance(val, datetime.datetime):
                val = datetime.datetime(val.year, val.month, val.day)

            timestamp = Timestamp()
            timestamp.FromDatetime(val)
            tgt.CopyFrom(timestamp)

        else:
            raise RuntimeError("Unsupported type: {}".format(type(tgt)))
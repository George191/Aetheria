from collections.abc import Iterable as ABCIterable


def check_attributes(request, required_attributes):
        
    if not isinstance(required_attributes, ABCIterable):
        raise ValueError("required_attributes 必须是一个可迭代对象")
    
    if any(not isinstance(attr, str) for attr in required_attributes):
        raise ValueError("required_attributes 中所有元素必须是字符串")

    missing_attributes = [attr for attr in required_attributes if not hasattr(request, attr)]
    return missing_attributes
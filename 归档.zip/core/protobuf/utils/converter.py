from .reflection import assign_to_field


class ProtoModelConverter:

    def __init__(self, model_class, proto_class):
        self.model_class = model_class
        self.proto_class = proto_class

    def model_to_proto(self, model_instance):
        proto = self.proto_class()
        for field in self.proto_class.DESCRIPTOR.fields:
            if hasattr(model_instance, field.name):
                assign_to_field(proto, field.name, getattr(model_instance, field.name))
        return proto

    def proto_to_model(self, proto_instance):
        model_kwargs = {
            field.name: getattr(proto_instance, field.name)
            for field in self.proto_class.DESCRIPTOR.fields
        }
        return self.model_class(**model_kwargs)

import re
import yaml
import os
from core.logger import logger
from types import SimpleNamespace
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent


def to_simple_namespace(data):
    if isinstance(data, dict):
        for key, value in data.items():
            data[key] = to_simple_namespace(value)
        return SimpleNamespace(**data)
    return data


def read_yaml_config(file_path):
    if os.path.exists(file_path):
        with open(file_path, 'r') as file:
            data = yaml.safe_load(file) or {}
            return to_simple_namespace(data)
            
    return SimpleNamespace()


global_config = read_yaml_config(os.path.join(BASE_DIR, 'global_config.yaml'))

env_pattern = re.compile(r".*?\${(.*?)}.*?")


def load_config(config_path):
    global global_config
    local_config = read_yaml_config(config_path)

    global_config_dict = vars(global_config)

    environ = getattr(local_config, 'envs', SimpleNamespace())
    environ_dict = vars(environ)
    
    global_config_dict.update(environ_dict)

    for key, value in vars(global_config).items():
        if isinstance(value, int) or isinstance(value, float):
            value = str(value)
        for group in env_pattern.findall(value):
            env, default = group.split(':')
            value = value.replace(f"${{{group}}}", os.environ.get(env, default=default))
        os.environ[key] = value

    for key, value in vars(local_config).items():
        setattr(global_config, key, value)

    return global_config


def config_to_dict(ns):
    """
    递归地将 SimpleNamespace 对象转换为字典。
    """
    if isinstance(ns, SimpleNamespace):
        return {key: config_to_dict(value) for key, value in vars(ns).items()}
    elif isinstance(ns, dict):
        return {key: config_to_dict(value) for key, value in ns.items()}
    elif isinstance(ns, list):
        return [config_to_dict(value) for value in ns]
    else:
        return ns

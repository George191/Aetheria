from .simple import load_config as load_simple_config
from .simple import config_to_dict

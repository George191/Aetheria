import argparse
import asyncio
import os
import grpc
import sys
from grpc_reflection.v1alpha import reflection
from concurrent import futures
from core.config import load_simple_config, config_to_dict
from core.utils.module_loading import import_string
from core.utils.consul_utils import ConsulUtils
from core.logger import logger


sys.path.insert(0, os.path.abspath(os.path.curdir))


def parse_args():
    parser = argparse.ArgumentParser(description="Run the Aetheria gRPC microservice.")
    parser.add_argument(
        "--config", type=str, default="config.yaml", help="Path to the YAML configuration file."
    )
    return parser.parse_args()


def create_dependencies(dependencies):
    class_path = dependencies.service
    params = config_to_dict(dependencies.params)
    database_class = import_string(class_path)
    return database_class(**params)


async def setup_components(config) -> dict:
    components = {}
    if hasattr(config, 'components'):
        for name, component_info in vars(config.components).items():
            components[name] = create_dependencies(component_info)
    return components


class Orchestrator:

    def __init__(self, config_path) -> None:
        self.config = load_simple_config(config_path)
        self.address = self.config.grpc.address
        self.workers = self.config.grpc.workers
        self.consul_utils = ConsulUtils(
            consul_host=os.getenv('CONSUL_HOST', 'localhost'),
            consul_port=int(os.getenv('CONSUL_PORT', 8500)),
        )

    async def start(self):
        components = await setup_components(self.config)
        thread_pool = futures.ThreadPoolExecutor(max_workers=self.workers)
        server = grpc.aio.server(thread_pool)
        service_class = import_string(self.config.service)
        service_instance = service_class(**components)
        add_to_grpc_server = import_string(self.config.register_server)
        if add_to_grpc_server:
            add_to_grpc_server(service_instance, server)
        else:
            raise AttributeError(f"The service {add_to_grpc_server.__name__} does not have an add_to_server method.")

        reflection.enable_server_reflection(self.config.consul.service_name, server)

        server.add_insecure_port(self.address)

        # server_credentials: grpc.ServerCredentials = grpc.ssl_server_credentials(
        #     ((self.config.PRIVATE_KEY_PATH, self.config.CERTIFICATE_CHAIN_PATH),)
        # )
        # server.add_secure_port(self.address, server_credentials)
        
        address = self.config.grpc.address.split(':')

        # Register service with Consul
        self.consul_utils.register_service(
            service_name=self.config.consul.service_name,
            service_id=self.config.consul.service_id,
            address=''.join(address[:-1]),
            port=int(address[-1]),
            tags=['grpc'],
            check_grpc=False
        )

        await logger.info(f"Service {self.config.consul.service_name} registered with ID {self.config.consul.service_id}.")
        
        await server.start()
        await logger.info(f"The server {service_class.__name__} started at {self.address}")
        await server.wait_for_termination()
        
        self.consul_utils.deregister_service(self.config.CONSUL_SERVICE_ID)
        await logger.info(f"Service with ID {self.config.CONSUL_SERVICE_ID} deregistered.")



def main():
    args = parse_args()
    orch = Orchestrator(args.config)

    loop = asyncio.get_event_loop()
    loop.run_until_complete(orch.start())

if __name__ == '__main__':
    main()
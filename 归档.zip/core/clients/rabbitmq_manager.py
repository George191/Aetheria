import asyncio
import os
import aio_pika
from aio_pika.exceptions import ProbableAuthenticationError, ConnectionClosed
from core.logger import logger


class RabbitMQ:

    def __init__(self, max_retries=5, initial_retry_delay=1, max_retries_delay=60):
        self.url = os.environ.get('AMQP_URI', None)
        self.max_retries = max_retries
        self.initial_retry_delay = initial_retry_delay
        self.max_retries_delay = max_retries_delay
        self.connection = None
        self.channel = None
    
    async def connect(self):
        retry_count = 0
        while 1:
            try: 
                self.connection = await aio_pika.connect_robust(self.url, heartbeat=600)
                self.channel = await self.connection.channel()
                await self.channel.set_qos(prefetch_count=1)
                await logger.info('Successfully connected to RabbitMQ.')
                break
            except ProbableAuthenticationError as e:
                await logger.error(f"Authentication failed for RabbitMQ: {e}")
                raise
            except ConnectionClosed as e:
                await logger.error(f"Rabbit connection closed: {e}")
                raise
            except Exception as e:
                retry_count += 1
                await logger.error(f'Error connection to RabbitMQ: {e}, retrying ({retry_count})...')
                if retry_count >= self.max_retries:
                    await logger.error("Maximum retry attemptsr eached fro RabbitMQ connection.")
                    raise
                await asyncio.sleep(min(self.initial_retry_delay * 2 ** retry_count, self.max_retries_delay))

    async def create_exchange(self, exchange_name, exchange_type='direct'):
        try:
            if not self.channel: 
                await self.connect()
            await self.channel.declare_exchange(exchange_name, exchange_type=exchange_type, durable=True)            
        except Exception as e:
            await logger.error(f"Failed to declare exchange: {e}")
            raise

    async def create_queue(self, req_queue_name, rep_queue_name=None, exchange_name=None):
        try:
            if not self.channel: 
                await self.connect()
            await self.channel.declare_queue(req_queue_name, durable=True)
            if rep_queue_name:
                await self.channel.declare_queue(rep_queue_name, durable=True)
            if exchange_name:
                await self.create_exchange(exchange_name)
        except Exception as e:
            logger.error(f"Failed to declare queues: {e}")
            raise

    async def publish(self, message, exchange_name, routing_key):
        try:
            if not self.channel:
                await self.connect()

            exchange = await self.channel.get_exchange(exchange_name)
            await exchange.publish(aio_pika.Message(body=message.encode()), routing_key)
            await logger.info(f"Message published to {exchange_name} with routing_key {routing_key}.")
        except Exception as e:
            await logger.error(f"Error publishing message to RabbitMQ: {e}")
            raise

    async def consume(self, queue_name):
        queue = await self.channel.declare_queue(queue_name, durable=True)
        await queue.consume(callable, no_ack=True)
        await logger.info(f"Consumer set for queue {queue_name}")
    
    async def close(self):
        try:
            if self.channel:
                await self.channel.close()
            if self.connection:
                await self.connection.close()
            await logger.info("RabbitMQ connection closed.")
        except Exception as e:
            await logger.error(f"Error closing RabbitMQ connection: {e}")
            
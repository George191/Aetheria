import asyncio
import os
import aioredis
from string import Template

import aioredis.connection
from core.logger import logger


class RedisPoolManager:
        
    _instance = None
    _lock = asyncio.Lock()

    def __init__(self):


        self.max_retries = int(os.getenv('CONNECTION_MAX_RETRIES', 5))
        self.retry_delay = int(os.getenv('CONNECTION_RETRY_DELAY', 1))
        self.max_retries_delay = int(os.getenv('CONNECTION_RETRIES_DELAY', 60))
        self.pools: dict[str, aioredis.ConnectionPool] = {}  # 存储不同数据库的连接池

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super().__new__(cls)
            cls._instance.initialized = False
        return cls._instance
    
    async def _create_pool(self, database: str):
        redis_url_template = os.getenv("REDIS_URI", None)
        template = Template(redis_url_template)
        redis_url = template.safe_substitute(
            REDIS_USER=os.getenv("REDIS_USER", ""),
            REDIS_PASSWORD=os.getenv("REDIS_PASSWORD", ""),
            REDIS_HOST=os.getenv("REDIS_HOST", "localhost"),
            REDIS_PORT=os.getenv("REDIS_PORT", "6379")
        )
        redis_url += database
        if redis_url not in self.pools:
            connection_pool = aioredis.ConnectionPool.from_url(redis_url, decode_responses=True)
            self.pools[redis_url] = connection_pool
            await logger.info(f"Redis connection pool [{database}] created.", include=redis_url)

        return self.pools[redis_url]

    async def connect(self, database: str) -> 'aioredis.Redis':
        async with self._lock:
            pool_key = f"{database}"
            if pool_key in self.pools:
                return self.pools[pool_key]
            retry_count = 0
            while 1:
                try:
                    connection_pool = await self._create_pool(database)
                    return aioredis.Redis(connection_pool=connection_pool)
                except Exception as e:
                    retry_count += 1
                    await logger.error(f"Redis connection attempt {retry_count} failed: {e}", include=database)
                    if retry_count >= self.max_retries:
                        raise ConnectionError("Maximum retry attempts reached for database connection.")
                    await asyncio.sleep(min(self.retry_delay * 2 ** retry_count, self.max_retries_delay))

    async def close(self):
        for key, pool in self.pools.items():
            await pool.release()
            await logger.debug(f"Redis connection pool [{key}] was closed.")

    async def set_hash_value(self, name, key, value, database: str = '0'):
        meanings = await self.connect(database)
        try:
            await meanings.hset(name, key, value)
        except Exception as e:
            raise ValueError(f"Error setting value in Redis: {e}")
        
    async def set_hash_mapping(self, name, database: str = '0', **kwargs):
        meanings = await self.connect(database)
        try:
            await meanings.hset(name, mapping=kwargs)
        except Exception as e:
            raise ValueError(f"Error setting value in Redis: {e}")

    async def get_hash_value(self, name, key, database: str = '0'):
        meanings = await self.connect(database)
        try: 
            return await meanings.hget(name, key)
        except Exception as e:
            raise ValueError(f"Error getting value in Redis: {e}")
        
    async def exists(self, *name, database: str = '0'):
        meanings = await self.connect(database)
        try: 
            return await meanings.exists(*name)
        except Exception as e:
            raise ValueError(f"Error checking key existence: {e}")
        
    async def get_hash_mapping(self, name, database: str = '0'):
        meanings = await self.connect(database)
        try: 
            return await meanings.hgetall(name)
        except Exception as e:
            raise ValueError(f"Error getting value in Redis: {e}")
        
    async def delete_hash_value(self, name, *keys, database: str = '0'):
        meanings = await self.connect(database)
        try: 
            return await meanings.hdel(name, *keys)
        except Exception as e:
            raise ValueError(f"Error getting value in Redis: {e}")

    async def delete_value(self, *names, database: str = '0'):
        meanings = await self.connect(database)
        try: 
            return await meanings.delete(*names)
        except Exception as e:
            raise ValueError(f"Error getting value in Redis: {e}")

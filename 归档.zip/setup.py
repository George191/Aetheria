from setuptools import setup, find_packages

setup(
    name="aetheria_core",
    version="0.1.0.0",
    description="Shared library",
    author="凡卿",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        'core.config': ['global_config.yaml'],
        'core.proto': ['*.proto'],
        'core.cert': ['*.crt', '*.key'],
    },
    entry_points={
        "console_scripts": [
            "orchestrator=core.cli.orchestrator:main"
        ]
    },
    install_requires=[
        "urllib3==1.25.4",
        "protobuf==4.25.1", 
        "aio-pika==9.3.1",
        "aioredis==2.0.1",
        "pyyaml==6.0.1",
        "aiologger==0.7.0",
        "structlog==23.3.0",
        "python-logstash==0.4.8",
        "grpcio==1.60.0",
        "grpcio-tools==1.60.0",
        "grpcio-reflection==1.60",
        "python-consul==1.1.0"
    ],
    extras_require={
        'dev': [
            
        ],
    },
    zip_safe=True,
    classifiers=[
        'Environment :: Mirco Service Clusters Environment',
        'Framework :: Aetheria',
        'Framework :: Aetheria :: 0.1.0.0',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: BSD License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.9',
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Internet :: WWW/HTTP :: Dynamic Content',
    ],
)

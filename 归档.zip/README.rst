docker run -d --name consul --network aetheria-network -p 8500:8500 \
  -e CONSUL_BIND_INTERFACE=eth0 \
  consul:1.15.4
..   -v /path/to/consul/data:/consul/data \
..   -v /path/to/consul/config:/consul/config \
from typing import AsyncGenerator
from core.protobuf.message.nimbus import nimbus_pb2_grpc
from middleware import Middleware


class NimbusMiddleware(Middleware):

    def __init__(self, service_name: str = 'nimbus-service') -> None:
        super().__init__(service_name=service_name)
        self.stub = nimbus_pb2_grpc.NimbusServiceStub(self.channel)
        
    async def file_download(self, request_iterator: AsyncGenerator):
        async for request in request_iterator:
            yield self.stub.download_file(request)

    async def download_pause(self, request_iterator: AsyncGenerator):
        async for request in request_iterator:
            yield self.stub.download_pause(request)

    async def download_resume(self, request_iterator: AsyncGenerator):
        async for request in request_iterator:
            yield self.stub.download_resume(request)
    
    async def download_cancel(self, request_iterator: AsyncGenerator):
        async for request in request_iterator:
            yield self.stub.download_cancel(request)

    async def upload_file(self, request_iterator: AsyncGenerator):
        yield self.stub.upload_file(request_iterator)

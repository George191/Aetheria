from importlib import import_module
from os import environ
from google.protobuf.message import Message
from google.protobuf.json_format import MessageToDict
from grpc._channel import _InactiveRpcError
from grpc.aio._call import UnaryStreamCall, StreamStreamCall, UnaryUnaryCall, StreamUnaryCall
from grpc._cython.cygrpc import _MessageReceiver
from grpc import ServicerContext, StatusCode
from core.clients import RedisPoolManager
from core.logger import logger
from core.protobuf.utils.reflection import assign_to_field
from core.protobuf.message.gateway import gateway_pb2, gateway_pb2_grpc
from asyncio import Queue
from utils.async_iterator import AsyncQueueIterator


initial_request = {
    'file_download': 'FileDownloadRequest',
    'download_pause': 'TransferControlRequest',
    'download_resume': 'TransferControlRequest',
    'download_cancel': 'TransferControlRequest',
    'upload_file': 'FileUploadRequest',
}

initial_response = {
    'file_download': 'FileDownloadResponse',
    'download_pause': 'TransferControlResponse',
    'download_resume': 'FileDownloadResponse',
    'download_cancel': 'TransferControlResponse',
    'upload_file': 'FileUploadResponse',
}

initial_service = {
    'file_download': 'nimbus',
    'download_pause': 'nimbus',
    'download_resume': 'nimbus',
    'download_cancel': 'nimbus',
    'upload_file': 'nimbus',
}

initial_whitelist = {
    'file_download': True,
    'download_pause': True,
    'download_resume': True,
    'download_cancel': True,
    'upload_file': True,
}

class GatewayServiceServicer(gateway_pb2_grpc.GatewayServiceServicer):

    def __init__(self) -> None:
        self.redis_client = RedisPoolManager()
        self.database = environ['redis_index']

    @staticmethod
    async def attrs_to_serv_reqs(attrs_iterator: 'AsyncQueueIterator', serv_reqs: Message):
        async for attrs in attrs_iterator:
            if (
                attrs.Is(serv_reqs.DESCRIPTOR) and 
                attrs.Unpack(serv_reqs)
            ):
                yield serv_reqs

    @staticmethod
    def create_gateway_response(gateway_response: gateway_pb2.GatewayResponse, serv_resp: Message):

        if serv_resp.HasField('success'):
            gateway_response.success.Pack(serv_resp)
            
        elif serv_resp.HasField('error'):
            for key, value in serv_resp.error.ListFields():
                assign_to_field(gateway_response.error, key.name, value)

    async def validate_params(self, serv: str, host: str, gateway_response: gateway_pb2.GatewayResponse, status_response: gateway_pb2.StatusResponse) -> gateway_pb2.GatewayResponse:
        
        if not serv:
            status_response.grpc_status = StatusCode.INVALID_ARGUMENT.value[0]
            status_response.server_code = 500
            status_response.message = 'Error!, Unknown or Missing required field service!'
            gateway_response.error.CopyFrom(status_response)
            await logger.error(MessageToDict(gateway_response))
            return gateway_response
        
        elif not host:
            status_response.grpc_status = StatusCode.INVALID_ARGUMENT.value[0]
            status_response.server_code = 500
            status_response.message = 'Error!, Unknown or Missing required field host!'
            gateway_response.error.CopyFrom(status_response)
            await logger.error(MessageToDict(gateway_response))
            return gateway_response
        
        elif not (initial_whitelist[serv] or await self.redis_client.get_hash_value(name='ip_address', key=host, database=self.database)):
            status_response.grpc_status = StatusCode.PERMISSION_DENIED.value[0]
            status_response.server_code = 405
            status_response.message = f'Error!, Host - {host} - Service - {serv} - is not allowed!'
            gateway_response.error.CopyFrom(status_response)
            await logger.error(MessageToDict(gateway_response))
            return gateway_response
        
        return True

    async def forward_message(self, request_iterator: _MessageReceiver, context: ServicerContext):    
        
        serv, host, serv_n, serv_mw = '', '', '', ''

        gateway_response = gateway_pb2.GatewayResponse()
        status_response = gateway_pb2.StatusResponse()

        attrs_queue = Queue()

        async for request in request_iterator:
            if getattr(request, 'service'):
                serv = request.service
                serv_n = initial_service[serv]
                serv_mw = serv_n.capitalize() + 'Middleware'

            elif getattr(request, 'host'):
                host = request.host
            
            elif getattr(request, 'attrs') and request.attrs.ByteSize() > 0:
                await attrs_queue.put(request.attrs)

        flag = await self.validate_params(serv, host, gateway_response, status_response)
        if flag is gateway_response:
            yield flag
            return

        gateway_response.service = serv

        mw_pkg = import_module('third_party', package='.')
        mw_cls = getattr(mw_pkg, serv_mw)()

        pb2pkg = import_module(f'.{serv_n}_pb2', package=f'core.protobuf.message.{serv_n}')
        serv_reqs = getattr(pb2pkg, initial_request[serv])()
        
        async_iterator = AsyncQueueIterator(attrs_queue)

        serv_reqs_async_iterator = self.attrs_to_serv_reqs(async_iterator, serv_reqs)
        
        try:
            mv_resp_p = getattr(mw_cls, serv)(serv_reqs_async_iterator)
            await logger.info(f'Gateway request for {host} has been forwarded to middleware successfully! - {serv_n}: {serv}')

            async for middleware_response in mv_resp_p:

                if isinstance(middleware_response, (UnaryStreamCall, StreamStreamCall, StreamUnaryCall)):
                    async for serv_resp in middleware_response:
                        self.create_gateway_response(gateway_response, serv_resp)
                        yield gateway_response
                        if serv_resp.HasField('error'):
                            return
                    
                elif isinstance(middleware_response, UnaryUnaryCall):
                    serv_resp = await middleware_response._invoke()
                    self.create_gateway_response(gateway_response, serv_resp)
                    yield gateway_response
                    if serv_resp.HasField('error'):
                        return

            await logger.info(f'Gateway response for {host} has been sent successfully! - {serv_n}: {serv}')
            return

        except _InactiveRpcError as e:
            status_response.grpc_status = StatusCode.INVALID_ARGUMENT.value[0]
            status_response.server_code = 500
            status_response.message = e.details()
            gateway_response.error.CopyFrom(status_response)
            yield gateway_response
            await logger.error(MessageToDict(gateway_response))
            return
        


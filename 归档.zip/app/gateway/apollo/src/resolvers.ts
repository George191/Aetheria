import { getLogger } from "log4js";
import { client } from "./clients";
import { PubSub } from 'graphql-subscriptions';


const logger = getLogger("gateway-resolvers");
logger.level = "debug";

const resolvers = {
    Query: {
        hello: async () => {
            const call = client.streamData()
            call.on('data', (response: any) => {
                console.log(`Received response: ${response}`)
            });
            call.on('end', () => {
                console.log('Stream ended.')
                resolvers('gRPC stream ended.')
            };
            call.on('error', (error: any) => {
                console.log(error)
                reject(error)
            };
            call.write({
                message: "Hello from Apollo Gateway!"
            });
            call.end()
        },
    },
    Subscription: {
        downloadFile: {
            subscribe: async (filePath: string, context: any, info: any) => {
                console.log("filePath", filePath)
            }
        }
    }
}

export { resolvers }
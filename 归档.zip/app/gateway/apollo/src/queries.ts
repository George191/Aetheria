const nimbusQueries = `\
subscription {
    downloadFile (file_path: "") {
        transfer_id,
        response {
            ... on SuccessFileDownloadResponse {
                file_path
                chunk
                transferred_bytes
                total_bytes
                status
            }
            ... on StatusResponse {
                grpc_status
                server_code
                message
            }
        }
    }
}
`

const Queries = (graphqlPath: string) => {
    return [{
        endpoint: graphqlPath,
        name: 'nimbusQueries',
        query: nimbusQueries
    }]
}

export { Queries }
import express from 'express';
import { ApolloServer } from 'apollo-server-express';
import { makeExecutableSchema } from '@graphql-tools/schema';
import { getLogger } from 'log4js'
import { typeDefs } from './schema'
import { resolvers } from './resolvers'
import { Queries } from './queries'
import http from 'http';
import { useServer } from 'graphql-ws/lib/use/ws';
import { WebSocketServer } from 'ws';
import * as playground from 'graphql-playground-middleware-express'
import { express as voyagerMiddleware } from 'graphql-voyager/middleware'
import { ApolloServerPluginLandingPageGraphQLPlayground } from 'apollo-server-core';
import { ApolloServerPluginUsageReportingDisabled } from 'apollo-server-core';
import { ApolloServerPluginInlineTrace } from 'apollo-server-core';


const logger = getLogger('Nimbus')
logger.level = 'debug'

const PORT = 4000
const GRAPHQL_PATH = '/graphql'
const PLAYGROUND_PATH = '/playground'
const VOYAGER_PATH = '/voyager'
const app = express()

app.get(
  PLAYGROUND_PATH,
  playground.default({
    endpoint: GRAPHQL_PATH,
    subscriptionEndpoint: GRAPHQL_PATH,
    tabs: Queries(GRAPHQL_PATH)
  })
)

app.use(VOYAGER_PATH, voyagerMiddleware({ endpointUrl: GRAPHQL_PATH }))

async function startApolloServer( app: any ): Promise<void> {
  const schema = makeExecutableSchema({ typeDefs, resolvers });

  const server = new ApolloServer({
    schema,
    introspection: true, // Enable introspection for the Playground
    plugins: [
      ApolloServerPluginLandingPageGraphQLPlayground(),
      ApolloServerPluginUsageReportingDisabled(),
      ApolloServerPluginInlineTrace(),
    ]
  });

  await server.start();

  server.applyMiddleware({ app, path: GRAPHQL_PATH });

  const httpServer = http.createServer(app);

  const wsServer = new WebSocketServer({
    server: httpServer,
    path: GRAPHQL_PATH,
  });

  useServer(
    {
      schema,
      onConnect: (ctx: any) => {
        logger.info('WebSocket connection established.');
      },
      onDisconnect: (ctx: any) => {
        logger.info('WebSocket connection closed.');
      },
    },
    wsServer
  );

  httpServer.listen({ port: PORT }, () => {
    logger.info(`
      🚀
      Server ready at http://localhost:${PORT}${GRAPHQL_PATH}
      Access playground with query examples at http://localhost:${PORT}${PLAYGROUND_PATH}
      WebSocket server ready at ws://localhost:${PORT}${GRAPHQL_PATH}
      🤘
    `);
  });
}

startApolloServer(app);
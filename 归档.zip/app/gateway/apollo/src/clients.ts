import grpc from '@grpc/grpc-js'
import * as protoLoader from '@grpc/proto-loader'

const GATEWAY_SERVICE = process.env.GATEWAY_SERVICE || 'localhost:50051'

const NIMBUS_PROTO_PATH = process.env.NIMBUS_PROTO_PATH || `${__dirname}../../../../../core/proto/nimbus.proto`

const nimbusPackageDefinition = protoLoader.loadSync(NIMBUS_PROTO_PATH, {
    keepCase: true,
    longs: String,
    enums: String,
    defaults: true,
    oneofs: true
})

const protoDescriptor: any = grpc.loadPackageDefinition(nimbusPackageDefinition)

const BiDiStreamService = new protoDescriptor.v1.GatewayService

const client = new BiDiStreamService(GATEWAY_SERVICE, grpc.credentials.createInsecure())

export { client }
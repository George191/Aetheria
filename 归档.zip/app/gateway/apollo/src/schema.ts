import { gql } from 'apollo-server'

const typeDefs = gql`
    enum TransferStatus {
        PENDING
        IN_PROGRESS
        SUCCESS
        FAILED
        PAUSED
        CANCELLED
    }

    type SuccessFileDownloadResponse {
        filePath: String!
        chunk: String! # Base64 encoded string
        transferredBytes: Float!
        totalBytes: Float!
        status: TransferStatus!
    }

    type StatusResponse {
        grpcStatus: Int!
        serverCode: Int!
        message: String!
    }

    union FileDownloadResponseUnion = SuccessFileDownloadResponse | StatusResponse

    type FileDownloadResponse {
        response: FileDownloadResponseUnion!
        transferId: String!
    }

    type Subscription {
        downloadFile(filePath: String!): FileDownloadResponse!
    }
    type Query {
        hello: String!
    }

    schema {
        query: Query
        subscription: Subscription
    }
`

export { typeDefs }
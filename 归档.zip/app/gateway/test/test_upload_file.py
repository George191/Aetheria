import hashlib
import os
from pathlib import Path
import sys
import time
from typing import AsyncGenerator, Generator, Any
import uuid


Basedir = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, os.path.abspath(Basedir))

import aiofiles
import grpc
from core.protobuf.message.gateway import gateway_pb2
from core.protobuf.message.gateway import gateway_pb2_grpc

from core.protobuf.message.nimbus import nimbus_pb2
from google.protobuf.any_pb2 import Any

import asyncio


async def file_request_iterator(local_path, file_name, file_path, bucket_name, chunk_size=128 * 1024):
    gateway_request = gateway_pb2.GatewayRequest()

    yield gateway_pb2.GatewayRequest(service='upload_file')
    yield gateway_pb2.GatewayRequest(host='8.218.206.243')

    def yield_request(attrs):
        request = gateway_request
        any_message = Any()
        any_message.Pack(attrs)
        request.attrs.CopyFrom(any_message)
        return request

    # Pack and yield file name
    yield yield_request(nimbus_pb2.FileUploadRequest(file_name=file_name))
    # Pack and yield file path
    yield yield_request(nimbus_pb2.FileUploadRequest(file_path=file_path))
    # Pack and yield bucket name
    yield yield_request(nimbus_pb2.FileUploadRequest(bucket_name=bucket_name))
    # Pack and yield file chunks
    try:
        async with aiofiles.open(local_path, "rb") as fp:
            while True:
                data = await fp.read(chunk_size)
                if not data:
                    break
                yield yield_request(nimbus_pb2.FileUploadRequest(file_chunk=data))

    except FileNotFoundError as e:
        print(f"File not found: {e}")


def generate_secret_file_name(file_name: str) -> str:
    timestamp = str(time.time()).encode('utf-8')
    original_name = file_name.encode('utf-8')
    hash_object = hashlib.sha256(timestamp + original_name)
    secret = hash_object.hexdigest()[:16]  # 取前16个字符
    file_extension = os.path.splitext(file_name)[1]
    return f"{secret}{file_extension}"


async def test_upload_file():
    channel = grpc.aio.insecure_channel('127.0.0.1:50050')
    stub = gateway_pb2_grpc.GatewayServiceStub(channel)
    
    status_response = gateway_pb2.StatusResponse()
    status_response.server_code = 500

    try:
        local_path = '/Users/george/Desktop/ChatGPT_Desktop_public_latest.dmg'
        file_name = generate_secret_file_name('ChatGPT_Desktop_public_latest.dmg')
        file_path = os.path.join('profile/dmg/zhangsan', file_name)

        file_size = os.path.getsize(local_path)

        bucket_name = 'public'

        file_upload_response = nimbus_pb2.FileUploadResponse()

        request_iterator = file_request_iterator(local_path=local_path, file_path=file_path, file_name=file_name, bucket_name=bucket_name)

        async for response in stub.forward_message(request_iterator):
            if response.HasField('success'):
                response.success.Unpack(file_upload_response)
                print(f"{response.service}: {file_upload_response.transfer_id} - {file_upload_response.success.file_name} - {file_upload_response.success.status} - Transferred_bytes: {file_upload_response.success.transferred_bytes} - Total_bytes: {file_size}")
            elif response.HasField('error'):
                print(f'{response.service}: {file_upload_response.transfer_id} - {response.error.grpc_status}, error_code: {response.error.server_code}, message: {response.error.message}')
    
    except grpc.aio.AioRpcError as e:  # 捕获异步gRPC调用的错误
        print(f'gRPC call failed: {e._details}')
        status_response.message = e._details
        status_response.grpc_status = e._code.value[0]


def main():
    asyncio.run(test_upload_file())
    
if __name__ == '__main__':
    main()


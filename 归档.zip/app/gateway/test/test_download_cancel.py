import os
from pathlib import Path
import sys


Basedir = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, os.path.abspath(Basedir))

import grpc
from core.protobuf.message.gateway import gateway_pb2
from core.protobuf.message.gateway import gateway_pb2_grpc

from core.protobuf.message.nimbus import nimbus_pb2
import asyncio


async def test_download_pause():
    channel = grpc.aio.insecure_channel('127.0.0.1:50050')
    stub = gateway_pb2_grpc.GatewayServiceStub(channel)
    
    StatusResponse = gateway_pb2.StatusResponse()
    StatusResponse.server_code = 500

    GatewayRequest = gateway_pb2.GatewayRequest()
    GatewayRequest.service = "download_cancel"
    GatewayRequest.host = '8.218.206.243'

    try:
        # 替换为一个有效的文件路径
        attrs = {
            "transfer_id": "AHm6NnjUisigGq5S"
        }

        TransferControlRequest = nimbus_pb2.TransferControlRequest()
        SuccessTransferControlResponse = nimbus_pb2.SuccessTransferControlResponse()

        for key, value in attrs.items():
            if isinstance(value, list):
                exec(f"TransferControlRequest.{key}.extend(value)")
            else:
                setattr(TransferControlRequest, key, value)

        GatewayRequest.attrs.Pack(TransferControlRequest)

        async for response in stub.forward_message((GatewayRequest,)):
            if response.HasField('success'):
                response.success.Unpack(SuccessTransferControlResponse)
                print(f"{response.service}: Message: {SuccessTransferControlResponse.message}, Status: {SuccessTransferControlResponse.status}")
            elif response.HasField('error'):
                print(f'{response.service}: Error: grpc_status: {response.error.grpc_status}, error_code: {response.error.server_code}, message: {response.error.message}')
    
    except grpc.aio.AioRpcError as e:  # 捕获异步gRPC调用的错误
        print(f'gRPC call failed: {e._details}')
        StatusResponse.message = e._details
        StatusResponse.grpc_status = e._code.value[0]    


def main():
    asyncio.run(test_download_pause())
    
if __name__ == '__main__':
    main()
    
import os
from pathlib import Path
import sys


Basedir = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, os.path.abspath(Basedir))

import grpc
from core.protobuf.message.gateway import gateway_pb2
from core.protobuf.message.gateway import gateway_pb2_grpc
from core.protobuf.utils.reflection import assign_to_field
from core.protobuf.message.nimbus import nimbus_pb2
from google.protobuf.any_pb2 import Any

import asyncio


async def file_request_iterator(service: str, host: str, attrs: dict):

    yield gateway_pb2.GatewayRequest(service=service)
    yield gateway_pb2.GatewayRequest(host=host)

    FileDownloadRequest = nimbus_pb2.FileDownloadRequest()

    for key, value in attrs.items():
        assign_to_field(FileDownloadRequest, key, value)


    any_message = Any()
    any_message.Pack(FileDownloadRequest)

    gateway_request_attrs = gateway_pb2.GatewayRequest()
    gateway_request_attrs.attrs.CopyFrom(any_message)

    yield gateway_request_attrs



async def test_download_file():
    channel = grpc.aio.insecure_channel('127.0.0.1:50050')
    stub = gateway_pb2_grpc.GatewayServiceStub(channel)
    
    StatusResponse = gateway_pb2.StatusResponse()
    StatusResponse.server_code = 500

    try:
        
        attrs = {
            "file_path": "public/profile/avatar/zhangsan/15dd5b463ad240ad8b2ff00efb17b377.csv"
        }
        SuccessFileDownloadResponse = nimbus_pb2.SuccessFileDownloadResponse()

        request_iterator = file_request_iterator("file_download", "8.218.206.243", attrs)

        async for response in stub.forward_message(request_iterator):
            if response.HasField('success'):
                response.success.Unpack(SuccessFileDownloadResponse)
                print(f"{response.service}: File_path Chunk received: {len(SuccessFileDownloadResponse.chunk)} bytes, Transferred_bytes: {SuccessFileDownloadResponse.transferred_bytes}, Status: {SuccessFileDownloadResponse.status}")
            elif response.HasField('error'):
                response.error.Unpack(StatusResponse)
                print(f'{response.service}: Error: grpc_status: {StatusResponse.grpc_status}, error_code: {StatusResponse.server_code}, message: {StatusResponse.message}')
    
    except grpc.aio.AioRpcError as e:  # 捕获异步gRPC调用的错误
        print(f'gRPC call failed: {e._details}')
        StatusResponse.message = e._details
        StatusResponse.grpc_status = e._code.value[0]


def main():
    asyncio.run(test_download_file())

if __name__ == '__main__':
    main()
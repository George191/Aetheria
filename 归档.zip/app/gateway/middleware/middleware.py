import grpc
from core.utils.consul_utils import ConsulUtils
import os


class Middleware:

    def __init__(self, service_name: str) -> None:
        self.service_name = service_name
        self.consul = ConsulUtils(
            consul_host=os.getenv('CONSUL_HOST', 'localhost'),
            consul_port=os.getenv('CONSUL_PORT', 8500),
        )

    @property
    def service_info(self) -> None:
        return self.consul.get_service_info(service_name=self.service_name)
    
    @property
    def interceptors(self): 
        return []

    @property
    def channel(self):
        _, service_info = self.service_info
        ip_address = service_info[0]['ServiceAddress']
        port = service_info[0]['ServicePort']
        interceptors = self.interceptors
        return grpc.aio.insecure_channel(f"{ip_address}:{port}", interceptors=interceptors)
import grpc
import asyncio

from core.protobuf.message.nimbus import nimbus_pb2
from core.protobuf.message.nimbus import nimbus_pb2_grpc


async def download_pause(transfer_id: str):

    channel = grpc.aio.insecure_channel('[::]:50051')
    stub = nimbus_pb2_grpc.NimbusServiceStub(channel)

    TransferControlResponse = nimbus_pb2.TransferControlResponse()
    StatusResponse = nimbus_pb2.StatusResponse()
    StatusResponse.grpc_status = grpc.StatusCode.INTERNAL.value[0]
    StatusResponse.server_code = 500

    if not transfer_id:
        StatusResponse.message = "transfer_id is required!"
    else:
        try:
            TransferControlRequest = nimbus_pb2.TransferControlRequest(transfer_id=transfer_id)
            return await stub.download_pause(TransferControlRequest)

        except grpc.aio.AioRpcError as e:  # 捕获异步gRPC调用的错误
            StatusResponse.message = e.details()

    TransferControlResponse.error.CopyFrom(StatusResponse)
    return TransferControlResponse
    

def main(transfer_id: str):
    app = download_pause(transfer_id=transfer_id)
    asyncio.run(app)
    
if __name__ == '__main__':
    main()


import grpc
from core.protobuf.message.nimbus import nimbus_pb2
from core.protobuf.message.nimbus import nimbus_pb2_grpc
import asyncio


async def download_resume(transfer_id: str):
    channel = grpc.aio.insecure_channel('[::]:50051')
    stub = nimbus_pb2_grpc.NimbusServiceStub(channel)
    
    StatusResponse = nimbus_pb2.StatusResponse()
    StatusResponse.grpc_status = grpc.StatusCode.INTERNAL.value[0]
    StatusResponse.server_code = 500

    if not transfer_id:
        StatusResponse.message = "transfer_id is required!"
        
    else:
        try:
            TransferControlRequest = nimbus_pb2.TransferControlRequest(transfer_id=transfer_id)
            async for response in stub.download_resume(TransferControlRequest):
                yield response
        
        except grpc.aio.AioRpcError as e:  # 捕获异步gRPC调用的错误
            StatusResponse.message = e.details()

    FileDownloadResponse = nimbus_pb2.FileDownloadResponse()
    FileDownloadResponse.transfer_id = "-1"
    FileDownloadResponse.error.CopyFrom(StatusResponse)
    yield FileDownloadResponse
    return


def main(transfer_id: str):
    app = download_resume(transfer_id)
    asyncio.run(app)


if __name__ == '__main__':
    main()
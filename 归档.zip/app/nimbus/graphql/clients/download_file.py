from core.protobuf.message.nimbus import nimbus_pb2
from core.protobuf.message.nimbus import nimbus_pb2_grpc
import asyncio
import grpc


async def download_file(file_path: str):
    channel = grpc.aio.insecure_channel('[::]:50051')
    stub = nimbus_pb2_grpc.NimbusServiceStub(channel)
    
    StatusResponse = nimbus_pb2.StatusResponse()
    StatusResponse.grpc_status = grpc.StatusCode.INTERNAL.value[0]
    StatusResponse.server_code = 500

    if not file_path:
        StatusResponse.message = "file_path is required!"

    else:
        try:
            download_request = nimbus_pb2.FileDownloadRequest(file_path=file_path)
            async for response in stub.download_file(download_request):
                yield response
        
        except grpc.aio.AioRpcError as e:  # 捕获异步gRPC调用的错误
            StatusResponse.message = e.details()

    FileDownloadResponse = nimbus_pb2.FileDownloadResponse()
    FileDownloadResponse.transfer_id = "-1"
    FileDownloadResponse.error.CopyFrom(StatusResponse)
    yield FileDownloadResponse
    return
    

def main(file_path: str):
    app = download_file(file_path)
    asyncio.run(app)


if __name__ == '__main__':
    main()
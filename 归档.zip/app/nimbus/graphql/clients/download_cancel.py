import grpc
import asyncio

from core.protobuf.message.nimbus import nimbus_pb2
from core.protobuf.message.nimbus import nimbus_pb2_grpc


async def download_cancel(transfer_id: str):

    channel = grpc.aio.insecure_channel('[::]:50051')
    stub = nimbus_pb2_grpc.NimbusServiceStub(channel)

    transfer_control_response = nimbus_pb2.TransferControlResponse()
    status_response = nimbus_pb2.StatusResponse()
    status_response.grpc_status = grpc.StatusCode.INTERNAL.value[0]
    status_response.server_code = 500
    if not transfer_id:
        status_response.message = "transfer_id is required!"

    else:
        try:
            transfer_control_request = nimbus_pb2.TransferControlRequest(transfer_id=transfer_id)
            return await stub.download_cancel(transfer_control_request)

        except grpc.aio.AioRpcError as e:  # 捕获异步gRPC调用的错误
            status_response.message = e.details()

    transfer_control_response.error.CopyFrom(status_response)
    return transfer_control_response
    

def main(transfer_id: str):
    app = download_cancel(transfer_id=transfer_id)
    asyncio.run(app)
    
if __name__ == '__main__':
    main(transfer_id='1234567890')

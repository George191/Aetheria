import os
import hashlib
import time
import os
import os
import grpc
import asyncio
from typing import AsyncGenerator

from core.protobuf.message.nimbus import nimbus_pb2
from core.protobuf.message.nimbus import nimbus_pb2_grpc



def generate_secret_file_name(file_name: str) -> str:
    timestamp = str(time.time()).encode('utf-8')
    original_name = file_name.encode('utf-8')
    hash_object = hashlib.sha256(timestamp + original_name)
    secret = hash_object.hexdigest()[:16]  # 取前16个字符
    file_extension = os.path.splitext(file_name)[1]
    return f"{secret}{file_extension}"


async def file_request_iterator(
    chunk_stream: AsyncGenerator[bytes, None], file_name: str, file_path: str, bucket_name: str
):
    yield nimbus_pb2.FileUploadRequest(file_name=file_name)
    yield nimbus_pb2.FileUploadRequest(file_path=file_path)
    yield nimbus_pb2.FileUploadRequest(bucket_name=bucket_name)

    # Send file chunks
    async for chunk in chunk_stream:
        yield nimbus_pb2.FileUploadRequest(file_chunk=chunk)


async def upload_file(chunk_stream: AsyncGenerator[bytes, None], file_name: str, file_path: str, bucket_name: str):
    
    channel = grpc.aio.insecure_channel('[::]:50051')
    stub = nimbus_pb2_grpc.NimbusServiceStub(channel)

    try:
        file_name = generate_secret_file_name(file_name=file_name)
        file_path = os.path.join(file_path, file_name)

        request = file_request_iterator(chunk_stream=chunk_stream, file_path=file_path, file_name=file_name, bucket_name=bucket_name)
        async for response in stub.upload_file(request):
            if response.HasField('success'):
                print(f"{response.transfer_id}: {response.success.file_path} {response.success.file_name} - {response.success.status} - Transferred_bytes: {response.success.transferred_bytes}")
            elif response.HasField('error'):
                print(f'{response.transfer_id}: Error: grpc_status: {response.error.grpc_status}, error_code: {response.error.server_code}, message: {response.error.message}')

    except grpc.aio.AioRpcError as e:  # 捕获异步gRPC调用的错误
        print(f'gRPC call failed: {e}')


def main(chunk: bytes, file_name: str, file_path: str, bucket_name: str):
    app = upload_file(chunk, file_name, file_path, bucket_name)
    asyncio.run(app)
    

if __name__ == '__main__':
    main()


from ariadne.asgi import GraphQL
from ariadne.explorer import ExplorerPlayground
from asgi_lifespan import _types
from app.nimbus.graphql.schema.download_file import schema as download_file_schema
from app.nimbus.graphql.schema.download_pause import schema as download_pause_schema
from app.nimbus.graphql.schema.download_resume import schema as download_resume_schema
from app.nimbus.graphql.schema.download_cancel import schema as download_cancel_schema
from app.nimbus.graphql.schema.upload_file import schema as upload_file_schema
from core.logger import logger


def create_app() -> _types.ASGIApp:
    explorer = ExplorerPlayground(
        title="Nimbus GraphQL API", 
        prettier_use_tabs=True,
        schema_polling_enable=True,
        schema_disable_comments=True,
        tracing_hide_tracing_response=True,
        tracing_tracing_supported=True,
        query_plan_hide_query_plan_response=True
    )

    return GraphQL(
        schema=upload_file_schema,
        debug=True,
        explorer=explorer,
        logger=logger
    )



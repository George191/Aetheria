from ariadne import QueryType, SubscriptionType
from app.nimbus.graphql.clients import download_resume
from app.nimbus.utils.response import MessageUtils


query = QueryType()
subscription = SubscriptionType()


@query.field("_empty")
async def resolve_empty(_, info):
    return "GraphQL API is working"


@subscription.source("downloadResume")
async def download_resume_source(_, info, transfer_id):
    async for response in download_resume.download_resume(transfer_id):
        message = MessageUtils(response)

        message.set_success_type("SuccessTransferControlResponse")
        message.set_error_type("StatusResponse")

        yield message.to_dict()


@subscription.field("downloadResume")
async def resolve_download_resume(response, info, transfer_id):
    return response

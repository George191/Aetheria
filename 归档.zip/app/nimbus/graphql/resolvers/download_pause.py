from ariadne import MutationType, QueryType
from app.nimbus.graphql.clients import download_pause
from app.nimbus.utils.response import MessageUtils


mutation = MutationType()
query = QueryType()


@query.field("_empty")
async def resolve_empty(_, info):
    return "GraphQL API is working"


@mutation.field("downloadPause")
async def download_pause_source(_, info, transfer_id: str):
    response = await download_pause.download_pause(transfer_id)
    message = MessageUtils(response)

    message.set_success_type("SuccessTransferControlResponse")
    message.set_error_type("StatusResponse")

    return message.to_dict()

from typing import AsyncGenerator
from ariadne import QueryType, SubscriptionType
from app.nimbus.graphql.clients import upload_file
from app.nimbus.utils.response import MessageUtils


query = QueryType()
subscription = SubscriptionType()


@query.field("_empty")
async def resolve_empty(_, info):
    return "GraphQL API is working"


@subscription.source("uploadFile")
async def upload_file_source(_, info, chunk_stream: AsyncGenerator[bytes, None], file_name: str, file_path: str, bucket_name: str):
    async for response in upload_file.upload_file(chunk_stream=chunk_stream, file_name=file_name, file_path=file_path, bucket_name=bucket_name):
        message = MessageUtils(response)

        message.set_success_type("SuccessFileUploadResponse")
        message.set_error_type("StatusResponse")

        yield message.to_dict()


@subscription.field("uploadFile")
async def resolve_upload_file(response, info, chunk_stream, file_name, file_path, bucket_name):
    return response

from ariadne import QueryType, SubscriptionType
from app.nimbus.graphql.clients import download_file
from app.nimbus.utils.response import MessageUtils


query = QueryType()
subscription = SubscriptionType()


@query.field("_empty")
async def resolve_empty(_, info):
    return "GraphQL API is working"


@subscription.source("downloadFile")
async def download_file_source(_, info, file_path):
    async for response in download_file.download_file(file_path):
        message = MessageUtils(response)

        message.set_success_type("SuccessFileDownloadResponse")
        message.set_error_type("StatusResponse")

        yield message.to_dict()


@subscription.field("downloadFile")
async def resolve_download_file(response, info, file_path):
    return response

from ariadne import make_executable_schema, gql
from app.nimbus.graphql.resolvers.upload_file import query, subscription


type_defs = gql("""
    enum TransferStatus {
        PENDING
        IN_PROGRESS
        SUCCESS
        FAILED
        PAUSED
        CANCELLED
    }

    type SuccessFileUploadResponse {
        file_name: String!
        file_path: String!
        transferred_bytes: Float!
        status: TransferStatus!
    }

    type StatusResponse {
        grpc_status: Int!
        server_code: Int!
        message: String!
    }

    union FileUploadResponseUnion = SuccessFileUploadResponse | StatusResponse

    type FileUploadResponse {
        response: FileUploadResponseUnion!
        transfer_id: String!
    }

    type Subscription {
        uploadFile(chunk_stream: String!, file_name: String!, file_path: String!, bucket_name: String!): FileUploadResponse!
    }
                
    type Query {
        _empty: String
    }
""")


# Create the executable schema
schema = make_executable_schema(type_defs, query, subscription)


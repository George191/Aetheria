import asyncio
from botocore.exceptions import BotoCoreError, ClientError

from grpc import RpcError, ServicerContext, StatusCode
from grpc._cython.cygrpc import _MessageReceiver

from google.protobuf.json_format import MessageToDict

from utils.dependencies import StorageClient
from utils.exceptions import ArgumentError

from os import environ
from json import dumps, loads

from core.protobuf.message.nimbus import nimbus_pb2, nimbus_pb2_grpc
from core.clients import RedisPoolManager
from core.utils.string_utils import uuid_16 as generate_transfer_id
from core.logger import logger


TRANSFER_ID_NOT_FOUND = 'Transfer ID not found.'


class NimbusServiceServicer(nimbus_pb2_grpc.NimbusService):
    
    def __init__(self, storage_client: StorageClient):
        self.storage_client = storage_client
        self.redis_client = RedisPoolManager()
        self.database = environ['redis_index']
        self.upload_buffer_size = 5 * 1024 * 1024
        self.download_buffer_size = 128 * 1024

    async def upload_file(self, request_iterator: _MessageReceiver, context: ServicerContext):
        
        transfer_id = generate_transfer_id()  # 生成唯一的传输ID
        buffer = bytearray()
        part_num = 1
        transferred_bytes = 0
        file_path = bucket_name = ""
        upload_id = None
        parts = []

        success_file_upload_response = nimbus_pb2.SuccessFileUploadResponse()
        success_file_upload_response.status = nimbus_pb2.TransferStatus.IN_PROGRESS

        status_response = nimbus_pb2.StatusResponse()
        status_response.grpc_status = StatusCode.INTERNAL.value[0]
        status_response.server_code = 500

        file_upload_response = nimbus_pb2.FileUploadResponse()
        file_upload_response.transfer_id = transfer_id
        
        upload_buffer_size = int(environ.get('upload_buffer_size', self.upload_buffer_size))

        try:
            await self.redis_client.set_hash_mapping(name=transfer_id, database=self.database, type='upload')

            async for request in request_iterator:
                status = await self.redis_client.get_hash_value(name=transfer_id, database=self.database, key='status')
                if status:
                    if status == 'pausing':
                        await logger.info(f"Upload {transfer_id} has been paused")
                        success_file_upload_response.status = nimbus_pb2.TransferStatus.PAUSED
                        file_upload_response.success.CopyFrom(success_file_upload_response)
                        yield file_upload_response
                        return
                    elif status == 'cancelling':
                        await logger.info(f"Upload {transfer_id} has been canceled")
                        success_file_upload_response.status = nimbus_pb2.TransferStatus. CANCELLED
                        file_upload_response.success.CopyFrom(success_file_upload_response)
                        yield file_upload_response
                        return
                
                if getattr(request, "file_name"):
                    file_name = getattr(request, "file_name")
                    await self.redis_client.set_hash_value(name=transfer_id, database=self.database, key='file_name', value=file_name)
                    success_file_upload_response.file_name = file_name

                elif getattr(request, "bucket_name"):
                    bucket_name = getattr(request, "bucket_name")
                    await self.redis_client.set_hash_value(name=transfer_id, database=self.database, key='bucket_name', value=bucket_name)

                elif getattr(request, "file_path"):
                    file_path = getattr(request, "file_path")
                    await self.redis_client.set_hash_value(name=transfer_id, database=self.database, key='file_path', value=file_path)

                elif getattr(request, "file_chunk"):
                    
                    buffer.extend(request.file_chunk)

                    transferred_bytes += len(request.file_chunk)
                    
                    if len(buffer) >= upload_buffer_size:
                        upload_id, parts = self.storage_client.upload_chunk(
                            remote_path=file_path,
                            file_chunk=buffer,
                            part_num=part_num,
                            upload_id=upload_id,
                            bucket_name=bucket_name,
                            parts=parts,
                        )
                        part_num += 1
                        buffer.clear()  # 重置buffer为一个空的bytearray
                        await self.redis_client.set_hash_mapping(
                            name=transfer_id, database=self.database, upload_id=upload_id, 
                            parts=dumps(parts), transferred_bytes=transferred_bytes, part_num=part_num,
                        )
                        success_file_upload_response.transferred_bytes = transferred_bytes
                        file_upload_response.success.CopyFrom(success_file_upload_response)

                        yield file_upload_response
                        await logger.debug(f"{MessageToDict(file_upload_response)}")

            if buffer: 
                upload_id, parts = self.storage_client.upload_chunk(
                    remote_path=file_path,
                    file_chunk=buffer,
                    part_num=part_num,
                    upload_id=upload_id,
                    bucket_name=bucket_name,
                    parts=parts,
                )
                success_file_upload_response.transferred_bytes = transferred_bytes

            if success_file_upload_response.status == nimbus_pb2.TransferStatus.IN_PROGRESS:
                success_file_upload_response.file_path = self.storage_client.complete_upload(
                    remote_path=file_path,
                    upload_id=upload_id,
                    parts=parts,
                    bucket_name=bucket_name,
                )
                success_file_upload_response.status = nimbus_pb2.TransferStatus.SUCCESS
                file_upload_response.success.CopyFrom(success_file_upload_response)
                await self.redis_client.delete_value(transfer_id, database=self.database)
                await logger.info(f"upload {transfer_id} has been completed successfully.")
                yield file_upload_response
                return
            else: 
                status_response.message = 'UnKnown Error!'
                file_upload_response.error.CopyFrom(status_response)
                await logger.error(f"UnKnown Error: {MessageToDict(file_upload_response)}")
                yield file_upload_response
                return
                
        except TypeError as e:
            status_response.message = str(e)
            file_upload_response.error.CopyFrom(status_response)
            await logger.error(f"TypeError: {MessageToDict(file_upload_response)}")
            yield file_upload_response
            return

        except RpcError as e:
            status_response.message = str(e)
            file_upload_response.error.CopyFrom(status_response)
            await logger.error(f"RpcError: {MessageToDict(file_upload_response)}")
            yield file_upload_response
            return
        
        except BotoCoreError as e:
            status_response.grpc_status = StatusCode.UNAVAILABLE.value[0]
            status_response.message = str(e.fmt)
            file_upload_response.error.CopyFrom(status_response)
            await logger.error(f"BotoCoreError: {MessageToDict(file_upload_response)}")
            yield file_upload_response
            return
        
        except ClientError as e:
            status_response.grpc_status = StatusCode.PERMISSION_DENIED.value[0]
            status_response.message = str(e.response)
            file_upload_response.error.CopyFrom(status_response)
            await logger.error(f"ClientError: {MessageToDict(file_upload_response)}")
            yield file_upload_response
            return

        except ValueError as e:
            status_response.message = str(e)
            status_response.grpc_status = StatusCode.INVALID_ARGUMENT.value[0]
            file_upload_response.error.CopyFrom(status_response)
            await logger.error(f"ValueError: {MessageToDict(file_upload_response)}")
            yield file_upload_response
            return

    async def download_file(self, request, context: ServicerContext):
        transfer_id = generate_transfer_id()  # 生成唯一的传输ID
        success_file_download_response = nimbus_pb2.SuccessFileDownloadResponse()
        success_file_download_response.status = nimbus_pb2.TransferStatus.IN_PROGRESS
        status_response = nimbus_pb2.StatusResponse()
        status_response.grpc_status = StatusCode.INTERNAL.value[0]
        status_response.server_code = 500
        file_download_response = nimbus_pb2.FileDownloadResponse()
        file_download_response.transfer_id = transfer_id
        file_path = request.file_path
        download_buffer_size = int(environ.get('download_buffer_size', self.download_buffer_size))

        transferred_bytes = await self.redis_client.get_hash_value(name=transfer_id, key=file_path, database=self.database)

        if not transferred_bytes:
            transferred_bytes = 0

        try:
            obj = self.storage_client.stat_object(file_path)
            total_bytes = obj.get("ContentLength", 0)
            await self.redis_client.set_hash_mapping(
                name=transfer_id, type='download', total_bytes=total_bytes, 
                file_path=file_path, database=self.database
            )
            data = self.storage_client.get_object(file_path, transferred_bytes=transferred_bytes)

            stream = data.get("Body", None)
            if not stream:
                status_response.message = "No data body in the response."
                status_response.grpc_status = StatusCode.INVALID_ARGUMENT.value[0]
                file_download_response.error.CopyFrom(status_response)
                await logger.error(f"Response: {MessageToDict(file_download_response)}")
                yield file_download_response
                return

            while 1:
                status = await self.redis_client.get_hash_value(name=transfer_id, database=self.database, key='status')
                if status:
                    if status == 'pausing':
                        await logger.info(f"Upload {transfer_id} has been paused")
                        success_file_download_response.status = nimbus_pb2.TransferStatus.PAUSED
                        file_download_response.success.CopyFrom(success_file_download_response)
                        yield file_download_response
                        return
                    elif status == 'cancelling':
                        await logger.info(f"Upload {transfer_id} has been canceled")
                        success_file_download_response.status = nimbus_pb2.TransferStatus. CANCELLED
                        file_download_response.success.CopyFrom(success_file_download_response)
                        yield file_download_response
                        return
                
                chunk = stream.read(download_buffer_size)
                transferred_bytes += len(chunk)
                
                success_file_download_response.file_path = file_path
                success_file_download_response.chunk = chunk
                success_file_download_response.transferred_bytes = transferred_bytes
                success_file_download_response.total_bytes = total_bytes
                if not chunk or transferred_bytes >= total_bytes:
                    success_file_download_response.status = nimbus_pb2.TransferStatus.SUCCESS

                file_download_response.success.CopyFrom(success_file_download_response)
                await self.redis_client.set_hash_mapping(
                    name=transfer_id, transferred_bytes=transferred_bytes, 
                    total_bytes=total_bytes, database=self.database
                )
                yield file_download_response

                if not chunk or transferred_bytes >= obj["ContentLength"]:
                    await logger.info(f"Response: {file_path} has been downloaded successfully.")
                    await self.redis_client.delete_value(transfer_id, database=self.database)
                    return

        except TypeError as e:
            status_response.message = str(e)
            status_response.grpc_status = StatusCode.FAILED_PRECONDITION.value[0]
            file_download_response.error.CopyFrom(status_response)
            await logger.error(f"Response: {MessageToDict(file_download_response)}")
            yield file_download_response
            return

        except RpcError as e:
            status_response.message = str(e)
            file_download_response.error.CopyFrom(status_response)
            await logger.error(f"Response: {MessageToDict(file_download_response)}")
            yield file_download_response
            return
        
        except BotoCoreError as e:
            status_response.grpc_status = StatusCode.UNAVAILABLE.value[0]
            status_response.message = str(e)
            file_download_response.error.CopyFrom(status_response)
            await logger.error(f"Response: {MessageToDict(file_download_response)}")
            yield file_download_response
            return
        
        except ClientError as e:
            status_response.grpc_status = StatusCode.PERMISSION_DENIED.value[0]
            status_response.message = str(e)
            file_download_response.error.CopyFrom(status_response)
            await logger.error(f"Response: {MessageToDict(file_download_response)}")
            yield file_download_response
            return

        except ValueError as e:
            status_response.message = str(e)
            status_response.grpc_status = StatusCode.INVALID_ARGUMENT.value[0]
            file_download_response.error.CopyFrom(status_response)
            await logger.error(f"Response: {MessageToDict(file_download_response)}")
            yield file_download_response
            return

    async def upload_pause(self, request, context: ServicerContext):
        transfer_id = request.transfer_id
        transfer_control_response = nimbus_pb2.TransferControlResponse()
        exists = await self.redis_client.exists(transfer_id, database=self.database)
        if not exists:
            status_response = nimbus_pb2.StatusResponse()
            status_response.server_code = 404
            status_response.grpc_status = StatusCode.NOT_FOUND.value[0]
            status_response.message = 'Transfer ID not found'
            transfer_control_response.error.CopyFrom(status_response)
            yield transfer_control_response
        else:
            try:
                success_transfer_control_response = nimbus_pb2.SuccessTransferControlResponse()
                success_transfer_control_response.status = nimbus_pb2.TransferStatus.SUCCESS
                success_transfer_control_response.message = f"Transfer ID {transfer_id} has been paused."
                transfer_control_response.transfer_id = transfer_id
                transfer_control_response.success.CopyFrom(success_transfer_control_response)
                await self.redis_client.set_hash_mapping(name=transfer_id, database=self.database, status='pausing')
                yield transfer_control_response
                return
            except ValueError as e:
                status_response.message = str(e)
                status_response.grpc_status = StatusCode.INVALID_ARGUMENT.value[0]
                transfer_control_response.error.CopyFrom(status_response)
                await logger.error(f"Response: {MessageToDict(transfer_control_response)}")
                yield transfer_control_response
                return
            
    async def upload_resume(self, request_iterator: _MessageReceiver, context: ServicerContext):

        upload_buffer_size = int(environ.get('upload_buffer_size', self.upload_buffer_size))

        success_file_upload_response = nimbus_pb2.SuccessFileUploadResponse()
        success_file_upload_response.status = nimbus_pb2.TransferStatus.IN_PROGRESS

        status_response = nimbus_pb2.StatusResponse()
        status_response.grpc_status = StatusCode.INTERNAL.value[0]
        status_response.server_code = 500

        file_upload_response = nimbus_pb2.FileUploadResponse()

        buffer = bytearray()
        part_num = 1
        transferred_bytes = 0
        file_path = bucket_name = transfer_id = ""
        upload_id = None
        parts = []

        try:
            async for request in request_iterator:
                status = await self.redis_client.get_hash_value(name=transfer_id, database=self.database, key='status')
                if status:
                    if status == 'pausing':
                        await logger.info(f"Upload {transfer_id} has been paused")
                        success_file_upload_response.status = nimbus_pb2.TransferStatus.PAUSED
                        file_upload_response.success.CopyFrom(success_file_upload_response)
                        yield file_upload_response
                        return
                    elif status == 'cancelling':
                        await logger.info(f"Upload {transfer_id} has been canceled")
                        success_file_upload_response.status = nimbus_pb2.TransferStatus. CANCELLED
                        file_upload_response.success.CopyFrom(success_file_upload_response)
                        yield file_upload_response
                        return
                
                if getattr(request, "transfer_id"):
                    transfer_id = getattr(request, "transfer_id")
                    file_upload_response.transfer_id = transfer_id
                    recovery_data = await self.redis_client.get_hash_mapping(name=transfer_id, database=self.database)
                    if not recovery_data:
                        status_response.message = f"Transfer ID - {transfer_id} -not found."
                        status_response.grpc_status = StatusCode.FAILED_PRECONDITION.value[0]
                        file_upload_response.error.CopyFrom(status_response)
                        await logger.error(f"Response: {MessageToDict(file_upload_response)}")
                        yield file_upload_response
                        return         
                    
                    bucket_name = recovery_data.get('bucket_name')
                    upload_id = recovery_data.get('upload_id')
                    part_num = int(recovery_data.get('part_num'))
                    transferred_bytes = int(recovery_data.get('transferred_bytes'))
                    buffer = bytearray(recovery_data.get('buffer').encode('utf-8'))
                    parts = loads(recovery_data.get('parts'))
                    file_path = recovery_data.get('file_path')
                    
                    success_file_upload_response.file_name = recovery_data.get('file_name')
                    await self.redis_client.delete_hash_value(transfer_id, 'status', database=self.database)

                elif getattr(request, "file_chunk"):
                    transferred_bytes += len(request.file_chunk)
                    buffer.extend(request.file_chunk)
                    buffer_bytes = bytes(buffer)  # 确保是 bytes 类型
                    await self.redis_client.set_hash_value(name=transfer_id, database=self.database, key='buffer', value=buffer_bytes)
                    if len(buffer) >= upload_buffer_size:
                        upload_id, parts = self.storage_client.upload_chunk(
                            remote_path=file_path,
                            file_chunk=buffer,
                            part_num=part_num,
                            upload_id=upload_id,
                            bucket_name=bucket_name,
                            parts=parts,
                        )
                        part_num += 1
                        buffer.clear()  # 重置buffer为一个空的bytearray
                        await self.redis_client.set_hash_mapping(
                            name=transfer_id, database=self.database, upload_id=upload_id, 
                            parts=dumps(parts), transferred_bytes=transferred_bytes, part_num=part_num,
                        )
                        success_file_upload_response.transferred_bytes = transferred_bytes
                        file_upload_response.success.CopyFrom(success_file_upload_response)
                        yield file_upload_response

            if buffer:
                upload_id, parts = self.storage_client.upload_chunk(
                    remote_path=file_path,
                    file_chunk=buffer,
                    part_num=part_num,
                    upload_id=upload_id,
                    bucket_name=bucket_name,
                    parts=parts,
                )
                success_file_upload_response.transferred_bytes = transferred_bytes
            if success_file_upload_response.status == nimbus_pb2.TransferStatus.IN_PROGRESS:
                success_file_upload_response.file_path = self.storage_client.complete_upload(
                    remote_path=file_path,
                    upload_id=upload_id,
                    parts=parts,
                    bucket_name=bucket_name,
                )
                success_file_upload_response.status = nimbus_pb2.TransferStatus.SUCCESS
                file_upload_response.success.CopyFrom(success_file_upload_response)
                await self.redis_client.delete_value(transfer_id, database=self.database)
                await logger.info(f"Response: upload {transfer_id} has been completed successfully.")
                yield file_upload_response
                return
            else: 
                status_response.message = 'UnKnown Error!'
                file_upload_response.error.CopyFrom(status_response)
                await logger.error(f"Response: {MessageToDict(file_upload_response)}")
                yield file_upload_response
                return
                
        except TypeError as e:
            status_response.message = str(e)
            status_response.grpc_status = StatusCode.FAILED_PRECONDITION.value[0]
            file_upload_response.error.CopyFrom(status_response)
            await logger.error(f"Response: {MessageToDict(file_upload_response)}")
            yield file_upload_response
            return

        except RpcError as e:
            status_response.message = str(e)
            file_upload_response.error.CopyFrom(status_response)
            await logger.error(f"Response: {MessageToDict(file_upload_response)}")
            yield file_upload_response
            return
        
        except BotoCoreError as e:
            status_response.grpc_status = StatusCode.UNAVAILABLE.value[0]
            status_response.message = str(e)
            file_upload_response.error.CopyFrom(status_response)
            await logger.error(f"Response: {MessageToDict(file_upload_response)}")
            yield file_upload_response
            return
        
        except ClientError as e:
            status_response.grpc_status = StatusCode.PERMISSION_DENIED.value[0]
            status_response.message = str(e)
            file_upload_response.error.CopyFrom(status_response)
            await logger.error(f"Response: {MessageToDict(file_upload_response)}")
            yield file_upload_response
            return

        except ValueError as e:
            status_response.message = str(e)
            status_response.grpc_status = StatusCode.INVALID_ARGUMENT.value[0]
            file_upload_response.error.CopyFrom(status_response)
            await logger.error(f"Response: {MessageToDict(file_upload_response)}")
            yield file_upload_response
            return

    async def download_pause(self, request, context: ServicerContext):
        transfer_id = request.transfer_id
        status_response = nimbus_pb2.StatusResponse()
        exists = await self.redis_client.exists(transfer_id, database=self.database)
        transfer_control_response = nimbus_pb2.TransferControlResponse()

        if not exists:
            status_response.server_code = 404
            status_response.grpc_status = StatusCode.NOT_FOUND.value[0]
            status_response.message = TRANSFER_ID_NOT_FOUND
            transfer_control_response.error.CopyFrom(status_response)
            return transfer_control_response
        else:
            try:
                success_transfer_control_response = nimbus_pb2.SuccessTransferControlResponse()
                success_transfer_control_response.status = nimbus_pb2.TransferStatus.SUCCESS
                success_transfer_control_response.message = f"Transfer ID {transfer_id} has been paused."
                transfer_control_response.transfer_id = transfer_id
                transfer_control_response.success.CopyFrom(success_transfer_control_response)
                await self.redis_client.set_hash_mapping(name=transfer_id, database=self.database, status='pausing')
                return transfer_control_response
            
            except ValueError as e:
                status_response.message = str(e)
                status_response.grpc_status = StatusCode.INVALID_ARGUMENT.value[0]
                transfer_control_response.error.CopyFrom(status_response)
                await logger.error(f"Response: {MessageToDict(transfer_control_response)}")
                return transfer_control_response
                
            
    async def download_resume(self, request, context: ServicerContext):

        transfer_id = request.transfer_id
        await self.redis_client.delete_hash_value(transfer_id, 'status', database=self.database)
        success_file_download_response = nimbus_pb2.SuccessFileDownloadResponse()
        success_file_download_response.status = nimbus_pb2.TransferStatus.IN_PROGRESS
        status_response = nimbus_pb2.StatusResponse()
        status_response.grpc_status = StatusCode.INTERNAL.value[0]
        status_response.server_code = 500
        file_download_response = nimbus_pb2.FileDownloadResponse()
        file_download_response.transfer_id = transfer_id
        
        download_buffer_size = int(environ.get('download_buffer_size', self.download_buffer_size))

        recovery_data = await self.redis_client.get_hash_mapping(name=transfer_id, database=self.database)

        if not recovery_data:
            status_response.message = f"Transfer ID - {transfer_id} -not found."
            status_response.grpc_status = StatusCode.FAILED_PRECONDITION.value[0]
            file_download_response.error.CopyFrom(status_response)
            await logger.error(f"Response: {MessageToDict(file_download_response)}")
            yield file_download_response
            return
        
        transferred_bytes = recovery_data.get('transferred_bytes')

        try:
            file_path = recovery_data.get('file_path')

            obj = self.storage_client.stat_object(file_path)
            total_bytes = obj.get("ContentLength", 0)
            data = self.storage_client.get_object(file_path, transferred_bytes=transferred_bytes)

            stream = data.get("Body", None)
            if not stream:
                status_response.message = "No data body in the response."
                status_response.grpc_status = StatusCode.FAILED_PRECONDITION.value[0]
                file_download_response.error.CopyFrom(status_response)
                await logger.error(f"Response: {MessageToDict(file_download_response)}")
                yield file_download_response
                return

            while 1:
                status = await self.redis_client.get_hash_value(name=transfer_id, database=self.database, key='status')
                if status:
                    if status == 'pausing':
                        await logger.info(f"Upload {transfer_id} has been paused")
                        success_file_download_response.status = nimbus_pb2.TransferStatus.PAUSED
                        file_download_response.success.CopyFrom(success_file_download_response)
                        yield file_download_response
                        return
                    elif status == 'cancelling':
                        await logger.info(f"Upload {transfer_id} has been canceled")
                        success_file_download_response.status = nimbus_pb2.TransferStatus. CANCELLED
                        file_download_response.success.CopyFrom(success_file_download_response)
                        yield file_download_response
                        return
                
                chunk = stream.read(download_buffer_size)
                transferred_bytes += len(chunk)
                
                success_file_download_response.file_path = file_path
                success_file_download_response.chunk = chunk
                success_file_download_response.transferred_bytes = transferred_bytes
                success_file_download_response.total_bytes = total_bytes
                if not chunk or transferred_bytes >= total_bytes:
                    success_file_download_response.status = nimbus_pb2.TransferStatus.SUCCESS

                file_download_response.success.CopyFrom(success_file_download_response)
                await self.redis_client.set_hash_mapping(
                    name=transfer_id, transferred_bytes=transferred_bytes, 
                    total_bytes=total_bytes, database=self.database
                )
                yield file_download_response

                if not chunk or transferred_bytes >= obj["ContentLength"]:
                    await logger.info(f"Response: Stream {file_path} has been downloaded successfully.")
                    await self.redis_client.delete_value(transfer_id, database=self.database)
                    return

        except TypeError as e:
            status_response.message = str(e)
            status_response.grpc_status = StatusCode.FAILED_PRECONDITION.value[0]
            file_download_response.error.CopyFrom(status_response)
            await logger.error(f"Response: {MessageToDict(file_download_response)}")
            yield file_download_response
            return

        except RpcError as e:
            status_response.message = str(e)
            file_download_response.error.CopyFrom(status_response)
            await logger.error(f"Response: {MessageToDict(file_download_response)}")
            yield file_download_response
            return
        
        except BotoCoreError as e:
            status_response.grpc_status = StatusCode.UNAVAILABLE.value[0]
            status_response.message = str(e)
            file_download_response.error.CopyFrom(status_response)
            await logger.error(f"Response: {MessageToDict(file_download_response)}")
            yield file_download_response
            return
        
        except ClientError as e:
            status_response.grpc_status = StatusCode.PERMISSION_DENIED.value[0]
            status_response.message = str(e)
            file_download_response.error.CopyFrom(status_response)
            await logger.error(f"Response: {MessageToDict(file_download_response)}")
            yield file_download_response
            return
        
        except ValueError as e:
            status_response.message = str(e)
            status_response.grpc_status = StatusCode.INVALID_ARGUMENT.value[0]
            file_download_response.error.CopyFrom(status_response)
            await logger.error(f"Response: {MessageToDict(file_download_response)}")
            yield file_download_response
            return

    async def upload_cancel(self, request, context: ServicerContext):
        transfer_id = request.transfer_id
        transfer_control_response = nimbus_pb2.TransferControlResponse()
        status_response = nimbus_pb2.StatusResponse()
        status_response.server_code = 500
        status_response.grpc_status = StatusCode.INTERNAL.value[0]

        transfer_control_response.transfer_id = transfer_id
        exists = await self.redis_client.exists(transfer_id, database=self.database)
        success_transfer_control_response = nimbus_pb2.SuccessTransferControlResponse()

        if not exists:
            status_response.server_code = 404
            status_response.grpc_status = StatusCode.NOT_FOUND.value[0]
            status_response.message = TRANSFER_ID_NOT_FOUND
            transfer_control_response.error.CopyFrom(success_transfer_control_response)
            yield transfer_control_response
        else:
            try:
                recovery_data = await self.redis_client.get_hash_mapping(name=transfer_id, database=self.database)
                if not recovery_data:
                    status_response.message = f"Transfer ID - {transfer_id} -not found."
                    status_response.grpc_status = StatusCode.FAILED_PRECONDITION.value[0]
                    transfer_control_response.error.CopyFrom(status_response)
                    await logger.error(f"Response: {MessageToDict(transfer_control_response)}")
                    yield transfer_control_response
                    return          
                      
                bucket_name = recovery_data['bucket_name']
                remote_path = recovery_data.get['file_path']
                upload_id = recovery_data.get['upload_id']
                self.storage_client.abort_upload(bucket_name=bucket_name, remote_path=remote_path, upload_id=upload_id)
                success_transfer_control_response.status = nimbus_pb2.TransferStatus.SUCCESS
                success_transfer_control_response.message = f"Transfer ID {transfer_id} has been canceled."
                transfer_control_response.success.CopyFrom(success_transfer_control_response)
                await self.redis_client.set_hash_mapping(
                    name=transfer_id, database=self.database, status='cancelling'
                )
                yield transfer_control_response
                return
            
            except KeyError as e:
                status_response.message = str(e)
                transfer_control_response.error.CopyFrom(status_response)
                await logger.error(f"Response: {MessageToDict(transfer_control_response)}")
                yield transfer_control_response
                return
            
            except TypeError as e:
                status_response.message = str(e)
                status_response.grpc_status = StatusCode.FAILED_PRECONDITION.value[0]
                transfer_control_response.error.CopyFrom(status_response)
                await logger.error(f"Response: {MessageToDict(transfer_control_response)}")
                yield transfer_control_response
                return

            except RpcError as e:
                status_response.message = str(e)
                transfer_control_response.error.CopyFrom(status_response)
                await logger.error(f"Response: {MessageToDict(transfer_control_response)}")
                yield transfer_control_response
                return
            
            except BotoCoreError as e:
                status_response.grpc_status = StatusCode.UNAVAILABLE.value[0]
                status_response.message = str(e)
                transfer_control_response.error.CopyFrom(status_response)
                await logger.error(f"Response: {MessageToDict(transfer_control_response)}")
                yield transfer_control_response
                return
            
            except ClientError as e:
                status_response.grpc_status = StatusCode.PERMISSION_DENIED.value[0]
                status_response.message = str(e)
                transfer_control_response.error.CopyFrom(status_response)
                await logger.error(f"Response: {MessageToDict(transfer_control_response)}")
                yield transfer_control_response
                return
            
            except ValueError as e:
                status_response.message = str(e)
                status_response.grpc_status = StatusCode.INVALID_ARGUMENT.value[0]
                transfer_control_response.error.CopyFrom(status_response)
                await logger.error(f"Response: {MessageToDict(transfer_control_response)}")
                yield transfer_control_response
                return

    async def download_cancel(self, request, context: ServicerContext):
        transfer_id = request.transfer_id
        transfer_control_response = nimbus_pb2.TransferControlResponse()
        transfer_control_response.transfer_id = transfer_id
        status_response = nimbus_pb2.StatusResponse()
        success_transfer_control_response = nimbus_pb2.SuccessTransferControlResponse()

        exists = await self.redis_client.exists(transfer_id, database=self.database)
        if not exists:
            status_response.server_code = 404
            status_response.grpc_status = StatusCode.NOT_FOUND.value[0]
            status_response.message = TRANSFER_ID_NOT_FOUND
            transfer_control_response.error.CopyFrom(success_transfer_control_response)
            return transfer_control_response
        else:
            try:
                success_transfer_control_response.status = nimbus_pb2.TransferStatus.SUCCESS
                success_transfer_control_response.message = f"Transfer ID {transfer_id} has been canceled."
                transfer_control_response.success.CopyFrom(success_transfer_control_response)
                await self.redis_client.set_hash_mapping(
                    name=transfer_id, database=self.database, status='cancelling'
                )
                return transfer_control_response
                
            except ValueError as e:
                status_response.message = str(e)
                status_response.grpc_status = StatusCode.INVALID_ARGUMENT.value[0]
                transfer_control_response.error.CopyFrom(status_response)
                await logger.error(f"Response: {MessageToDict(transfer_control_response)}")
                return transfer_control_response
                
from setuptools import setup, find_packages

setup(
    name='nimbus',
    version='0.1.0.0',
    packages=find_packages(),
    install_requires=[
        "grpcio==1.60.0",
        "grpcio-tools==1.60.0",
        "protobuf==4.25.1", 
        "boto3==1.34.10",
        "botocore==1.34.10",
    ],
    extras_require={
        'dev': [
            "aiofiles==23.2.1",
            "ariadne==0.23.0",
            "aiohttp==3.9.5",
            "uvicorn==0.30.3",
            "uvicorn[standard]==0.30.3",  # 安装带有 WebSocket 支持的 uvicorn
            "wsproto==1.2.0",
            "asgiref==3.8.1",
            "asgi_lifespan==2.1.0"
        ],
        "prod": []
    },
)
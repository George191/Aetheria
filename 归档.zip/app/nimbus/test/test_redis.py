import aioredis
import asyncio

# 连接到Redis
r = aioredis.Redis(host='localhost', port=6379, db=15)


# 清空当前数据库
asyncio.run(r.flushdb())


# buffer = asyncio.run(r.hget(name='CFso8k83M5kikSYl', key='buffer'))
# print(buffer)


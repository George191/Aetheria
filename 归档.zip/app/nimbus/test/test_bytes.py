ba = bytearray([65, 66, 67])  # 示例：非空的bytearray，包含"ABC"
print(ba)  # bytearray(b'ABC')

# 转换为bytes
b = bytes(ba)
print(b)  # b'ABC'


ba = bytearray([65, 66, 67])
print(f"Before conversion: {ba}")

b = bytes(ba)
print(f"After conversion: {b}")


ba_empty = bytearray()  # 空的bytearray
print(f"Empty bytearray before conversion: {ba_empty}")

b_empty = bytes(ba_empty)
print(f"Converted bytes from empty bytearray: {b_empty}")  # 将打印空的bytes对象


c_dict = {"a": 1}
print(c_dict.get('b'))
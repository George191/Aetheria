import asyncio
import os
from pathlib import Path
import sys
import time
import grpc
import aiofiles

Basedir = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, os.path.abspath(Basedir))

from core.protobuf.message.nimbus import nimbus_pb2
from core.protobuf.message.nimbus import nimbus_pb2_grpc


async def file_request_iterator(
    transfer_id, local_path, chunk_size=128 * 1024
):
    yield nimbus_pb2.FileUploadResumeRequest(transfer_id=transfer_id)
    
    try:
        async with aiofiles.open(local_path, "rb") as fp:
            start_bytes = 424673280
            await fp.seek(start_bytes)
            while 1:
                data = await fp.read(chunk_size)
                if not data:
                    break
                yield nimbus_pb2.FileUploadResumeRequest(file_chunk=data)
    except Exception as e:
        print(e)

async def test_upload_resume():
    now = time.time()
    channel = grpc.aio.insecure_channel('127.0.0.1:39150')
    stub = nimbus_pb2_grpc.NimbusServiceStub(channel)

    try:
        local_path = f'/Users/george/CodeLab/aetheria-services/service/nimbus/test/test_file.csv'
        transfer_id = 'OEjwuIJgoCn0ebSO'
        request = file_request_iterator(local_path=local_path, transfer_id=transfer_id)
        print(request)
        async for response in stub.upload_resume(request):
            if response.HasField('success'):
                print(f"{response.transfer_id}: {response.success.file_path} {response.success.file_name} - {response.success.status} - Transferred_bytes: {response.success.transferred_bytes}")
            elif response.HasField('error'):
                print(f'{response.transfer_id}: Error: grpc_status: {response.error.grpc_status}, error_code: {response.error.server_code}, message: {response.error.message}')

    except grpc.aio.AioRpcError as e:  # 捕获异步gRPC调用的错误
        print(f'gRPC call failed: {e}')
    
    print('耗时: ', time.time() - now)
    # 1.47G 无redis 1128.5906178951263
    # 1.47G 有redis 1214.262804031372

def main():
    asyncio.run(test_upload_resume())
    
if __name__ == '__main__':
    main()
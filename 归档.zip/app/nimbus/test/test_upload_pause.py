import os
from pathlib import Path
import uuid as UUID

# import pytest
import time
import os
import sys
import grpc
import asyncio

Basedir = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, os.path.abspath(Basedir))

from core.protobuf.message.nimbus import nimbus_pb2
from core.protobuf.message.nimbus import nimbus_pb2_grpc

async def test_upload_pause():
    now = time.time()
    channel = grpc.aio.insecure_channel('127.0.0.1:39150')
    stub = nimbus_pb2_grpc.NimbusServiceStub(channel)

    try:
        TransferControlRequest = nimbus_pb2.TransferControlRequest(transfer_id="OEjwuIJgoCn0ebSO")
        response = await stub.upload_pause(TransferControlRequest)

        if response.HasField('success'):
            print(response.success.message, response.success.status)
        elif response.HasField('error'):
            print(f'Error: grpc_status: {response.error.grpc_status}, error_code: {response.error.server_code}, message: {response.error.message}')

    except grpc.aio.AioRpcError as e:  # 捕获异步gRPC调用的错误
        print(f'gRPC call failed: {e}')
    
    print('耗时: ', time.time() - now)

def main():
    asyncio.run(test_upload_pause())
    
if __name__ == '__main__':
    main()


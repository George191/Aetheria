import os
from pathlib import Path
import sys

Basedir = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, os.path.abspath(Basedir))

import grpc
from core.protobuf.message.nimbus import nimbus_pb2
from core.protobuf.message.nimbus import nimbus_pb2_grpc
import asyncio

async def test_download_file():
    channel = grpc.aio.insecure_channel('127.0.0.1:39150')
    stub = nimbus_pb2_grpc.NimbusServiceStub(channel)
    
    try:
        # 替换为一个有效的文件路径
        TransferControlRequest = nimbus_pb2.TransferControlRequest(transfer_id='zes1ynziGWTufgsI')

        async for response in stub.download_resume(TransferControlRequest):
            if response.HasField('success'):
                print(f"{response.transfer_id}: File_path Chunk received: {len(response.success.chunk)} bytes, Transferred_bytes: {response.success.transferred_bytes}, Status: {response.success.status}")
            elif response.HasField('error'):
                print(f'{response.transfer_id}: Error: grpc_status: {response.error.grpc_status}, error_code: {response.error.server_code}, message: {response.error.message}')
    
    except grpc.aio.AioRpcError as e:  # 捕获异步gRPC调用的错误
        print(f'gRPC call failed: {e}')
    


def main():
    asyncio.run(test_download_file())

if __name__ == '__main__':
    main()
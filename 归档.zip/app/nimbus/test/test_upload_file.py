import os
from pathlib import Path
import uuid as UUID

# import pytest
import time
import os
import sys
import grpc
import asyncio
import aiofiles
Basedir = Path(__file__).parent.parent.parent.parent
sys.path.insert(0, os.path.abspath(Basedir))

from core.protobuf.message.nimbus import nimbus_pb2
from core.protobuf.message.nimbus import nimbus_pb2_grpc


async def file_request_iterator(
    local_path, file_name, file_path, bucket_name, chunk_size=128 * 1024
):
    yield nimbus_pb2.FileUploadRequest(file_name=file_name)
    yield nimbus_pb2.FileUploadRequest(file_path=file_path)
    yield nimbus_pb2.FileUploadRequest(bucket_name=bucket_name)
    
    async with aiofiles.open(local_path, "rb") as fp:
        while 1:
            data = await fp.read(chunk_size)
            if not data:
                break
            yield nimbus_pb2.FileUploadRequest(file_chunk=data)

def generate_secret_file_name(file_name: str) -> str:
    secret = str(UUID.uuid4()).replace("-", "")
    _, file_extension = os.path.splitext(file_name)
    return f"{secret}{file_extension}"


async def test_upload_file():
    now = time.time()
    channel = grpc.aio.insecure_channel('127.0.0.1:50051')
    stub = nimbus_pb2_grpc.NimbusServiceStub(channel)

    try:
        local_path = f'/Users/george/Desktop/ChatGPT_Desktop_public_latest.dmg'
        file_name = generate_secret_file_name('ChatGPT_Desktop_public_latest.dmg')
        file_path = os.path.join('profile/dmg/zhangsan', file_name)

        request_iterator = file_request_iterator(local_path=local_path, file_path=file_path, file_name=file_name, bucket_name='public')
        async for response in stub.upload_file(request_iterator):
            if response.HasField('success'):
                print(f"{response.transfer_id}: {response.success.file_path} {response.success.file_name} - {response.success.status} - Transferred_bytes: {response.success.transferred_bytes}")
            elif response.HasField('error'):
                print(f'{response.transfer_id}: Error: grpc_status: {response.error.grpc_status}, error_code: {response.error.server_code}, message: {response.error.message}')

    except grpc.aio.AioRpcError as e:  # 捕获异步gRPC调用的错误
        print(f'gRPC call failed: {e}')

    print('耗时: ', time.time() - now)
    # 1.47G 无redis 1128.5906178951263
    # 1.47G 有redis 1214.262804031372
    # 耗时:  50.710277795791626
def main():
    asyncio.run(test_upload_file())
    
if __name__ == '__main__':
    main()


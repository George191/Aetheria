class ArgumentError(Exception):
    pass

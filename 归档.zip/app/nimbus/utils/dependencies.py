
import boto3
from botocore import client
from botocore.exceptions import ClientError, NoCredentialsError

UNEXPECTED_ERROR_MESSAGE = "An unexpected error occurred"

class StorageClient:
    
    def __init__(self, AWS_S3_ENDPOINT_URL, AWS_ACCESS_KEY_ID, AWS_SECRET_ACCESS_KEY):
        self.s3_client: client.BaseClient = boto3.client(
            "s3",
            endpoint_url=AWS_S3_ENDPOINT_URL,
            aws_access_key_id=AWS_ACCESS_KEY_ID,
            aws_secret_access_key=AWS_SECRET_ACCESS_KEY,
        )

    def ensure_bucket_exists(self, bucket_name: str):
        try:
            self.s3_client.head_bucket(Bucket=bucket_name)
        except ClientError:
            self.s3_client.create_bucket(Bucket=bucket_name)

    def upload_chunk(
        self, bucket_name, remote_path, file_chunk, part_num, upload_id=None, parts=None
    ):
        parts = parts or []
        self.ensure_bucket_exists(bucket_name=bucket_name)

        try:
            if upload_id is None:
                response = self.s3_client.create_multipart_upload(
                    Bucket=bucket_name, Key=remote_path
                )
                upload_id = response["UploadId"]

            response = self.s3_client.upload_part(
                Bucket=bucket_name,
                Key=remote_path,
                PartNumber=part_num,
                UploadId=upload_id,
                Body=file_chunk,
            )
            parts.append({"PartNumber": part_num, "ETag": response["ETag"]})
            return upload_id, parts
        
        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code == "403":
                raise ValueError(f"Access denied: {e}")
            else:
                raise ValueError(f"Unexpected error: {e}")
        except self.s3_client.exceptions.NoSuchBucket as e:
            raise ValueError(f"Bucket does not exist: {e}")
        except self.s3_client.exceptions.NoSuchKey as e:
            raise ValueError(f"Object does not exist: {e}")
        except self.s3_client.exceptions.NoSuchUpload:
            raise ValueError(f"The specified multipart upload does not exist: {e}")
        except NoCredentialsError as e:
            raise ClientError(f"Unable to locate credentials: {e}")
        except Exception as e:
            return f"{UNEXPECTED_ERROR_MESSAGE}: {str(e)}"
        
    def complete_upload(self, bucket_name, remote_path, upload_id, parts):
        try:
            self.s3_client.complete_multipart_upload(
                Bucket=bucket_name,
                Key=remote_path,
                UploadId=upload_id,
                MultipartUpload={"Parts": parts},
            )
            return f"{bucket_name}/{remote_path}"
        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code == "403":
                raise ValueError(f"Access denied: {e}")
            else:
                raise ValueError(f"Unexpected error: {e}")
        except self.s3_client.exceptions.NoSuchBucket as e:
            raise ValueError(f"Bucket does not exist: {e}")
        except self.s3_client.exceptions.NoSuchKey as e:
            raise ValueError(f"Object does not exist: {e}")
        except self.s3_client.exceptions.NoSuchUpload:
            raise ValueError(f"The specified multipart upload does not exist: {e}")
        except NoCredentialsError as e:
            raise ClientError(f"Unable to locate credentials: {e}")
        except Exception as e:
            return ClientError(f"{UNEXPECTED_ERROR_MESSAGE}: {str(e)}")
        
    def abort_upload(self, bucket_name, remote_path, upload_id):
        try:
            self.s3_client.abort_multipart_upload(
                Bucket=bucket_name,
                Key=remote_path,
                UploadId=upload_id,
            )
            return f"{bucket_name}/{remote_path}"
        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code == "403":
                raise ValueError(f"Access denied: {e}")
            else:
                raise ValueError(f"Unexpected error: {e}")
        except self.s3_client.exceptions.NoSuchBucket as e:
            raise ValueError(f"Bucket does not exist: {e}")
        except self.s3_client.exceptions.NoSuchKey as e:
            raise ValueError(f"Object does not exist: {e}")
        except self.s3_client.exceptions.NoSuchUpload:
            raise ValueError(f"The specified multipart upload does not exist: {e}")
        except NoCredentialsError as e:
            raise ClientError(f"Unable to locate credentials: {e}")
        except Exception as e:
            return ClientError(f"{UNEXPECTED_ERROR_MESSAGE}: {str(e)}")
    
    def _parse_path(self, remote_path):
        parts = remote_path.split("/", 1)
        if len(parts) == 2:
            return parts[0], parts[1]
        else:
            raise ValueError(
                """
                Invalid remote path format.
                Expected format 'bucket-name/path/file'
            """
            )

    def stat_object(self, remote_path):
        bucket_name, object_path = self._parse_path(remote_path)

        try:
            return self.s3_client.head_object(Bucket=bucket_name, Key=object_path)

        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code == "403":
                raise ValueError(f"Access denied: {e}")
            else:
                raise ValueError(f"Unexpected error: {e}")
        except self.s3_client.exceptions.NoSuchBucket as e:
            raise ValueError(f"Bucket does not exist: {e}")
        except self.s3_client.exceptions.NoSuchKey as e:
            raise ValueError(f"Object does not exist: {e}")
        except NoCredentialsError as e:
            raise ClientError(f"Unable to locate credentials: {e}")
        except Exception as e:
            raise ClientError(f"{UNEXPECTED_ERROR_MESSAGE}: {str(e)}")
        
    def get_object(self, remote_path, transferred_bytes: int=0):
        bucket_name, object_path = self._parse_path(remote_path)
        range_param = 'bytes={}-'.format(transferred_bytes)
        try:
            return self.s3_client.get_object(Bucket=bucket_name, Key=object_path, Range=range_param)
        except ClientError as e:
            error_code = e.response["Error"]["Code"]
            if error_code == "403":
                raise ValueError(f"Access denied: {e}")
            else:
                raise ValueError(f"Unexpected error: {e}")
        except self.s3_client.exceptions.NoSuchBucket as e:
            raise ValueError(f"Bucket does not exist: {e}")
        except self.s3_client.exceptions.NoSuchKey as e:
            raise ValueError(f"Object does not exist: {e}")
        except NoCredentialsError as e:
            raise ClientError(f"Unable to locate credentials: {e}")
        except Exception as e:
            raise ClientError(f"{UNEXPECTED_ERROR_MESSAGE}: {str(e)}")

from google.protobuf.json_format import MessageToDict


class MessageUtils:

    def __init__(self, response):
        self.response = response
        self.success_type_name = ""
        self.error_type_name = ""
        self.unknown_type_name = "InactivatedResponse"

    def set_success_type(self, type_name):
        self.success_type_name = type_name

    def set_error_type(self, type_name):
        self.error_type_name = type_name

    def to_dict(self):
        if self.response.HasField("success"):
            response_dict = MessageToDict(self.response.success, preserving_proto_field_name=True)
            response_dict['__typename'] = self.success_type_name
        elif self.response.HasField("error"):
            response_dict = MessageToDict(self.response.error, preserving_proto_field_name=True)
            response_dict['__typename'] = self.error_type_name
        else:
            response_dict = {}
            response_dict['__typename'] = self.unknown_type_name

        return {
            "transfer_id": self.response.transfer_id,
            "response": response_dict
        }
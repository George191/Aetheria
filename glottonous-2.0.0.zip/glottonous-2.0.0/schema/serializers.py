#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:33
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :serializers.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.contrib.auth.models import update_last_login
from django.contrib.auth.password_validation import validate_password
from django.conf import settings
from django.utils.encoding import force_text
from django.utils.http import urlsafe_base64_decode as uid_decoder
from django.contrib.auth.tokens import default_token_generator
from django.core.exceptions import ObjectDoesNotExist
from rest_framework_simplejwt.settings import api_settings

from schema.admin.permission.models import UserProfile
from schema.forms import PasswordResetForm, SetPasswordForm, EmailVerifyForm

from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer, TokenRefreshSerializer
from rest_framework.validators import UniqueValidator
from rest_framework.exceptions import ValidationError

from utils.operations.serializers import CustomModelSerializer


class ChangePasswordSerializer(CustomModelSerializer):
    """
    Serializer for password change endpoint.
    """
    old_password = serializers.CharField(required=True)
    new_password = serializers.CharField(required=True)

    class Meta:
        model = UserProfile
        fields = ('new_password', 'old_password')

    def validate_new_password(self, value):
        validate_password(value)
        return value


class ChangeStatusSerializer(CustomModelSerializer):
    """
    Serializer for change is_active endpoint.
    """
    status = serializers.CharField(required=True)
    email = serializers.EmailField(required=True)

    class Meta:
        model = UserProfile
        fields = ('status', )

# 用户注册
class UserRegSerializer(CustomModelSerializer):

    # validators 可以指明一些默认的约束类, 此处的 UniqueValidator 表示唯一约束限制不能重名
    username = serializers.CharField(label="用户名", help_text="用户名", required=True, allow_blank=False,
                                     validators=[UniqueValidator(queryset=UserProfile.objects.all(), message="用户已经存在")])

    password = serializers.CharField(
        style={'input_type': 'password'}, help_text="密码", label="密码", write_only=True,
    )

    email_verify_class = EmailVerifyForm

    class Meta:
        model = UserProfile
        fields = ("username", "email", "password")

    def create(self, validated_data):
        user = super(UserRegSerializer, self).create(validated_data=validated_data)
        user.set_password(validated_data["password"])
        user.save()
        return user

    def get_email_options(self):
        """Override this method to change default e-mail options"""
        return {}

    def save(self, **kwargs):

        assert hasattr(self, '_errors'), (
            'You must call `.is_valid()` before calling `.save()`.'
        )

        assert not self.errors, (
            'You cannot call `.save()` on a serializer with invalid data.'
        )

        # Guard against incorrect use of `serializer.save(commit=False)`
        assert 'commit' not in kwargs, (
            "'commit' is not a valid keyword argument to the 'save()' method. "
            "If you need to access data before committing to the database then "
            "inspect 'serializer.validated_data' instead. "
            "You can also pass additional keyword arguments to 'save()' if you "
            "need to set extra attributes on the saved model instance. "
            "For example: 'serializer.save(owner=request.user)'.'"
        )

        assert not hasattr(self, '_data'), (
            "You cannot call `.save()` after accessing `serializer.data`."
            "If you need to access data before committing to the database then "
            "inspect 'serializer.validated_data' instead. "
        )

        validated_data = {**self.validated_data, **kwargs}

        if self.instance is not None:
            self.instance = self.update(self.instance, validated_data)
            assert self.instance is not None, (
                '`update()` did not return an object instance.'
            )
        else:
            self.instance = self.create(validated_data)
            assert self.instance is not None, (
                '`create()` did not return an object instance.'
            )

        request = self.context.get('request')
        # Set some values to trigger the send_email method.
        opts = {
            'use_https': request.is_secure(),
            'from_email': getattr(settings, 'EMAIL_FROM'),
            'request': request,
        }
        opts.update(self.get_email_options())

        verify_form = self.email_verify_class(data=self.initial_data)

        if not verify_form.is_valid():
            raise serializers.ValidationError(self.reset_form.errors)

        verify_form.save(**opts)

        return self.instance


class PasswordResetSerializer(CustomModelSerializer):
    """
    Serializer for requesting a password reset e-mail.
    """
    email = serializers.EmailField()

    password_reset_form_class = PasswordResetForm

    class Meta:
        model = UserProfile
        fields = ("email", )

    def get_email_options(self):
        """Override this method to change default e-mail options"""
        return {}

    def validate_email(self, value):
        # Create PasswordResetForm with the serializer
        try:
            user = UserProfile.objects.get(email=self.initial_data['email'])
            self.reset_form = self.password_reset_form_class(data=self.initial_data)

            if not self.reset_form.is_valid():
                raise serializers.ValidationError(self.reset_form.errors)

            return value
        except ObjectDoesNotExist as e:
            raise serializers.ValidationError(e)

    def save(self):
        request = self.context.get('request')
        # Set some values to trigger the send_email method.
        opts = {
            'use_https': request.is_secure(),
            'from_email': getattr(settings, 'EMAIL_FROM'),
            'request': request,
        }

        opts.update(self.get_email_options())
        self.reset_form.save(**opts)
        

class PasswordResetConfirmSerializer(CustomModelSerializer):
    """
    Serializer for requesting a password reset e-mail.
    """
    new_password1 = serializers.CharField(max_length=128)
    new_password2 = serializers.CharField(max_length=128)
    uid = serializers.CharField()
    token = serializers.CharField()

    set_password_form_class = SetPasswordForm

    class Meta:
        model = UserProfile
        fields = ("new_password1", "new_password2", 'uid', 'token')

    def custom_validation(self, attrs):
        pass

    def validate(self, attrs):
        self._errors = {}

        # Decode the uidb64 to uid to get User object
        try:
            uid = force_text(uid_decoder(attrs['uid']))
            self.user = UserProfile._default_manager.get(pk=uid)
        except (TypeError, ValueError, OverflowError, UserProfile.DoesNotExist):
            raise ValidationError({'uid': ['Invalid value']})

        self.custom_validation(attrs)
        # Construct SetPasswordForm instance
        self.set_password_form = self.set_password_form_class(
            user=self.user, data=attrs
        )
        if not self.set_password_form.is_valid():
            raise serializers.ValidationError(self.set_password_form.errors)
        if not default_token_generator.check_token(self.user, attrs['token']):
            raise ValidationError({'token': ['Invalid value']})

        return attrs

    def save(self):
        return self.set_password_form.save()


class AuthTokenObtainPairSerializer(TokenObtainPairSerializer):

    def validate(self, attrs):
        data = super().validate(attrs)

        refresh = self.get_token(self.user)

        data['refresh'] = str(refresh)
        data['access'] = str(refresh.access_token)

        if api_settings.UPDATE_LAST_LOGIN:
            update_last_login(None, self.user)

        return data

    


#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:05
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :urls.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from rest_framework.routers import DefaultRouter

from schema.core.verifier.views import SeedBankViewSet, SpiderLogViewSet

from django.urls import re_path


router = DefaultRouter()
router.register(r'seed_bank', SeedBankViewSet)
router.register(r'seed_log', SpiderLogViewSet)


urlpatterns = [
    re_path('seed_log/export/', SpiderLogViewSet.as_view({'get': 'export', })),
    re_path('seed_bank/export/', SeedBankViewSet.as_view({'get': 'export', })),
    re_path('seed_bank/importTemplate/', SeedBankViewSet.as_view({'get': 'importTemplate', 'post': 'importTemplate'})),

    re_path('seed_bank/publish_to_me/', SeedBankViewSet.as_view({'get': 'publish_to_me', })),

    re_path('seed_log/publish_task/', SpiderLogViewSet.as_view({'put': 'publish_task', })),
    re_path('seed_log/publish_from_me/', SpiderLogViewSet.as_view({'get': 'publish_from_me', })),
    re_path('seed_log/publish_to_me/', SpiderLogViewSet.as_view({'get': 'publish_to_me', })),

    re_path('seed_log/spider_start/(?P<secret>.*)/', SpiderLogViewSet.as_view({'get': 'spider_start', })),
    re_path('seed_log/spider_finish/(?P<secret>.*)/', SpiderLogViewSet.as_view({'get': 'spider_finish', })),
]

urlpatterns += router.urls
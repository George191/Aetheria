#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:05
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :serializers.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from rest_framework import serializers
from utils.operations.serializers import CustomModelSerializer

from schema.core.verifier.models import SeedBank, SpiderLog


class SeedBankSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = SeedBank
        exclude = ('modifier',)


class SeedBankCreateUpdateSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = SeedBank
        fields = '__all__'


class ExportSeedBankSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = SeedBank
        fields = ('account', 'homepage', 'name', 'batch', 'description', 'creator', 'create_datetime')


class SeedBankImportSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    def save(self, **kwargs):
        data = super().save(**kwargs)
        batch = SpiderLogSerializer.create({
            'seed_count': len(kwargs['account']),
            'wave_house': 0,
        })
        data.batch = batch
        return data

    def run_validation(self, data=None):
        return super().run_validation(data=data)

    class Meta:
        model = SeedBank
        fields = ('account', 'homepage', 'name', 'description')


class SpiderLogSerializer(CustomModelSerializer):

    tag = serializers.CharField(source='get_tag_display')
    wave_house = serializers.CharField(source='get_wave_house_display')
    spider_source = serializers.CharField(source='get_spider_source_display')

    class Meta:
        model = SpiderLog
        exclude = ('modifier',)


class SpiderLogCreateUpdateSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """

    class Meta:
        model = SpiderLog
        fields = '__all__'


class ExportSpiderLogSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = SpiderLog
        fields = ('id', 'tag', 'seed_count', 'timeline_recall', 'timeline_count', 'user_recall', \
            'user_count', 'friend_recall', 'friend_count', 'secret', 'batch', 'object_number', 'wave_house', 'publish_to', \
            'description', 'creator', 'create_datetime')

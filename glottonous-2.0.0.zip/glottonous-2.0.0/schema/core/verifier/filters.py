#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:02
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :filters.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


import django_filters
from admin.verifier.models import SeedBank, SpiderLog


class SeedBankFilter(django_filters.rest_framework.FilterSet):
    """[summary]

    Args:
        django_filters ([type]): [description]
    """
    name = django_filters.CharFilter(lookup_expr='icontains')

    class Meta:
        model = SeedBank
        exclude = ('description', 'creator', 'modifier')


class SpiderLogFilter(django_filters.rest_framework.FilterSet):
    """[summary]

    Args:
        django_filters ([type]): [description]
    """
    name = django_filters.CharFilter(lookup_expr='icontains')

    class Meta:
        model = SpiderLog
        exclude = ('description', 'creator', 'modifier')
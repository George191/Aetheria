#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:05
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :views.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from utils.operations.viewsets import CustomModelViewSet
from utils.operations.filters import DataLevelPermissionsFilter
from schema.core.verifier.serializers import SeedBankSerializer, SpiderLogSerializer, SeedBankCreateUpdateSerializer, \
    ExportSeedBankSerializer, SpiderLogCreateUpdateSerializer, ExportSpiderLogSerializer, SeedBankImportSerializer
from schema.core.verifier.models import SeedBank, SpiderLog
# from apps.core.verifier.filters import SeedBankFilter, SpiderLogFilter
from schema.admin.permission.permissions import CommonPermission
from schema.core.verifier.tasks import identify

from rest_framework.request import Request

from django.contrib.auth import get_user_model
from django.shortcuts import get_list_or_404 as _get_object_or_404
from utils.exceptions import APIException
from django.core.exceptions import ValidationError
from django.http.response import Http404
from utils.response import SuccessResponse, ErrorResponse

UserProfile = get_user_model()

# Create your views here.

def get_object_or_404(queryset, *filter_args, **filter_kwargs):
    try:
        return _get_object_or_404(queryset, *filter_args, **filter_kwargs)[0]
    except (TypeError, ValueError, ValidationError, Http404):
        raise APIException(message='该对象不存在或者无访问权限')


class SeedBankViewSet(CustomModelViewSet):
    """[summary]

    Args:
        CustomModelViewSet ([type]): [description]
    """
    queryset = SeedBank.objects.filter()
    serializer_class = SeedBankSerializer
    create_serializer_class = SeedBankCreateUpdateSerializer
    update_serializer_class = SeedBankCreateUpdateSerializer
    # filter_class = SeedBankFilter
    extra_filter_backends = [DataLevelPermissionsFilter]
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    search_fields = ('account', 'name', 'description')
    ordering = '-create_datetime'
    export_field_data = ['账户序号', '账户id', '账户主页', '账户名称', '目标编号', '批次数', '描述', '创建人', '创建时间']
    export_serializer_class = ExportSeedBankSerializer
    import_serializer_class = SeedBankImportSerializer
    import_field_data = {'account': '账号', 'homepage': '主页', 'name': '昵称', 'description': '描述'}
    lookup_field = 'secret'

    def publish_to_me(self, request: Request, *args, **kwargs):
        """
        发布给我
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        secret_list = list(SpiderLog.objects.filter(publish_to_id=request.user.id).values_list('secret', flat=True))

        instance = self.queryset.filter(confirm=False, batch__in=secret_list)
        serializer = self.get_serializer(instance, many=True)
        if hasattr(self, 'handle_logging'):
            self.handle_logging(request, *args, **kwargs)
        return SuccessResponse(serializer.data)


class SpiderLogViewSet(CustomModelViewSet):
    """[summary]

    Args:
        CustomModelViewSet ([type]): [description]
    """
    lookup_field = 'secret'
    queryset = SpiderLog.objects.filter()
    serializer_class = SpiderLogSerializer
    create_serializer_class = SpiderLogCreateUpdateSerializer
    update_serializer_class = SpiderLogCreateUpdateSerializer
    # filter_class = SpiderLogFilter
    extra_filter_backends = [DataLevelPermissionsFilter]
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    search_fields = ('description', 'secret')
    ordering = '-create_datetime'
    export_field_data = ['账户序号', '是否发布', '种子数量', '帖子采集比例', '帖子采集数量', '账号采集比例', '账号采集数量', '好友采集比例', '好友采集数量', \
        '唯标识', '批次数', '对象编号', '入库方式', '采集人', '描述', '创建人', '创建时间']
    export_serializer_class = ExportSpiderLogSerializer
    lookup_field = 'secret'

    def publish_task(self, request: Request, *args, **kwargs):
        """
        发布任务
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        publish_to = request.data.get('publish_to')
        secret = request.data.get('secret')

        publish_queryset = get_object_or_404(self.queryset, secret=secret, tag=0)
        if publish_queryset.batch < 4:# 修改灵活
            publish_queryset.publish_to = UserProfile.objects.filter(pk=publish_to).first()
            publish_queryset.tag = 1
            publish_queryset.batch += 1
            publish_queryset.save()

            if hasattr(self, 'handle_logging'):
                self.handle_logging(request, *args, **kwargs)
            return SuccessResponse()
        return ErrorResponse(msg='当前批次数据已达最大批次数，已无法发布！')

    def publish_from_me(self, request: Request, *args, **kwargs):
        """
        我的发布
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        instance = self.queryset.filter(creator=request.user.id, tag__in=[1, 2, 3, 4])
        serializer = self.get_serializer(instance, many=True)
        if hasattr(self, 'handle_logging'):
            self.handle_logging(request, *args, **kwargs)
        return SuccessResponse(serializer.data)

    def publish_to_me(self, request: Request, *args, **kwargs):
        """
        发布给我
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        instance = self.queryset.filter(publish_to_id=request.user.id, tag__in=[1, 2, 3, 4])
        serializer = self.get_serializer(instance, many=True)
        if hasattr(self, 'handle_logging'):
            self.handle_logging(request, *args, **kwargs)
        return SuccessResponse(serializer.data)

    def spider_start(self, request: Request, *args, **kwargs):
        """
        开始采集
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        instance = self.queryset.get(secret=kwargs.get('secret'), tag=1, publish_to_id=request.user.id)
        instance.tag = 2
        instance.save()
        serializer = self.get_serializer(instance)
        if hasattr(self, 'handle_logging'):
            self.handle_logging(request, *args, **kwargs)
        return SuccessResponse(serializer.data)
    
    def spider_finish(self, request: Request, *args, **kwargs):
        """
        采集完成
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        secret = kwargs.get('secret')
        instance = self.queryset.get(secret=secret, tag=2, publish_to_id=request.user.id)
        instance.tag = 3
        instance.save()
        serializer = self.get_serializer(instance)

        account = SeedBank.objects.filter(batch=kwargs.get('secret'), confirm=False).values_list('account', 'batch__object_number__obj_num', 'batch__object_number__obj_typ')
        if account:
            identify.delay(list(account), kwargs.get('secret'))
            if hasattr(self, 'handle_logging'):
                self.handle_logging(request, *args, **kwargs)
            return SuccessResponse(serializer.data)
        return ErrorResponse(msg='该批次暂无可验证账号！')

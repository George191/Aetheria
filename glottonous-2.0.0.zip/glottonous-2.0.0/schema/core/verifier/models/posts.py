'''
Author: your name
Date: 2022-02-11 08:50:40
LastEditTime: 2022-04-12 16:39:21
LastEditors: your name
Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
FilePath: /backend/apps/core/verifier/models/posts.py
'''
#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:02
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :posts.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.db import models
from django.utils.translation import ugettext_lazy as _

from utils.operations.models import CoreModel


class Posts(CoreModel):
    post_id = models.PositiveBigIntegerField(_('帖子ID'), blank=True, null=True)
    post_url = models.URLField(_('帖子链接'), max_length=255, blank=True, null=True)
    title = models.CharField(_('帖子标题'), max_length=255, blank=True, null=True)
    content = models.TextField(_('帖子正文'), blank=True, null=True)
    account = models.PositiveBigIntegerField(_('发帖人账号'), blank=True, null=True)
    account_homepage = models.URLField(_('发帖人账号链接'), max_length=1024, blank=True, null=True)
    account_name = models.CharField(_('发帖人全名'), max_length=255, blank=True, null=True)
    account_jumpname = models.CharField(_('发帖人跳转名称'), max_length=255, blank=True, null=True)
    profile_picture_url = models.URLField(_('profile_picture_url'), max_length=1024, blank=True, null=True)
    share_account = models.PositiveBigIntegerField(_('被分享人的账号'), blank=True, null=True)
    share_account_name = models.CharField(_('被分享人的名字'), max_length=255, blank=True, null=True)
    share_account_homepage = models.URLField(_('被分享人的主页'), max_length=1024, blank=True, null=True)
    share_post_title_ranges = models.TextField(_('分享帖子标题中的标签'), blank=True, null=True)
    share_post_url = models.URLField(_('分享帖子链接'), max_length=255, blank=True, null=True)
    share_post_time = models.DateTimeField(_('分享贴的发布时间'), blank=True, null=True)
    share_post_ranges = models.TextField(_('帖子标题中的标签'), blank=True, null=True)
    post_time = models.DateTimeField(_('发帖时间'), blank=True, null=True)
    share_title = models.CharField(_('分享帖子的标题'), max_length=255, blank=True, null=True)
    share_jump_name = models.CharField(_('跳转名字'), max_length=1024, blank=True, null=True)
    share_post_attach = models.TextField(_('图片或者视频'), blank=True, null=True)
    post_ranges = models.TextField(_('帖子中的标签'), blank=True, null=True)
    post_title_ranges = models.TextField(_('帖子标题中的标签'), blank=True, null=True)
    post_num = models.TextField(_('包含评论数、点赞数等'), blank=True, null=True)
    post_attach = models.TextField(_('图片或者视频'), blank=True, null=True)
    share_content = models.TextField(_('分享帖子内容'), blank=True, null=True)
    location = models.CharField(_('帖子的地点'), max_length=255, blank=True, null=True)
    longitude = models.FloatField(_('经度'), blank=True, null=True)
    latitude = models.FloatField(_('纬度'), blank=True, null=True)
    comment_count = models.PositiveIntegerField(_("评论数"), blank=True, null=True)
    share_count = models.PositiveIntegerField(_('分享数'), blank=True, null=True)
    like_count = models.PositiveIntegerField(_('点赞数'), blank=True, null=True)
    is_shared = models.BooleanField(_('是否转发的帖子'), blank=True, null=True)
    is_handled = models.BooleanField(_('是否已经处理过'), default=False, blank=True, null=True)
    source = models.CharField(_('来源'), max_length=255, blank=True, null=True)
    title_cn = models.CharField(_('中文标题'), blank=True, null=True, max_length=255)
    content_cn = models.TextField(_('中文正文'), blank=True, null=True)
    share_title_cn = models.CharField(_('中文分享标题'), blank=True, null=True, max_length=255)
    share_content_cn = models.TextField(_('中文分享正文'), blank=True, null=True)
    object_number = models.CharField(_('服役目标的编号'), max_length=50, blank=True, null=True)
    batch = models.CharField(_('批次'), max_length=238)

    class Meta:
        verbose_name = verbose_name_plural = '验证帖子'
        db_table = 'verifier_post'

    def __str__(self):
        return self.post_id
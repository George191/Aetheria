#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:02
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :account.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.db import models
from django.utils.translation import ugettext_lazy as _

from utils.operations.models import CoreModel


class Account(CoreModel):
    account = models.PositiveBigIntegerField(_('账号ID'), blank=True, null=True)
    name = models.CharField(_('账号全名'), max_length=255, blank=True, null=True)
    jumpname = models.CharField(_('跳转名称（青岛采集）'), max_length=255, blank=True, null=True)
    nickname = models.CharField(_('账号昵称'), max_length=255, blank=True, null=True)
    homepage = models.CharField(_('主页链接'), max_length=1024, blank=True, null=True)
    register_time = models.DateTimeField(_('账号注册时间'), blank=True, null=True)
    gender = models.CharField(_('性别'), max_length=10, blank=True, null=True)
    birthday = models.DateTimeField(_('出生日期'), blank=True, null=True)
    sexual_orientation = models.CharField(_('性取向'), max_length=10, blank=True, null=True)
    language = models.CharField(_('语言'), max_length=255, blank=True, null=True)
    marital_status = models.CharField(_('婚姻状况'), max_length=255, blank=True, null=True)
    hometown = models.CharField(_('家乡'), max_length=255, blank=True, null=True)
    current_residence = models.CharField(_('现居住地'), max_length=255, blank=True, null=True)
    work_experience = models.CharField(_('工作经历'), max_length=1024, blank=True, null=True)
    edu_experience = models.CharField(_('教育经历'), max_length=1024, blank=True, null=True)
    family_info = models.CharField(_('家庭成员信息'), max_length=1024, blank=True, null=True)
    life_chronicle = models.CharField(_('生活纪事'), max_length=1024, blank=True, null=True)
    object_number = models.CharField(_('服役目标的编号'), max_length=50, blank=True, null=True)
    images = models.TextField(_('图片'), blank=True, null=True)
    overview = models.TextField(_('青岛采集'), blank=True, null=True)
    places = models.TextField(_('青岛采集'), blank=True, null=True)
    life_events = models.TextField(_('青岛采集'), blank=True, null=True)
    details = models.TextField(_('青岛采集'), blank=True, null=True)
    family_and_relations = models.TextField(_('青岛采集'), blank=True, null=True)
    contact_and_basicinfo = models.TextField(_('青岛采集'), blank=True, null=True)
    work_and_edu = models.TextField(_('青岛采集'), blank=True, null=True)
    identity_status = models.IntegerField(_('身份状态'), default=0, blank=True, null=True)
    object_type = models.CharField(_('服役目标的类型：ship, base'), max_length=64, blank=True, null=True)
    source = models.CharField(_('来源'), max_length=255, blank=True, null=True)
    
    class Meta:
        verbose_name = verbose_name_plural = '验证用户'
        db_table = 'verifier_user'

    def __str__(self):
        return self.name
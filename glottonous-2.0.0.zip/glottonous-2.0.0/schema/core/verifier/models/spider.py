#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:02
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :spider.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.db import models
from django.utils.translation import ugettext_lazy as _
from multiselectfield import MultiSelectField
from uuid import uuid4

from utils.operations.models import CoreModel

# Create your models here.

class SpiderLog(CoreModel):

    TAG_CHOICES = ((0, '待发布'), (1, '已发布'), (2, '采集中'), (3, '待验证'), (4, '已完成'))
    WAVE_CHOICES = ((0, '工人导入'), (1, '系统验证'))
    SPIDER_CHOICE = ((0, '帖子'), (1, '个人信息'), (2, '好友'))

    tag = models.SmallIntegerField(_('任务状态'), default=0, choices=TAG_CHOICES)
    seed_count = models.PositiveIntegerField(_('种子数量'), default=0)

    spider_log = models.JSONField(_('采集日志'))

    secret = models.SlugField(max_length=255, default=uuid4, verbose_name=_('加密秘钥'), unique=True)
    batch = models.PositiveSmallIntegerField(_('批次数'), default=0)
    object_number = models.ForeignKey(to='verifier.ObjectNumber', on_delete=models.SET_NULL, verbose_name=_('目标'), null=True, related_name='publish_obj')
    wave_house = models.SmallIntegerField(_("入库方式"), choices=WAVE_CHOICES)
    publish_to = models.ForeignKey(to='permission.UserProfile', on_delete=models.SET_NULL, verbose_name=_('采集人'), null=True, related_name='publish_to')
    spider_source = MultiSelectField(_("采集来源"), choices=SPIDER_CHOICE)

    class Meta:
        verbose_name = verbose_name_plural = '发布日志'
        db_table = 'verifier_log'

    def __str__(self):
        return f'{self.secret}-{self.batch}'
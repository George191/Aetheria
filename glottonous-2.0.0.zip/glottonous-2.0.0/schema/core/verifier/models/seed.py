#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:02
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :seed.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.db import models
from django.utils.translation import ugettext_lazy as _

from utils.operations.models import CoreModel


# Create your models here.

class SeedBank(CoreModel):
    
    account = models.PositiveBigIntegerField(_('账户id'), unique=True)
    homepage = models.URLField(_("主页"), max_length=256, blank=True, null=True)
    name = models.CharField(_('姓名'), max_length=64, blank=True, null=True)
    batch = models.ForeignKey(to='verifier.SpiderLog', on_delete=models.CASCADE, verbose_name=_('批次数'),to_field='secret')
    confirm = models.BooleanField(_('是否确认'), default=False)
    
    class Meta:
        verbose_name = verbose_name_plural = '验证种子'
        db_table = 'verifier_seed'

    def __str__(self):
        return str(self.account)
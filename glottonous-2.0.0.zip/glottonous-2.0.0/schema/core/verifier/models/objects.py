#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:02
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :objects.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.db import models
from django.utils.translation import ugettext_lazy as _

from utils.operations.models import CoreModel


# Create your models here.

class ObjectNumber(CoreModel):
    
    name = models.CharField(_("名称"), max_length=64)
    obj_num = models.CharField(_("对象编号"), max_length=64)
    mod_num = models.CharField(_("对象型号"), max_length=64)
    obj_typ = models.CharField(_("对象类型"), max_length=64)
    
    class Meta:
        verbose_name = verbose_name_plural = '验证目标'
        db_table = 'verifier_objects'

    def __str__(self):
        return '{}-{}-{}'.format(self.obj_typ, self.obj_num, self.name)
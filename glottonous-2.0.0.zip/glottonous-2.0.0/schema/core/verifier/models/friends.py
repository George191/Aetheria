#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:02
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :friends.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.db import models
from django.utils.translation import ugettext_lazy as _

from utils.operations.models import CoreModel


class Friends(CoreModel):
    source_account = models.PositiveBigIntegerField(_('源用户ID'), blank=True, null=True)
    account = models.PositiveBigIntegerField(_('好友账号ID'), blank=True, null=True)
    name = models.CharField(_('好友账号全名'), max_length=255, blank=True, null=True)
    title = models.CharField(_('好友头衔'), max_length=255, blank=True, null=True)
    atname = models.CharField(_('@name'), max_length=255, blank=True, null=True)
    homepage = models.CharField(_('好友主页链接'), max_length=255, blank=True, null=True)
    category = models.CharField(_('好友分类'), max_length=255, blank=True, null=True)
    avatar = models.CharField(_('好友头像链接'), max_length=255, blank=True, null=True)
    source = models.CharField(_('来源'), max_length=255, blank=True, null=True)
    
    class Meta:
        verbose_name = verbose_name_plural = '验证好友'
        db_table = 'verifier_friend'
    
    def __str__(self):
        return self.name
#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:05
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :tasks.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from scripts.identification import Identification
from utils.decorators import BaseCeleryApp


@BaseCeleryApp(name='apps.core.verify.tasks.identify', save_success_logs=False)
def identify(names=None, secret=None):
    """Celery 任务，用于验证人员 确认身份"""
    assert secret, "Can't Found Task Secret. "
    Identification(names, secret)

        
#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:05
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :urls.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from rest_framework.routers import DefaultRouter

from schema.core.crawler.views import AuthenticationViewSet, CollectedViewSet, MirrorViewSet, RecorderViewSet

from django.urls import re_path


router = DefaultRouter()
router.register(r'crawler_authent', AuthenticationViewSet)
router.register(r'crawler_collected', CollectedViewSet)
router.register(r'crawler_mirror', MirrorViewSet)
router.register(r'crawler_recorder', RecorderViewSet)


urlpatterns = [
    re_path('crawler_authent/export/', AuthenticationViewSet.as_view({'get': 'export', })),
    re_path('crawler_recorder/export/', RecorderViewSet.as_view({'get': 'export', })),
    re_path('crawler_collected/export/', CollectedViewSet.as_view({'get': 'export', })),

    re_path('crawler_recorder/(?P<recorder>.*)/get_instance/', RecorderViewSet.as_view({'get': 'get_instance', })),

    re_path('crawler_authent/importTemplate/', AuthenticationViewSet.as_view({'get': 'importTemplate', 'post': 'importTemplate'})),
]

urlpatterns += router.urls





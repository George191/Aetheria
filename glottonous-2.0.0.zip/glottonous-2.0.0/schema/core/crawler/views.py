#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:05
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :views.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from utils.operations.viewsets import CustomModelViewSet
from utils.response import SuccessResponse, ErrorResponse
from utils.operations.filters import DataLevelPermissionsFilter
from schema.core.crawler.serializers import (
  AuthenticationSerializer, AuthenticationExportSerializer, AuthenticationImportSerializer, CollectedSerializer, 
  CollectedExportSerializer, MirrorSerializer, InstanceSerializer, RecorderSerializer, AuthenticationCreateSerializer,
  CollectedCreateSerializer, RecorderCreateSerializer, RecorderExportSerializer
)
from schema.core.crawler.models import Authentication, Collected, Mirror, Instance, Recorder
# from apps.core.verifier.filters import 
from schema.admin.permission.permissions import CommonPermission

from rest_framework.request import Request


class AuthenticationViewSet(CustomModelViewSet):
    """[summary]

    Args:
        CustomModelViewSet ([type]): [description]
    """
    queryset = Authentication.objects.filter()
    serializer_class = AuthenticationSerializer
    create_serializer_class = AuthenticationCreateSerializer
    update_serializer_class = AuthenticationCreateSerializer
    # filter_class = 
    extra_filter_backends = [DataLevelPermissionsFilter]
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    search_fields = ('username', 'email_username')
    ordering = '-create_datetime'
    export_serializer_class = AuthenticationExportSerializer
    import_serializer_class = AuthenticationImportSerializer
    import_field_data = {
      'username': '用户名', 'password': '密码', 'validcode': '验证码', 'email_username': '邮箱', 
      'email_password': '邮箱密码', 'hometown': '家乡', 'status': '状态', 'rank': '等级', 
      'owner': '归属人', 'description': '描述'
    }
    export_field_data = [
      '用户名', '密码', '验证码', '邮箱', '邮箱密码', '家乡', '状态', '等级', '归属人', '描述'
    ]
    lookup_field = 'secret'


class CollectedViewSet(CustomModelViewSet):
    """[summary]

    Args:
        CustomModelViewSet ([type]): [description]
    """
    queryset = Collected.objects.filter()
    serializer_class = CollectedSerializer
    create_serializer_class = CollectedCreateSerializer
    update_serializer_class = CollectedCreateSerializer
    # filter_class = 
    extra_filter_backends = [DataLevelPermissionsFilter]
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    search_fields = ('account', 'homepage', 'description')
    ordering = '-create_datetime'
    export_serializer_class = CollectedExportSerializer
    export_field_data = [
      '账号ID', '主页URI', '采集难易程度', '描述'
    ]
    lookup_field = 'secret'


class MirrorViewSet(CustomModelViewSet):
    """[summary]

    Args:
        CustomModelViewSet ([type]): [description]
    """
    queryset = Mirror.objects.filter()
    serializer_class = MirrorSerializer
    create_serializer_class = RecorderCreateSerializer
    update_serializer_class = RecorderCreateSerializer
    # filter_class = 
    extra_filter_backends = [DataLevelPermissionsFilter]
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    search_fields = ('name', )
    ordering = '-create_datetime'
    lookup_field = 'secret'


class RecorderViewSet(CustomModelViewSet):
    """[summary]

    Args:
        CustomModelViewSet ([type]): [description]
    """
    queryset = Recorder.objects.filter()
    serializer_class = RecorderSerializer
    create_serializer_class = RecorderCreateSerializer
    update_serializer_class = RecorderCreateSerializer
    # filter_class = 
    extra_filter_backends = [DataLevelPermissionsFilter]
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    ordering = '-create_datetime'
    export_serializer_class = RecorderExportSerializer
    export_field_data = [
      '开始时间', '结束时间', '采集来源', '采集方式', '采集类别', '保存方式', '是否翻译', '排序', '镜像', '描述'
    ]
    lookup_field = 'secret'

    def get_instance(self, request: Request, *args, **kwargs):
        """
        发布给我
        :param request:
        :param args:
        :param kwargs:
        :return:
        """
        instance = Instance.objects.filter(recorder=kwargs.get('recorder'))
        serializer = InstanceSerializer(instance, many=True)
        if hasattr(self, 'handle_logging'):
            self.handle_logging(request, *args, **kwargs)
        return SuccessResponse(serializer.data)

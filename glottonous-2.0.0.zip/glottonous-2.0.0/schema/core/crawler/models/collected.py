#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:02
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :seed.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.db import models
from django.utils.translation import ugettext_lazy as _

from utils.operations.models import CoreModel


# Create your models here.

class Collected(CoreModel):
    
    account = models.PositiveBigIntegerField(_('账户id'), unique=True, null=True, blank=True)
    homepage = models.URLField(_("主页"), max_length=255, blank=False, null=False, unique=True)
    hard_rank = models.PositiveSmallIntegerField(_('采集困难程度'), null=False, blank=False, default=0) # 0 ~ ... 可以定义每次采集每组总分为N 组内账号该字段不大于N

    class Meta:
        verbose_name = verbose_name_plural = '被采集账号'
        db_table = 'crawler_collected'

    def __str__(self):
        return str(self.account)
#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:02
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :friends.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.db import models
from django.conf import settings
from django.utils.translation import ugettext_lazy as _
from uuid import uuid4
from utils.operations.models import CoreModel


class Authentication(CoreModel):

    ACTIVE_STATUS = ((0, '待使用'), (1, '正在采集'), (2, '正在养号'), (3, '采集完成'), (4, '冻结'), (5, '禁用'))


    secret = models.SlugField(max_length=255, default=uuid4, verbose_name=_('加密秘钥'), unique=True)
    username = models.CharField(_('用户名'), max_length=64, null=False)
    password = models.CharField(_('登录密码'), max_length=128, null=False)
    validcode = models.CharField(_('二次验证key'), max_length=32, null=False)
    email_username = models.EmailField(_('邮箱用户名'), max_length=32, null=True)
    email_password = models.CharField(_('邮箱密码'), max_length=128, null=True)
    hometown = models.CharField(_('账号所在地'), max_length=128, null=True)
    status = models.PositiveSmallIntegerField(_('帐号状态'), null=False, default=0, choices=ACTIVE_STATUS)
    rank = models.PositiveSmallIntegerField(_('账号等级'), default=0, null=False)
    owner = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL,
                               verbose_name='所属人', related_name='account_owner', null=True)
    
    class Meta:
        verbose_name = verbose_name_plural = '采集鉴权账号'
        db_table = 'crawler_authentication'
    
    def __str__(self):
        return self.name
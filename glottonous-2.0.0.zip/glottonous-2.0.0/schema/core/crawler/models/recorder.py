#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:02
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :spider.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.db import models
from django.utils.translation import ugettext_lazy as _
from multiselectfield import MultiSelectField
from uuid import uuid4
from django_minio_backend import MinioBackend
import os
from utils.operations.models import CoreModel

# Create your models here.

def spider_results(instance, file_name):
    return os.path.join('user', instance.username, 'spider', f'{uuid4()}{os.path.splitext(file_name)[-1]}')


class Recorder(CoreModel):

    STATUS_CHOICES = ((0, '待发布'), (1, '已发布'), (2, '采集中'), (3, '验证中'), (4, '已完成'))
    WAVE_CHOICES = ((0, '工人导入'), (1, '系统验证'))
    
    SPIDER_CATEGORY = ((0, '个人'), (1, '公共'))

    # 如果个人都可以采集， 如果是公共只能采集帖子
    SPIDER_SOURCE = ((0, '帖子'), (1, '个人信息'), (2, '好友'))
    
    # 当采集帖子会有如下选项
    SPIDER_METHOD = ((0, '日增'), (1, '历史'))

    # 当采集历史会有如下选项
    start_time = models.DateTimeField(_('采集开始时间'), null=True, blank=True)
    end_time = models.DateTimeField(_('采集结束时间'), null=True, blank=True)

    secret = models.SlugField(max_length=255, default=uuid4, verbose_name=_('加密秘钥'), unique=True)
    spider_source = MultiSelectField(_("采集来源"), choices=SPIDER_SOURCE, min_choices=0)
    spider_method = MultiSelectField(_("采集方式"), choices=SPIDER_METHOD, min_choices=0)
    spider_category = models.PositiveSmallIntegerField(_("采集类型"), choices=SPIDER_CATEGORY, null=False)
    wave_house = models.PositiveSmallIntegerField(_("入库方式"), choices=WAVE_CHOICES)
    status = models.PositiveSmallIntegerField(_("任务状态"), choices=STATUS_CHOICES)
    spider_result = models.FileField(_('采集结果'), storage=MinioBackend(bucket_name='public'), upload_to=spider_results, null=True)
    spider_result = models.FileField(_('采集结果'), upload_to=spider_results, null=True)
    is_translate = models.BooleanField(_('是否需要翻译'), default=0, null=False)
    rank = models.PositiveSmallIntegerField(_('排序'), blank=False, null=False, default=11) # 重要|紧急组合方式 重要又紧急11、重要不紧急10, 不重要紧急01，不重要不紧急00

    mirror = models.ForeignKey(to='crawler.Mirror', to_field='secret', on_delete=models.SET_NULL, null=True)

    class Meta:
        verbose_name = verbose_name_plural = '采集任务'
        db_table = 'crawler_recorder'

    def __str__(self):
        return f'{self.spider_source}-{self.spider_type}-{self.secret}'
#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:02
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :friends.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.db import models
from django.utils.translation import ugettext_lazy as _
from uuid import uuid4

from utils.operations.models import CoreModel, BaseModel


class Mirror(CoreModel):
    SYSTEM_CHOICES = ((0, 'Windows Server'), (1, 'Red Hat Enterprsie Linux'))
    DISK_CHOICES = ((0, 'SSD云盘'), (1, '高效云盘'),  (2, '普通云盘'))
    AREA_CHOICES = ((0, '华北'), (1, '华东'),  (2, '华西'), (2, '华南'), (2, '华中'))

    secret = models.SlugField(max_length=255, default=uuid4, verbose_name=_('加密秘钥'), unique=True)
    op_sys = models.PositiveSmallIntegerField(_('操作系统'), null=False, choices=SYSTEM_CHOICES, default=0)
    op_disk = models.PositiveSmallIntegerField(_('磁盘类型'), null=False, choices=DISK_CHOICES, default=0)
    disk_capacity = models.PositiveSmallIntegerField(_('磁盘容量/GB'), null=False, default=40)
    is_encryption = models.BooleanField(_('是否加密'), default=False, null=False)
    name = models.CharField(_('镜像名称'), null=False, max_length=64)
    area = models.PositiveSmallIntegerField(_('目标地域'), null=False, choices=AREA_CHOICES, default=0)

    
    class Meta:
        verbose_name = verbose_name_plural = 'ECS镜像'
        db_table = 'crawler_mirror'
    
    def __str__(self):
        return self.name


class Instance(BaseModel):
    INTANCE_STATUS = ((0, '等待执行'), (1, '正在执行'), (2, '执行完成'), (3, '以释放'), (4, '实例异常'))

    secret = models.SlugField(max_length=255, default=uuid4, verbose_name=_('加密秘钥'), unique=True)

    allocation_id = models.CharField(_('阿里云弹性IP id'), max_length=128, null=False, blank=False)
    disk_id = models.CharField(_('磁盘 id'), max_length=128, null=False, blank=False)

    eip_addr = models.GenericIPAddressField(_('阿里云弹性IP地址'), max_length=32, null=False, blank=False)
    net_stats = models.CharField(_('网络类型'), max_length=32, null=True, blank=True)
    sys_conf = models.CharField(_('配置'), max_length=256, null=True)
    status = models.PositiveSmallIntegerField(_('实例状态'), null=False, blank=False, choices=INTANCE_STATUS)
    recorder = models.ForeignKey(to='crawler.Recorder', on_delete=models.CASCADE)

    class Meta:
      verbose_name = verbose_name_plural = 'ECS实例'
      db_table = 'crawler_instance'

    def __str__(self):
      return self.secret
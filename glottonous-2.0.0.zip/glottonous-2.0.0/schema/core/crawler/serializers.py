#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:05
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :serializers.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from rest_framework import serializers
from utils.operations.serializers import CustomModelSerializer

from schema.core.crawler.models import Authentication, Collected, Mirror, Instance, Recorder


class AuthenticationSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    status = serializers.CharField(source='get_status_display')

    class Meta:
        model = Authentication
        exclude = ('modifier', )


class AuthenticationCreateSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """

    class Meta:
        model = Authentication
        fields = (
            'username', 'password', 'validcode', 'email_username', 'email_password', 
            'hometown', 'rank', 'owner', 'is_delete', 'description'
        )
    

class AuthenticationImportSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
      
    def run_validation(self, data=None):
        return super().run_validation(data=data)

    class Meta:
        model = Authentication
        fields = (
            'username', 'password', 'validcode', 'email_username', 'email_password', 
            'hometown', 'status', 'rank', 'owner', 'description'
        )
        

class AuthenticationExportSerializer(CustomModelSerializer):

    status = serializers.CharField(source='get_status_display')

    class Meta:
        model = Authentication
        fields = (
            'username', 'password', 'validcode', 'email_username', 'email_password', 
            'hometown', 'status', 'rank', 'owner', 'description'
        )


class CollectedSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """

    class Meta:
        model = Collected
        exclude = ('modifier', )


class CollectedCreateSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """

    class Meta:
        model = Collected
        exclude = ('account', 'homepage', 'hard_rank', 'description')


class CollectedExportSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = Collected
        fields = '__all__'


class MirrorSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    op_sys = serializers.CharField(source='get_op_sys_display')
    op_disk = serializers.CharField(source='get_op_disk_display')
    area = serializers.CharField(source='get_area_display')
    
    class Meta:
        model = Mirror
        exclude = ('modifier', )


class MirrorCreateSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    op_sys = serializers.CharField(source='get_op_sys_display')
    op_disk = serializers.CharField(source='get_op_disk_display')
    area = serializers.CharField(source='get_area_display')
    
    class Meta:
        model = Mirror
        fields = ('modifier', )


class InstanceSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    status = serializers.CharField(source='get_status_display')
    
    class Meta:
        model = Instance
        exclude = ('modifier', )


class RecorderSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    spider_source = serializers.CharField(source='get_spider_source_display')
    spider_method = serializers.CharField(source='get_spider_method_display')
    spider_category = serializers.CharField(source='get_spider_category_display')
    wave_house = serializers.CharField(source='get_wave_house_display')
    mirror = serializers.CharField(source='mirror__name')
    
    class Meta:
        model = Recorder
        exclude = ('modifier', )


class RecorderCreateSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    def save(self, **kwargs):
        data = super().save(**kwargs)
        return data

    def run_validation(self, data=None):
        return super().run_validation(data=data)

    class Meta:
        model = Recorder
        fields = (
            'start_time', 'end_time', 'spider_source', 'spider_method', 
            'spider_category', 'wave_house', 'is_translate', 'rank', 'mirror',
            'description'
        )
        

class RecorderExportSerializer(CustomModelSerializer):

    class Meta:
        model = Recorder
        fields = (
            'start_time', 'end_time', 'spider_source', 'spider_method', 
            'spider_category', 'wave_house', 'is_translate', 'rank', 'mirror',
            'description'
        )

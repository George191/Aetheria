from schema.views import (
    UserCreateView, ChangePasswordView, MyTokenRefreshView,MyTokenObtainPairView, PasswordResetView, PasswordResetConfirmView, EmailVerifyRecordView
)  
from schema.admin.permission.views import GetUserProfileView, GetRouters

from django.urls import re_path, path, include
from rest_framework_simplejwt.views import TokenVerifyView
from rest_framework.views import APIView
from rest_framework.documentation import include_docs_urls


from utils.response import SuccessResponse

from captcha.conf import settings as ca_settings
from captcha.helpers import captcha_image_url, captcha_audio_url
from captcha.models import CaptchaStore



class CaptchaRefresh(APIView):
    authentication_classes = []
    permission_classes = []

    def get(self, request):
        new_key = CaptchaStore.pick()
        to_json_response = {
            "key": new_key,
            "image_url": captcha_image_url(new_key),
            "audio_url": captcha_audio_url(new_key) if ca_settings.CAPTCHA_FLITE_PATH else None,
        }
        return SuccessResponse(to_json_response)


urlpatterns = [
    re_path(r'^getInfo/$', GetUserProfileView.as_view()),
    re_path(r'^getRouters/$', GetRouters.as_view()),
    
    re_path('api-auth/', include('rest_framework.urls', namespace='rest_framework')),
    re_path('coreapi-docs/', include_docs_urls(title='coreapi接口文档')),

    re_path(r"^captcha/refresh/$", CaptchaRefresh.as_view(), name="captcha-refresh"),  # 刷新验证码
    re_path(r'^captcha/', include('captcha.urls')),  # 图片验证码 路由

    re_path(r'^sign-in/?$', MyTokenObtainPairView.as_view(), name='sign-in'),
    re_path(r'^update-pwd/$', ChangePasswordView.as_view(), name='update_pwd'),
    re_path(r'^sign-up/$', UserCreateView.as_view(), name='sign-up'),
    re_path(r'^refresh/$', MyTokenRefreshView.as_view(), name='token_refresh'),
    re_path(r'^verify/$', TokenVerifyView.as_view(), name='token_verify'),
    re_path(r'^reset/$', PasswordResetView.as_view(), name='password_reset'),
    path('reset/confirm/<uidb64>/<token>/', PasswordResetConfirmView.as_view(), name='password_reset_confirm'), 

    re_path(r'^admin/', include('schema.admin.urls')),
    re_path(r'^core/', include('schema.core.urls')),
]


from rest_framework.routers import DefaultRouter

from schema.admin.tickets.views import TicketViewSet, TicketFlowLogViewSet, TicketCustomFieldViewSet, TicketUserViewSet

router = DefaultRouter()
router.register(r'ticket', TicketViewSet)
router.register(r'ticketflowlog', TicketFlowLogViewSet)
router.register(r'ticketcustomfield', TicketCustomFieldViewSet)
router.register(r'ticketuser', TicketUserViewSet)

urlpatterns = router.urls

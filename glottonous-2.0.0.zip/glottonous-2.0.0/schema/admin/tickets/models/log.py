from django.db.models import (ForeignKey, CASCADE, CharField)
from utils.operations.models import CoreModel


class TicketFlowLog(CoreModel):
    intervene_type = {
        0: '转交操作',
        1: '接单操作',
        2: '评论操作',
        3: '删除操作',
        4: '强制关闭操作',
        5: '强制修改状态操作',
        6: '撤回',
    }
    """
    工单流转日志
    """
    ticket = ForeignKey(to='tickets.TicketRecord', on_delete=CASCADE, verbose_name='工单')
    suggestion = CharField('审批意见', max_length=140, blank=True)
    transition = ForeignKey(to='workflow.Transition', on_delete=CASCADE, verbose_name='流转')
    participant = CharField('处理人', max_length=50, default='', blank=True)
    state = ForeignKey(to='workflow.State', on_delete=CASCADE, verbose_name='当前状态')
    intervene_type = CharField(max_length=1, choices=tuple(intervene_type.items()), default=0,
                                      verbose_name='干预类型')

    class Meta:
        verbose_name = '工单流转日志'
        verbose_name_plural = verbose_name
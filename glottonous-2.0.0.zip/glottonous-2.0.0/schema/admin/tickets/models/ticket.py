import uuid
from django.db.models import (ForeignKey, SET_NULL, CASCADE, CharField, TextField)
from utils.operations.models import CoreModel


class TicketRecord(CoreModel):
    """
    工单记录
    """
    name = CharField(verbose_name='标题', max_length=128, blank=True, default='', help_text="工单的标题")
    sn = CharField(verbose_name='流水号', default=uuid.uuid4 , help_text="工单的流水号", max_length=64)
    participant = CharField(verbose_name='处理人', max_length=64, default='', help_text='可以为空(无处理人的情况，如结束状态)、username\多个username(以,隔开)\部门id\角色id\脚本文件名等')
    workflow = ForeignKey(to='workflow.Workflow', db_constraint=False, help_text='与workflow.Workflow流程关联', on_delete=CASCADE)
    state = ForeignKey(to='workflow.State', verbose_name='工作流状态', db_constraint=False, help_text='与workflow.State关联', on_delete=CASCADE)
    transition = ForeignKey(to='workflow.Transition', on_delete=SET_NULL, blank=True, null=True, verbose_name='进行状态')
    relation = TextField(verbose_name='工单关联人', default='', blank=True, help_text='包括创建人、处理人，用于查询')
    
    def __str__(self):
        return self.name

    class Meta:
        verbose_name = '工单记录'
        verbose_name_plural = verbose_name
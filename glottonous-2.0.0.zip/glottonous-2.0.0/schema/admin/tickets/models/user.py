from django.db.models import (ForeignKey, SET_NULL, CharField, BooleanField)
from utils.operations.models import CoreModel


class TicketUser(CoreModel):
    """
    工单关系人, 用于加速待办工单及关联工单列表查询
    """
    ticket = ForeignKey(to='tickets.TicketRecord', verbose_name='工单记录', db_constraint=False, blank=True, null=True, on_delete=SET_NULL)
    username = CharField(verbose_name='关系人', max_length=100)
    in_process = BooleanField(verbose_name='待处理中', default=False)
    worked = BooleanField(verbose_name='处理过', default=False)

    def __str__(self):
        return self.username

    class Meta:
        verbose_name = '工单关系人'
        verbose_name_plural = verbose_name
    
from django.db.models import (ForeignKey, CASCADE, TextField)
from utils.operations.models import CoreModel


class TicketCustomField(CoreModel):
    """
    工单自定义字段， 工单自定义字段实际的值。
    """
    ticket = ForeignKey(to='tickets.TicketRecord', on_delete=CASCADE, verbose_name='工单')
    customfield = ForeignKey(to='workflow.CustomField', on_delete=CASCADE, verbose_name='字段')
    field_value = TextField('字段值', default='', blank=True)
 
    class Meta:
        verbose_name = '工单自定义字段值'
        verbose_name_plural = verbose_name
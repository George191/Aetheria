import django_filters
from schema.admin.tickets.models import TicketRecord

class TicketFilter(django_filters.rest_framework.FilterSet):

    class Meta:
        model = TicketRecord
        fields = {
            'id': ['exact'],
            'name': ['exact'],
            'participant': ['exact'],
            'creator__username': ['exact'],
            "transition__attribute_type": ['exact', "lt"],
        }
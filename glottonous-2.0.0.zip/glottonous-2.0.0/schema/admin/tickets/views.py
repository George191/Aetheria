from schema.admin.tickets.serializers import (
    TicketCustomFieldReadSerializer, TicketCustomFieldSerializer, TicketFlowLogReadSerializer, 
    TicketFlowLogSerializer, TicketRecordReadSerializer, TicketRecordSerializer, TicketUserSerializer
)
from schema.admin.tickets.models import (
    TicketCustomField, TicketFlowLog, TicketRecord, TicketUser
)
from schema.admin.permission.permissions import CommonPermission
from schema.admin.tickets.filters import TicketFilter

from utils.operations.viewsets import CustomModelViewSet

from django.contrib.auth import get_user_model


User = get_user_model()


class TicketViewSet(CustomModelViewSet):
    queryset = TicketRecord.objects.filter()
    serializer_class = TicketRecordSerializer
    filterset_class = TicketFilter
    search_fields = ['name']
    ordering_fields = ['state']
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    lookup_field = 'secret'

    def get_serializer_class(self):
        if self.action in ['list', 'retrieve']:
            return TicketRecordReadSerializer
        return TicketRecordSerializer

    def get_queryset(self):
        user = User.objects.get(username=self.request.user.username)
        if user.is_superuser:
            return TicketRecord.objects.filter()
        else:
            return TicketRecord.objects.filter(relation__icontains=self.request.user).distinct()



class TicketFlowLogViewSet(CustomModelViewSet):
    """[summary]

    Args:
        BulkModelMixin ([type]): [description]

    Returns:
        [type]: [description]
    """
    queryset = TicketFlowLog.objects.filter()
    serializer_class = TicketFlowLogSerializer
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    search_fields = ['ticket']
    filter_fields = ['ticket', 'state']
    lookup_field = 'secret'

    def get_serializer_class(self):
        if self.action in ['list', 'retrieve']:
            return TicketFlowLogReadSerializer
        return TicketFlowLogSerializer


class TicketCustomFieldViewSet(CustomModelViewSet):
    """[summary]

    Args:
        BulkModelMixin ([type]): [description]

    Returns:
        [type]: [description]
    """
    queryset = TicketCustomField.objects.filter()
    serializer_class = TicketCustomFieldSerializer
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    filter_fields = ['ticket', 'customfield']
    lookup_field = 'secret'

    def get_serializer_class(self):
        if self.action in ['list', 'retrieve']:
            return TicketCustomFieldReadSerializer
        return TicketCustomFieldSerializer


class TicketUserViewSet(CustomModelViewSet):
    """[summary]

    Args:
        BulkModelMixin ([type]): [description]
    """
    queryset = TicketUser.objects.filter()
    serializer_class = TicketUserSerializer
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    search_fields = ['username']
    filter_fields = ['username', 'in_process', 'worked']
    lookup_field = 'secret'

from schema.admin.tickets.models import TicketRecord, TicketFlowLog, TicketCustomField, TicketUser
import json
from schema.admin.permission.serializers import CustomModelSerializer


class TicketRecordReadSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = TicketRecord
        fields = '__all__'
        depth = 1

class TicketRecordSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = TicketRecord
        fields = '__all__'
    
    def create(self, validated_data):
        user = self.context['request'].user
        ticket = TicketRecord.objects.create(**validated_data)
        ticket.save()

        transition = validated_data['transition']
        # save ticketlog
        ticketlog = dict()
        ticketlog["ticket"] = ticket
        ticketlog["suggestion"] = ''
        ticketlog["state"] = transition.source_state
        ticketlog["transition"] = transition
        ticketlog["participant"] = user.username
        TicketFlowLog.objects.create(**ticketlog).save()

        customfield_list = validated_data['customfield_list']
        
        if customfield_list:
            field_models = []
            for item in json.loads(validated_data['customfield_list']):
                if item['field_key'] == "create_user":
                    field_models.append(
                        TicketCustomField(ticket=ticket, customfield_id=int(item['customfield']),
                                        field_value=ticket.create_user),
                    )
                elif item['field_key'] == "create_time":
                    field_models.append(
                        TicketCustomField(ticket=ticket, customfield_id=int(item['customfield']),
                                        field_value=ticket.create_time),
                    )
                elif item['field_key'] == "group":
                    field_models.append(
                        TicketCustomField(ticket=ticket, customfield_id=int(item['customfield']),
                                        field_value=ticket.create_user.group),
                    )
                elif item['field_key'] == "id":
                    field_models.append(
                        TicketCustomField(ticket=ticket, customfield_id=int(item['customfield']),
                                        field_value=ticket.create_user.id),
                    )
                else:
                    field_models.append(
                        TicketCustomField(ticket=ticket, customfield_id=int(item['customfield']),
                                        field_value=item['field_value'])
                    )

            TicketCustomField.objects.bulk_create(field_models).save()

        TicketUser.objects.create(ticket=ticket, username=user.username, worked=True).save()
        TicketUser.objects.create(ticket=ticket, username=ticket.participant, in_process=True).save()
        
        return ticket

    def update(self, instance, validated_data):
        cur_user = self.context['request'].user
        instance.name = validated_data.get('name', instance.name)
        instance.workflow = validated_data.get('workflow', instance.workflow)
        instance.sn = validated_data.get('sn', instance.sn)
        instance.state = validated_data.get('state', instance.state)
        instance.create_user = validated_data.get('create_user', instance.create_user)
        instance.participant = validated_data.get('participant', instance.participant)
        instance.transition = validated_data.get('transition', instance.transition)
        instance.customfield = validated_data.get('customfield', instance.customfield)
        instance.memo = validated_data.get('memo', instance.memo)

        # update relation
        relation = instance.relation.split(',')
        relation.append(validated_data['relation'])
        instance.relation = ','.join(set(relation))
        instance.save()

        # save ticketlog
        ticketlog = dict()
        ticketlog["ticket"] = instance
        ticketlog["suggestion"] = instance.memo
        ticketlog["state"] = instance.transition.source_state
        ticketlog["transition"] = instance.transition
        ticketlog["participant"] = cur_user
        TicketFlowLog.objects.create(**ticketlog)

        # save customfield
        customfield_list = json.loads(instance.customfield)
        for item in customfield_list:
            TicketCustomField.objects.filter(id=item["id"]).update(field_value=item["field_value"])

        # save ticketuser
        TicketUser.objects.create(ticket=instance, username=cur_user, worked=True)
        TicketUser.objects.create(ticket=instance, username=instance.participant, in_process=True)
        return instance


class TicketFlowLogReadSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = TicketFlowLog
        fields = '__all__'
        depth = 2


class TicketFlowLogSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = TicketFlowLog
        fields = '__all__'


class TicketCustomFieldReadSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = TicketCustomField
        fields = '__all__'
        depth = 1


class TicketCustomFieldSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = TicketCustomField
        fields = '__all__'


class TicketUserSerializer(CustomModelSerializer):
    """[summary]

    Args:
        serializers ([type]): [description]
    """
    class Meta:
        model = TicketUser
        fields = '__all__'

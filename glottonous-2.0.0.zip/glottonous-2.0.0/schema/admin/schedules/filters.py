#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:34
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :filters.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


import django_filters
from django_celery_beat.models import IntervalSchedule, CrontabSchedule, PeriodicTask


class IntervalScheduleFilter(django_filters.rest_framework.FilterSet):
    class Meta:
        model = IntervalSchedule
        fields = '__all__'


class CrontabScheduleFilter(django_filters.rest_framework.FilterSet):
    class Meta:
        model = CrontabSchedule
        exclude = ('timezone',)


class PeriodicTaskFilter(django_filters.rest_framework.FilterSet):
    class Meta:
        model = PeriodicTask
        fields = '__all__'


#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:34
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :serializers.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django_celery_beat.models import IntervalSchedule, CrontabSchedule, PeriodicTask
from rest_framework import serializers

from utils.operations.serializers import CustomModelSerializer
from utils.exceptions import APIException


class IntervalScheduleSerializer(CustomModelSerializer):
    class Meta:
        model = IntervalSchedule
        fields = '__all__'


class CrontabScheduleSerializer(CustomModelSerializer):

    def save(self, **kwargs):
        queryset = CrontabSchedule.objects.filter(**self.validated_data)
        if queryset.count() and (
                queryset.count() == 1 and self.initial_data.get('id', None) not in queryset.values_list('id',
                                                                                                        flat=True)):
            raise APIException(message='值已存在!!!')
        super().save(**kwargs)

    class Meta:
        model = CrontabSchedule
        exclude = ('timezone',)


class PeriodicTaskSerializer(CustomModelSerializer):
    interval_list = serializers.SerializerMethodField(read_only=True)
    crontab_list = serializers.SerializerMethodField(read_only=True)

    def get_interval_list(self, obj):
        return IntervalScheduleSerializer(obj.interval).data if obj.interval else {}

    def get_crontab_list(self, obj):
        return CrontabScheduleSerializer(obj.crontab).data if obj.crontab else {}

    class Meta:
        model = PeriodicTask
        fields = '__all__'

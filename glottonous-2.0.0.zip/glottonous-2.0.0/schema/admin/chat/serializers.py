from schema.admin.chat.models import (
    Message, Room, RoomMessage, RoomInvite
)
from schema.admin.permission.models import UserProfile
from schema.admin.permission.serializers import CustomModelSerializer

from rest_framework import serializers
from rest_framework.validators import UniqueValidator
from rest_framework.exceptions import ValidationError

from utils.operations.generics import get_object_or_404

import re


class MessageSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]

    Returns:
        [type]: [description]
    """
    user = serializers.CharField(source='user.username', read_only=True)
    recipient = serializers.CharField(source='recipient.username')

    def create(self, validated_data):
        user = self.context['request'].user
        recipient = get_object_or_404(
            UserProfile, username=validated_data['recipient']['username'])
        msg = Message(recipient=recipient, content=validated_data['content'], user=user)
        msg.save()
        return msg

    class Meta:
        model = Message
        exclude = ('id',)


class RoomListSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    members_num = serializers.ReadOnlyField(source='get_members_num')

    class Meta:
        model = Room
        exclude = ('id',)


class RoomDetailSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]

    Raises:
        ValidationError: [description]
        ValidationError: [description]
        ValidationError: [description]

    Returns:
        [type]: [description]
    """
    owner = serializers.PrimaryKeyRelatedField(read_only=True)
    members_num = serializers.ReadOnlyField(source='get_members_num')
    slug = serializers.SlugField(
        allow_blank=True,
        required=False,
        validators=[
            UniqueValidator(queryset=Room.objects.all().select_related('owner').prefetch_related('members'))
        ]
    )

    class Meta:
        model = Room
        exclude = ('id',)

    def validate_slug(self, value):

        if re.search(r'-[i|I][d|D]-\w+$', value):
            if not self.instance or self.instance.slug != value:
                raise ValidationError('子段字段中的这种结尾类型是保留的。')
        return value

    def validate(self, data):

        if data.get('members'):
            if not self.instance:
                raise ValidationError('您无法添加成员。创建房间时。')
            members_before = {user.id for user in self.instance.members.all()}
            members_after = {user.id for user in data['members']}
            if not members_after.issubset(members_before):
                raise ValidationError('您只能删除会议室成员。')
        return data


class InviteListSerializer(serializers.ListSerializer):
    """[summary]

    Args:
        serializers ([type]): [description]
    """
    def create(self, validated_data):
        invites = [RoomInvite(**item) for item in validated_data]
        return RoomInvite.objects.bulk_create(invites)


class InviteSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]

    Raises:
        ValidationError: [description]
        ValidationError: [description]

    Returns:
        [type]: [description]
    """
    creator = serializers.ReadOnlyField(source='creator.id')
    room = serializers.ReadOnlyField(source='room.slug')

    class Meta:
        model = RoomInvite
        list_serializer_class = InviteListSerializer
        fields = '__all__'

    def validate(self, data):

        room = self.context['room']
        if data['invite_object'] in room.members.all() or data['invite_object'] == room.owner:
            raise ValidationError(f'用户 {data["invite_object"]} 已经在房间里列出 {room.slug}.')
        if RoomInvite.objects.filter(invite_object=data['invite_object'], room=room):
            raise ValidationError(f'用户 {data["invite_object"]} 已经被邀请到房间了 {room.slug}.')
        return data


class InviteToMeSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    creator = serializers.ReadOnlyField(source='creator.id')
    room = serializers.ReadOnlyField(source='room.slug')
    invite_object = serializers.ReadOnlyField(source='invite_object.id')

    class Meta:
        model = RoomInvite
        fields = '__all__'


class RoomMessageSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    room = serializers.ReadOnlyField(source='room.slug')

    class Meta:
        model = Message
        exclude = ('id',)
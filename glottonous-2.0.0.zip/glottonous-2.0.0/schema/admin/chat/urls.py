from schema.admin.chat.views import (
    MessageViewSet, RoomViewSet, InviteFromMeView, InviteToMeView, InviteView, LazyLoadMessagesView
)
from rest_framework_extensions.routers import NestedRouterMixin

from rest_framework.urlpatterns import format_suffix_patterns
from rest_framework.routers import DefaultRouter

from django.urls import re_path


class NestedDefaultRouter(NestedRouterMixin, DefaultRouter):
    pass


router = NestedDefaultRouter()
router.register(r'message', MessageViewSet)
router.register(r'room', RoomViewSet, basename='room_detail')
router.register(r'invite-from-me', InviteFromMeView, basename='invite-from-me')
router.register(r'invite-to-me', InviteToMeView, basename='invite-to-me')


urlpatterns = format_suffix_patterns([
    # 获取所有 tasks 名称
    re_path(r'room/(?P<room_slug>\w+)/invite/$', InviteView.as_view(), name='room-invite'),
    re_path(r'room/(?P<room_slug>\w+)/messages/$', LazyLoadMessagesView.as_view(), name='room-messages'),
])

urlpatterns += router.urls

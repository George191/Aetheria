import django_filters
from schema.admin.chat.models import  Message


class MessageFilter(django_filters.rest_framework.FilterSet):

    MessageName = django_filters.CharFilter(lookup_expr='icontains')

    class Meta:
        model = Message
        exclude = ('creator', 'modifier', 'dept_belong_id', 'description')
from utils.operations.models import BaseModel
from django.db.models import (TextField, DateTimeField, ForeignKey, CASCADE)
from django.conf import settings

from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer


class Message(BaseModel):
    """
    This class represents a chat message. It has a owner (user), timestamp and
    the message body.
    """
    user = ForeignKey(settings.AUTH_USER_MODEL, on_delete=CASCADE, verbose_name='user', related_name='message_user', db_index=True)
    recipient = ForeignKey(settings.AUTH_USER_MODEL, on_delete=CASCADE, verbose_name='recipient', related_name='user_message', db_index=True)
    timestamp = DateTimeField('timestamp', auto_now_add=True, editable=False, db_index=True)
    content = TextField('content', blank=True)

    def __str__(self):
        return self.body

    def characters(self):
        """
        Toy function to count body characters.
        :return: body's char number
        """
        return len(self.body)

    def notify_ws_clients(self):
        """
        Inform client there is a new message.
        """
        notification = {
            'type': 'recieve_group_message',
            'message': '{}'.format(self.id)
        }

        channel_layer = get_channel_layer()

        async_to_sync(channel_layer.group_send)("{}".format(self.user.id), notification)
        async_to_sync(channel_layer.group_send)("{}".format(self.recipient.id), notification)

    def save(self, *args, **kwargs):
        """
        Trims white spaces, saves the message and notifies the recipient via WS
        if the message is new.
        """
        new = self.id
        self.body = self.body.strip()  # Trimming whitespaces from the body
        super(Message, self).save(*args, **kwargs)
        if new is None:
            self.notify_ws_clients()

    # Meta
    class Meta:
        app_label = 'chat'
        verbose_name = 'messages'
        verbose_name_plural = verbose_name
        ordering = ('-timestamp',)
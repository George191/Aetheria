from django.db.models import (DateTimeField, ForeignKey, CASCADE, CharField, ManyToManyField, SlugField, BooleanField)
from django.conf import settings
from utils.operations.models import BaseModel
import uuid


class Room(BaseModel):
    title = CharField(max_length=128, verbose_name='title')
    slug = SlugField(max_length=128, verbose_name='URL', unique=True, blank=True)
    owner = ForeignKey(settings.AUTH_USER_MODEL, verbose_name='owner',
                              on_delete=CASCADE, related_name='rooms_owner')
    members = ManyToManyField(settings.AUTH_USER_MODEL, verbose_name='members',
                                     blank=True, related_name='rooms_members')
    created_at = DateTimeField(auto_now=True)

    def __str__(self):
        return f'room {self.owner}'

    def get_members_num(self):
        return self.members.all().count() + 1

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = ''.join(str(uuid.uuid4()).split('-'))
        super().save(*args, **kwargs)

    class Meta:
        app_label = 'chat'


class RoomInvite(BaseModel):
    creator = ForeignKey(settings.AUTH_USER_MODEL, verbose_name='creator',
                                on_delete=CASCADE, related_name='invite_creator')
    invite_object = ForeignKey(settings.AUTH_USER_MODEL, verbose_name='invite_object',
                                      on_delete=CASCADE, related_name='invite_object')
    room = ForeignKey(to='chat.Room', on_delete=CASCADE,
                             verbose_name='room', related_name='invites')
    is_accepted = BooleanField(verbose_name='is_accepted', null=True)

    def __str__(self):
        return f'{self.invite_object}-{self.creator}-{self.room}'

    class Meta:
        unique_together = ('invite_object', 'room')
        app_label = 'chat'
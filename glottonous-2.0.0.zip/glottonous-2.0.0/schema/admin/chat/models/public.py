from django.db.models import (TextField, DateTimeField, ForeignKey, CASCADE)
from django.conf import settings

from utils.operations.models import BaseModel


class RoomMessage(BaseModel):
    author = ForeignKey(settings.AUTH_USER_MODEL, on_delete=CASCADE,
                               verbose_name='创建人', related_name='message_author')
    room = ForeignKey(to='chat.Room', on_delete=CASCADE,
                             verbose_name='房间', related_name='room_messages')
    text = TextField(verbose_name='message')
    timestamp = DateTimeField(auto_now=True)

    def __str__(self):
        return f'{self.room}-{self.author}-{self.text}'

    class Meta:
        app_label = 'chat'

from channels.generic.websocket import AsyncWebsocketConsumer
import json
import redis
from asgiref.sync import sync_to_async
from channels.db import database_sync_to_async
from channels.exceptions import StopConsumer

from admin.chat.models import Room, RoomMessage
from admin.chat.serializers import RoomMessageSerializer
from settings.dev import REDIS_HOST, REDIS_PORT


class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        print('connect...')
        user_id = self.scope["session"]["_auth_user_id"]

        self.group_name = "{}".format(user_id)

        # Join room group

        await self.channel_layer.group_add(
            self.group_name,
            self.channel_name
        )

        await self.accept()

    async def disconnect(self, close_code):
        print('disconnect...')
        user = self.scope['user']

        # Leave room group
        await self.channel_layer.group_discard(
            self.group_name,
            self.channel_name
        )

    # Receive message from WebSocket
    async def receive(self, text_data=None,bytes_data = None):
        
        print('receive...')
        text_data_json = json.loads(text_data)
        message = text_data_json['message']
        # Send message to room group
        await self.channel_layer.group_send(
            self.chat_group_name,
            {
                'type': 'recieve_group_message',
                'message': message
            }
        )

    async def recieve_group_message(self, event):
        print('recieve_group_message...')
        message = event['message']

        # Send message to WebSocket
        await self.send(
             text_data=json.dumps({
            'message': message
        }))
        

class AsyncChatConsumer(AsyncWebsocketConsumer):
    """异步消费者来处理 WS 连接。"""
    session_storage = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, db=0, decode_responses=True)

    # session_storage.delete('users_test-slug')

    async def connect(self):
        """连接处理函数。"""
        self.room_slug = self.scope['url_route']['kwargs']['room_slug']
        try:
            # 想找个房间
            self.room = await self.get_room()
        except Exception as exc:
            # 如果有错误关闭连接
            await self.close()

        # 检查用户是否是房间的成员
        if not await self.is_room_member():
            raise StopConsumer()

        # 将用户添加到房间组
        self.room_group_name = 'chat_{}'.format(self.room_slug)
        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name
        )

        # 接受连接
        await self.accept()

        # 将用户添加到存储以跟踪连接的用户
        await self.redis_add_user()

        # 将过去的房间消息发送给连接的用户
        await self.send(json.dumps(await self.get_messages()))

        # 发送给群组中的所有新用户
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'user_counter',
                'online': len(await self.get_online_users()),
                'users': await self.get_online_users()
            }
        )

    async def disconnect(self, close_code):
        """断开连接处理函数。"""

        # 从临时存储中删除用户
        await self.redis_del_user()

        # 发送给群组中的所有新用户
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'user_counter',
                'online': len(await self.get_online_users()),
                'users': await self.get_online_users()
            }
        )

        # 从组中删除用户
        await self.channel_layer.group_discard(
            self.room_group_name,
            self.channel_name
        )

    async def receive(self, text_data):
        """处理接收信号的函数."""

        # 数据处理
        text_data_json = json.loads(text_data)
        author = text_data_json.get('author', None)
        message = text_data_json['message']

        # 在数据库中创建消息实例
        await self.create_message(message)

        # 向组中的所有用户发送消息
        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'chat_message',
                'author': author,
                'message': message
            }
        )

    async def chat_message(self, event):
        """发送消息功能。"""
        author = event['author']
        message = event['message']

        await self.send(text_data=json.dumps({
            'author': author,
            'text': message
        }))

    async def user_counter(self, event):
        """发送在线用户的功能."""
        online = event['online']
        users = event['users']

        await self.send(text_data=json.dumps({
            'currently_online': online,
            'User': users
        }))

    # 同步辅助功能：

    @database_sync_to_async
    def get_room(self):
        return Room.objects.get(slug=self.room_slug)

    @sync_to_async
    def is_room_member(self):
        return bool(self.scope['user'] == self.room.owner or self.scope['user'] in self.room.members.all())

    @database_sync_to_async
    def create_message(self, message):
        RoomMessage.objects.create(author=self.scope["user"], room=self.room, text=message)

    @sync_to_async
    def get_username(self):
        return self.scope["user"].profile.username

    @sync_to_async
    def redis_add_user(self):
        self.session_storage.sadd(f'users_{self.room_slug}', self.scope["user"].profile.id)

    @sync_to_async
    def redis_del_user(self):
        self.session_storage.srem(f'users_{self.room_slug}', self.scope["user"].profile.id)

    @sync_to_async
    def get_messages(self):
        messages = self.room.room_messages.order_by('-created_at')[:25]
        serializer = RoomMessageSerializer(messages, many=True)
        return serializer.data

    @sync_to_async
    def get_online_users(self):
        users = list(self.session_storage.smembers(f'users_{self.room_slug}'))
        return users
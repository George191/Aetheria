from schema.admin.chat.models import RoomMessage, RoomInvite


def invite_handler(invite):
    """更改时处理聊天室邀请的功能。"""
    assert isinstance(invite, RoomInvite)

    if invite.is_accepted:
        # 如果邀请被接受，则邀请对象被添加到房间成员中并且邀请实例被删除
        invite.room.members.add(invite.invite_object)
        invite.delete()
    elif invite.is_accepted is False:
        # 如果邀请被拒绝，则简单地删除邀请实例。
        invite.delete()


def message_filter(request, room_slug):

    no_more_data = False
    if RoomMessage.objects.filter(room__slug=room_slug).count():
        no_more_data = True
    return RoomMessage.objects.filter(room__slug=room_slug).order_by('-timestamp'), no_more_data
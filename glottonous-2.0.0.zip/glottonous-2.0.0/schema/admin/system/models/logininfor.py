#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:56
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :logininfor.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.utils.translation import ugettext_lazy as _
from django.db import models
from utils.operations.models import CoreModel


class LoginInfor(CoreModel):
    session_id = models.CharField(max_length=64, verbose_name=_("会话标识"), null=True, blank=True)
    browser = models.CharField(max_length=64, verbose_name=_("浏览器"))
    ipaddr = models.CharField(max_length=32, verbose_name=_("ip地址"), null=True, blank=True)
    loginLocation = models.CharField(max_length=64, verbose_name=_("登录位置"), null=True, blank=True)
    msg = models.TextField(verbose_name=_("操作信息"), null=True, blank=True)
    os = models.CharField(max_length=64, verbose_name=_("操作系统"), null=True, blank=True)
    status = models.BooleanField(default=False, verbose_name=_("登录状态"))

    class Meta:
        app_label = 'system'
        verbose_name = '登录日志'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.creator and self.creator.name}"

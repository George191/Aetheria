#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:56
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :dict_data.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.utils.translation import ugettext_lazy as _
from django.db import models
from utils.operations.models import CoreModel


class DictData(CoreModel):
    dictName = models.CharField(max_length=64, verbose_name=_("字典名称"))
    dictType = models.CharField(max_length=64, verbose_name=_("字典类型"))
    status = models.CharField(max_length=8, verbose_name=_("字典状态"))
    remark = models.CharField(max_length=256,verbose_name=_("备注"), null=True, blank=True)

    class Meta:
        verbose_name = '字典管理'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.dictName}"

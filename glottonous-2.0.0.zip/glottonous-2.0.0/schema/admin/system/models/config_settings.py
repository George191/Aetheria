#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:56
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :config_settings.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.utils.translation import ugettext_lazy as _
from django.db import models
from utils.operations.models import CoreModel


class ConfigSettings(CoreModel):
    configName = models.CharField(max_length=64, verbose_name=_("参数名称"))
    configKey = models.CharField(max_length=256, verbose_name=_("参数键名"))
    configValue = models.CharField(max_length=256, verbose_name=_("参数键值"))
    configType = models.CharField(max_length=8,verbose_name=_("是否内置"))
    status = models.CharField(max_length=8, verbose_name=_("参数状态"))
    remark = models.CharField(max_length=256, verbose_name=_("备注"), null=True, blank=True)

    class Meta:
        verbose_name = '参数设置'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.configName}"

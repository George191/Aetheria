#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:56
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :dict_details.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.utils.translation import ugettext_lazy as _
from django.db import models
from utils.operations.models import CoreModel


class DictDetails(CoreModel):
    dictLabel = models.CharField(max_length=64, verbose_name=_("字典标签"))
    dictValue = models.CharField(max_length=256, verbose_name=_("字典键值"))
    is_default = models.BooleanField(verbose_name=_("是否默认"), default=False)
    status = models.CharField(max_length=2, verbose_name=_("字典状态"))
    sort = models.CharField(max_length=256, verbose_name=_("字典排序"))
    dict_data = models.ForeignKey(to='system.DictData', on_delete=models.CASCADE, verbose_name=_("关联字典"), db_constraint=False)
    remark = models.CharField(max_length=256, verbose_name=_("备注"), null=True, blank=True)

    @classmethod
    def get_default_dictValue(cls, dictName):
        instance = DictDetails.objects.filter(dict_data__dictName=dictName, is_default=True).first()
        return instance and instance.dictValue

    class Meta:
        verbose_name = '字典详情'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.dictLabel}"

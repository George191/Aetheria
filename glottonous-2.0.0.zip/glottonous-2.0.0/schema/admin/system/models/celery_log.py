#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:56
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :celery_log.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.utils.translation import ugettext_lazy as _
from django.db import models
from utils.operations.models import CoreModel


class CeleryLog(CoreModel):
    name = models.CharField(max_length=256, verbose_name=_('任务名称'), help_text='任务名称')
    func_name = models.CharField(max_length=256, verbose_name=_('执行函数名称'), help_text='执行函数名称')
    kwargs = models.TextField(max_length=1024, verbose_name=_('执行参数'), help_text='运行参数')
    seconds = models.CharField(max_length=8, verbose_name=_('执行时间'))
    status = models.BooleanField(default=False, verbose_name=_('运行状态'))
    result = models.TextField(max_length=10240, verbose_name=_('任务结果'), help_text='任务返回内容')

    class Meta:
        verbose_name = 'celery定时日志'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.creator and self.creator.name}"

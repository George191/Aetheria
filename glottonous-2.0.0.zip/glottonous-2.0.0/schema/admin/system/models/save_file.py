#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:00
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :save_file.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


import os
import uuid

from django.utils import timezone
from django.utils.translation import ugettext_lazy as _
from django.db import models

from utils.operations.models import CoreModel



def files_path(instance, filename):
    return '/'.join(['system', timezone.now().strftime("%Y-%m-%d"), str(uuid.uuid4()) + os.path.splitext(filename)[-1]])


class SaveFile(CoreModel):
    name = models.CharField(max_length=128, verbose_name=_("文件名称"), null=True, blank=True)
    type = models.CharField(max_length=200, verbose_name=_("文件类型"), null=True, blank=True)
    size = models.CharField(max_length=64, verbose_name=_("文件大小"), null=True, blank=True)
    address = models.CharField(max_length=16, verbose_name=_("存储位置"), null=True, blank=True)  # 本地、阿里云、腾讯云..
    source = models.CharField(max_length=16, verbose_name=_("文件来源"), null=True, blank=True)  # 导出、用户上传.
    oss_url = models.CharField(max_length=200, verbose_name=_("OSS地址"), null=True, blank=True)
    status = models.BooleanField(default=True, verbose_name=_("文件是否存在"))
    file = models.FileField(verbose_name=_("文件URL"), upload_to=files_path, )

    class Meta:
        verbose_name = '文件管理'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.name}"

#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:57
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :operation_log.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.utils.translation import ugettext_lazy as _
from django.db import models
from utils.operations.models import CoreModel


class OperationLog(CoreModel):
    request_modular = models.CharField(max_length=64, verbose_name=_("请求模块"), null=True, blank=True)
    request_path = models.CharField(max_length=400, verbose_name=_("请求地址"), null=True, blank=True)
    request_body = models.TextField(verbose_name=_("请求参数"), null=True, blank=True)
    request_method = models.CharField(max_length=64, verbose_name=_("请求方式"), null=True, blank=True)
    request_msg = models.TextField(verbose_name=_("操作说明"), null=True, blank=True)
    request_ip = models.CharField(max_length=32, verbose_name=_("请求ip地址"), null=True, blank=True)
    request_browser = models.CharField(max_length=64, verbose_name=_("请求浏览器"), null=True, blank=True)
    response_code = models.CharField(max_length=32, verbose_name=_("响应状态码"), null=True, blank=True)
    request_location = models.CharField(max_length=64,verbose_name=_("操作地点"), null=True, blank=True)
    request_os = models.CharField(max_length=64, verbose_name=_("操作系统"), null=True, blank=True)
    json_result = models.TextField(verbose_name=_("返回信息"), null=True, blank=True)
    status = models.BooleanField(default=False, verbose_name=_("响应状态"))

    class Meta:
        verbose_name = '操作日志'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.request_msg}[{self.request_modular}]"

from admin.system import consumers

from django.conf.urls import url

websocket_urlpatterns = [
    url(r'^ws/chat/$', consumers.ChatConsumer),
    url(r'^ws/chat/room/<str:room_slug>/', consumers.AsyncChatConsumer.as_asgi()),
]
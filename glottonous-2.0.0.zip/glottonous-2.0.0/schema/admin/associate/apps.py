from django.apps import AppConfig


class AssociateConfig(AppConfig):
    name = 'associate'
    """
    声明应用
    """

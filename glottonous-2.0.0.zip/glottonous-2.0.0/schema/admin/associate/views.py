#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:37
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :views.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from utils.operations.viewsets import GenericViewSet
from utils.operations import mixins
from utils.operations.filters import DataLevelPermissionsFilter

from rest_framework.request import Request

from schema.admin.associate.models import InfomationSystem
from schema.admin.associate.serializers import InfomationSystemSerializer
from schema.admin.permission.permissions import CommonPermission



class InfomationSystemModelViewSet(
  mixins.ListModelMixin, mixins.RetrieveModelMixin, 
  GenericViewSet, mixins.TableSerializerMixin, mixins.ExportSerializerMixin):
    """
    系统无需对数据进行维护，只需提供查询即可
    如果不小心误操作对数据进行修改，经纬度改到范围以外，可能会导致异常
    包含列表查询，详情查询，并支持导出功能
    是否需要包含导入具体根据需求修改
    """
    queryset = InfomationSystem.objects.filter()
    serializer_class = InfomationSystemSerializer
    extra_filter_backends = [DataLevelPermissionsFilter]
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    ordering = '-create_datetime'  # 默认排序
    lookup_field = 'secret'

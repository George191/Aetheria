#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:37
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :urls.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from rest_framework.routers import DefaultRouter

from schema.admin.associate.views import InfomationSystemModelViewSet

router = DefaultRouter()
router.register(r'infomation_system', InfomationSystemModelViewSet)


urlpatterns = [
  
]
urlpatterns += router.urls
from django.core.management.base import BaseCommand
from application.admin.permission.models.role import Role
from graph.models import *
from permission.models import Menu
from permission.tools import init_menu


class Command(BaseCommand):
  """
  初始化默认部门，岗位，角色，用户，以及已有的菜单
  """
  help = '初始化 自动化 系统'

  def handle(self, *args, **options):

    try:
      role = Role.objects.get(roleName='超级管理员')
    except:
      raise KeyError('错误: 未查询到超级管理员角色!')

    """
    自动化验证系统菜单
    """
    try:
      self.stdout.write(self.style.SUCCESS('############ 初始化自动化验证菜单 ###########'))

      data_manager = Menu.objects.filter(name='数据管理').exists()
      if not data_manager:
        data_manager = Menu.objects.create(
          parentId=None,
          menuType=1,
          icon='ion:server-outline',
          name='数据管理',
          orderNum=1,
          isFrame=False,
          web_path='data',
          component_path='src/views/data/',
          status=1,
          visible=1,
          isCache=0,
          dept_belong_id=0,
          creator_id=0
        ),
        
      association_menu = Menu.objects.create(
        parentId=data_manager,
        menuType=1,
        icon='ion:md-switch',
        name='船舶自动识别系统',
        orderNum=0,
        isFrame=False,
        web_path='data/association/ship',
        interface_path='admin/association/ship',
        component_path='src/views/data/association/ship/',
        interface_method='GET',
        status=1,
        visible=1,
        isCache=0,
        creator_id=0,
        dept_belong_id=0,
      )
      role.menu.add(association_menu)
      init_menu(association_menu)
    except Exception as e:
      self.stdout.write(self.style.ERROR(f'错误: 初始化自动化验证菜单失败 -> {e}'))
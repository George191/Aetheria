#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:56
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :celery_log.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.utils.translation import ugettext_lazy as _
from django.db import models
from utils.operations.models import BaseModel


class InfomationSystem(BaseModel):
    """
    AIS (Automatic Identification System)船舶自动识别系统，是一种安装于船舶上的无线电通信导航避碰设备，
    可适用于内河、港口及外海等各类船舶。 AIS的主要组成部分为一个GPS接收机,
    一个通信处理器,两个VHF数据接收机和一个VHF数据发射机。 AIS能够提供有效的避碰措施。
    """
    name = models.CharField(
        max_length=64, verbose_name=_('船名'), help_text=_('船名'))
    lon = models.FloatField(_('船舶定位时刻所在的位置的经度，单位：度，取值范围：-180 -- 180  东正西负'),
                            help_text=_('船舶定位时刻所在的位置的经度，单位：度，取值范围：-180 -- 180  东正西负'))
    lat = models.FloatField(_('船舶定位时刻所在位置的纬度，单位：度，取值范围：-90 -- 90， 北正南负'),
                            help_text=_('船舶定位时刻所在位置的纬度，单位：度，取值范围：-90 -- 90， 北正南负'))
    mmsi = models.PositiveIntegerField(
        _('船舶的MMSI号码'), help_text=_('船舶的MMSI号码'))
    speed = models.FloatField(_('船舶速度，单位：节'), help_text=_('船舶速度，单位：节'))
    an = models.CharField(_('船旗，简写 ，如中国CN'), help_text=_(
        '船旗，简写 ，如中国CN'), max_length=64)
    fn = models.CharField(_('船旗，英文'), help_text=_('船旗，英文'), max_length=64)
    dn = models.CharField(_('船旗，中文'), help_text=_('船旗，中文'), max_length=64)
    eta = models.DateTimeField(_('预计到达时间'), help_text=_('预计到达时间'))
    draught = models.FloatField(_('船舶吃水，单位：米'), help_text=_('船舶吃水，单位：米'))
    destination = models.CharField(
        _(' 船舶AIS系统报告的目的港'), help_text=_('船舶AIS系统报告的目的港'), max_length=128)
    destination_tidied = models.CharField(_('船舶AIS系统报告的目的港，经过hifleet映射后的，得到的符合要求的目的港信息'), help_text=_(
        '船舶AIS系统报告的目的港，经过hifleet映射后的，得到的符合要求的目的港信息'), max_length=128)
    width = models.FloatField(_('船舶宽度，单位：米'), help_text=_('船舶宽度，单位：米'))
    length = models.FloatField(_('船舶长度，单位：米'), help_text=_('船舶长度，单位：米'))
    type = models.CharField(_('船类型'), help_text=_('船类型'), max_length=128)
    minotype = models.CharField(
        _('船舶子类型'), help_text=_('船舶子类型'), max_length=128)
    callsign = models.CharField(_('船舶呼号，如果船舶AIS系统未报，该项无值'), help_text=_(
        '船舶呼号，如果船舶AIS系统未报，该项无值'), max_length=128)
    imonumber = models.PositiveIntegerField(
        _('船舶IMO号，如果船舶无IMO号，该项无值'), help_text=_('船舶IMO号，如果船舶无IMO号，该项无值'))
    course = models.CharField(_('船舶航迹向，单位：度，0-360度范围'),
                              help_text=_('船舶航迹向，单位：度，0-360度范围'), max_length=128)
    turnrate = models.CharField(
        _('船舶转向率，单位：度/分钟'), help_text=_('船舶转向率，单位：度/分钟'), max_length=128)
    status = models.CharField(
        _('船舶的航行状态'), help_text=_('船舶的航行状态'), max_length=128)
    heading = models.FloatField(_('船舶船首向，单位：度。取值范围：0-360，默认值：511，表示无可用数据'),
                                help_text=_('船舶船首向，单位：度。取值范围：0-360，默认值：511，表示无可用数据'), max_length=128)

    class Meta:
        app_label = 'associate'
        verbose_name = '自动识别系统'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.name}"

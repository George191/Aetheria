#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:55
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :serializers.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from schema.admin.associate.models import InfomationSystem
from utils.operations.serializers import CustomModelSerializer


class InfomationSystemSerializer(CustomModelSerializer):
    """
    Automatic Identification System 
    系统数据序列化层
    """

    class Meta:
        model = InfomationSystem
        fields = '__all__'
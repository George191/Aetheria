#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:55
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :serializers.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from schema.admin.graph.models import Labels, Node, Property, Relation
from utils.operations.serializers import CustomModelSerializer


class PropertyListSerializer(CustomModelSerializer):
    """
    图数据库属性
    """

    class Meta:
        model = Property
        fields = ('name', 'description', 'creator_name', 'create_datetime', 'update_datetime', 'secret')


class PropertyRetrieveSerializer(CustomModelSerializer):
    """
    图数据库属性
    """

    class Meta:
        model = Property
        fields = ('name', 'description', 'dept_belong_id', 'is_delete', 'is_unique', 'is_index', 'is_required', 'property_type', 'default')


class NodeListSerializer(CustomModelSerializer):
    """
    图数据库节点
    """

    class Meta:
        model = Node
        fields = ('name', 'description', 'creator_name', 'create_datetime', 'update_datetime', 'is_delete', 'secret')


class SimplePropertyListSerializer(CustomModelSerializer):
    """
    属性简易
    """
    class Meta:
        model = Property
        fields = ('name', 'description', 'secret')


class SimpleNodeListSerializer(CustomModelSerializer):
    """
    节点简易
    """
    class Meta:
        model = Node
        fields = ('name', 'description', 'secret')


class NodeRetrieveSerializer(CustomModelSerializer):
    """
    图数据库节点
    """

    properties = SimplePropertyListSerializer(many=True)

    class Meta:
        model = Node
        fields = ('name', 'properties', 'description', 'dept_belong_id', 'is_delete', 'has_operate', 'has_relation', 'color', 'size', 'show_field', 'view_flag')


class NodeCreateSerializer(CustomModelSerializer):
    """
    图数据库节点
    """

    class Meta:
        model = Node
        fields = ('name', 'properties', 'description', 'dept_belong_id', 'is_delete', 'has_operate', 'has_relation', 'color', 'size', 'show_field', 'view_flag')


class LabelRetrieveSerializer(CustomModelSerializer):
    """
    图数据库标签
    """

    class Meta:
        model = Labels
        fields = ('name', 'description', 'is_delete', 'dept_belong_id')


class LabelCreateSerializer(CustomModelSerializer):
    """
    图数据库标签
    """

    class Meta:
        model = Labels
        fields = ('name', 'description', 'is_delete', 'dept_belong_id')


class LabelListSerializer(CustomModelSerializer):
    """
    图数据库标签
    """
    class Meta:
        model = Labels
        fields = ('name', 'creator_name', 'create_datetime', 'update_datetime', 'secret')


class RelationListSerializer(CustomModelSerializer):
    """
    图数据库属性
    """
    class Meta:
        model = Relation
        fields = ('name', 'description', 'creator_name', 'create_datetime', 'update_datetime', 'secret')


class RelationRetrieveSerializer(CustomModelSerializer):
    """
    图数据库关系
    """
    properties = SimplePropertyListSerializer(many=True, read_only=True)
    node_from = SimpleNodeListSerializer(many=True, read_only=True)
    node_to = SimpleNodeListSerializer(many=True, read_only=True)


    class Meta:
        model = Relation
        fields = ('name', 'properties', 'node_from', 'node_to', 'is_delete', 'dept_belong_id', 'color', 'size', 'direction', 'show_field', 'allow_multi')


class RelationCreateSerializer(CustomModelSerializer):
    """
    图数据库关系
    """

    class Meta:
        model = Relation
        fields = ('name', 'properties', 'node_from', 'node_to', 'is_delete', 'dept_belong_id', 'color', 'size', 'direction', 'show_field', 'allow_multi')
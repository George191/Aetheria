from django.core.management.base import BaseCommand
from schema.admin.permission.models.role import Role
from schema.admin.graph.models import *
from schema.admin.permission.models import Menu
from schema.admin.permission.tools import init_menu


class Command(BaseCommand):
  """
  初始化默认部门，岗位，角色，用户，以及已有的菜单
  """
  help = '初始化 节点 属性 标签 关系'

  def handle(self, *args, **options):
    """
    属性类型数据初始化
    """
    try:
      self.stdout.write(self.style.SUCCESS('############ 初始化属性类型 ###########'))
      has_filetype = FieldType.objects.count()
      if not has_filetype:
        short_text      = FieldType.objects.create(name='短文本', code='short_text', creator_id=0, dept_belong_id=0)
        long_text       = FieldType.objects.create(name='长文本', code='long_text', creator_id=0, dept_belong_id=0)
        rich_text       = FieldType.objects.create(name='富文本', code='rich_text', creator_id=0, dept_belong_id=0)
        date_picker     = FieldType.objects.create(name='日期选择', code='date_picker', creator_id=0, dept_belong_id=0)
        datetime_picker = FieldType.objects.create(name='日期时间选择', code='datetime_picker', creator_id=0, dept_belong_id=0)
        switch          = FieldType.objects.create(name='开关', code='switch', creator_id=0, dept_belong_id=0)
        number          = FieldType.objects.create(name='数字', code='number', creator_id=0, dept_belong_id=0)
        dropdown        = FieldType.objects.create(name='下拉选择', code='dropdown', creator_id=0, dept_belong_id=0)
        file            = FieldType.objects.create(name='文件', code='file', creator_id=0, dept_belong_id=0)
    except Exception as e:
      self.stdout.write(self.style.ERROR(f'错误: 初始化数据类型失败 -> {e}'))
    """
    属性数据初始化
    """   
    try:
      self.stdout.write(self.style.SUCCESS('############ 初始化属性 ###########'))
      has_property = Property.objects.count()
      if not has_property:
        id_card     = Property.objects.create(name='唯一编号', is_unique=1, is_index=1, property_type=number, creator_id=0, dept_belong_id=0)
        id_uri      = Property.objects.create(name='主页链接', is_unique=1, is_index=1, property_type=long_text, creator_id=0, dept_belong_id=0)
        name        = Property.objects.create(name='名称', property_type=short_text, creator_id=0, dept_belong_id=0)
        start_time    = Property.objects.create(name='开始时间', property_type=datetime_picker, creator_id=0, dept_belong_id=0)
        end_time    = Property.objects.create(name='结束时间', property_type=datetime_picker, creator_id=0, dept_belong_id=0)
        date        = Property.objects.create(name='日期', property_type=date_picker, creator_id=0, dept_belong_id=0)
        title       = Property.objects.create(name='标题', property_type=short_text, creator_id=0, dept_belong_id=0)
        content     = Property.objects.create(name='正文', property_type=rich_text, creator_id=0, dept_belong_id=0)
        confidence  = Property.objects.create(name='置信度', property_type=switch, creator_id=0, dept_belong_id=0)
        parse_result = Property.objects.create(name='分析结果', property_type=rich_text, creator_id=0, dept_belong_id=0)
        source      = Property.objects.create(name='来源', property_type=long_text, creator_id=0, dept_belong_id=0)
        regulate    = Property.objects.create(name='正则', property_type=long_text, creator_id=0, dept_belong_id=0)
        ignore_case = Property.objects.create(name='忽略大小写', property_type=switch, creator_id=0, dept_belong_id=0)
        status      = Property.objects.create(name='状态', property_type=dropdown, creator_id=0, dept_belong_id=0)
        origin_country = Property.objects.create(name='生产国', property_type=short_text, creator_id=0, dept_belong_id=0)
        lng         = Property.objects.create(name='经度', property_type=number, creator_id=0, dept_belong_id=0)
        lat         = Property.objects.create(name='纬度', property_type=number, creator_id=0, dept_belong_id=0)
        batch         = Property.objects.create(name='批次', property_type=number, creator_id=0, dept_belong_id=0)
        score         = Property.objects.create(name='能力值', property_type=number, creator_id=0, dept_belong_id=0)
    except Exception as e:
      self.stdout.write(self.style.ERROR(f'错误: 初始化属性失败 -> {e}'))
    """
    节点数据初始化
    """
    try:
      self.stdout.write(self.style.SUCCESS('############ 初始化节点 ###########'))
      has_node = Node.objects.count()
      if not has_node:
        account = Node.objects.create(name='社交媒体账号', has_operate=0, dept_belong_id=0, creator_id=0)
        account.properties.add(*(id_card, id_uri, name))

        clue = Node.objects.create(name='开源情报', has_operate=0, dept_belong_id=0, creator_id=0)
        clue.properties.add(*(id_card, id_uri, title, content, confidence))

        clue_other = Node.objects.create(name='开源情报其他线索', has_operate=0, dept_belong_id=0, creator_id=0)
        clue_other.properties.add(*(name, id_uri))

        label = Node.objects.create(name='标签', has_operate=1, dept_belong_id=0, creator_id=0)
        label.properties.add(*(name, ))

        file = Node.objects.create(name='文件', has_operate=1, dept_belong_id=0, creator_id=0)
        file.properties.add(*(id_uri, parse_result))

        site = Node.objects.create(name='站点', has_operate=1, dept_belong_id=0, creator_id=0)
        site.properties.add(*(content, source, id_uri, name))

        algo = Node.objects.create(name='规则', has_operate=1, dept_belong_id=0, creator_id=0)
        algo.properties.add(*(name, regulate, ignore_case))

        person = Node.objects.create(name='人物', has_operate=1, dept_belong_id=0, creator_id=0, has_relation=1)
        person.properties.add(*(name, ))

        equipment = Node.objects.create(name='装备', has_operate=1, dept_belong_id=0, creator_id=0,)
        equipment.properties.add(*(name, status, origin_country))

        organization = Node.objects.create(name='机构', has_operate=1, dept_belong_id=0, creator_id=0)
        organization.properties.add(*(name, status, origin_country))

        facility = Node.objects.create(name='设施', has_operate=1, dept_belong_id=0, creator_id=0)
        facility.properties.add(*(name, status, origin_country))

        alias = Node.objects.create(name='别名', has_operate=1, dept_belong_id=0, creator_id=0)
        alias.properties.add(*(name,))

        place = Node.objects.create(name='地点', has_operate=1, dept_belong_id=0, creator_id=0)
        place.properties.add(*(name, lat, lng))

        warning = Node.objects.create(name='预警', has_operate=1, dept_belong_id=0, creator_id=0)
        warning.properties.add(*(name,))

        category = Node.objects.create(name='类型', has_operate=1, dept_belong_id=0, creator_id=0)
        category.properties.add(*(name,))
    except Exception as e:
      self.stdout.write(self.style.ERROR(f'错误: 初始化节点失败 -> {e}'))
    """
    关系数据初始化
    """
    try:
      self.stdout.write(self.style.SUCCESS('############ 初始化关系 ###########'))
      has_rel = Relation.objects.count()
      if not has_rel:

        relation = Relation.objects.create(name='社交')
        relation.properties.add(*(name, start_time, end_time))
        """
        账号和帐号之间好友关系
        人和人之间朋友、家属、亲人、同事、同学等关系
        """
        relation.node_from.add(*(account, person))
        relation.node_to.add(*(account, person))

        owner = Relation.objects.create(name='归属')
        """
        人和账号之间是属于关系
        账号和社交媒体信是发布关系
        社交媒体言论和言论附属是互动关系
        站点和新闻是来源关系
        地点和地点书属于关系
        # """
        owner.properties.add(*(name, start_time, end_time))
        owner.node_from.add(*(person, account, clue, site, place))
        owner.node_to.add(*(account, clue, clue_other, place))

        warn = Relation.objects.create(name='预警')
        """
        社交媒体情报和官方新闻情报都与预警类别有预警关系
        如果只匹配任务 name 可以为 任务预警
        如果只匹配空间 name 可以为 空间预警
        如果只匹配时间 name 可以为 时间预警
        如果均匹配 name 可以为 事件预警
        """
        warn.properties.add(*(name, start_time, end_time))
        warn.node_from.add(*(clue, ))
        warn.node_to.add(*(warning, ))

        level = Relation.objects.create(name='等级')
        """
        类型和类型是 下级 关系（子分类）
        标签和标签是 下级 关系 (子标签) 
        """
        level.properties.add(*(name, ))
        level.node_from.add(*(category, label))
        level.node_to.add(*(category, label))

        attachment = Relation.objects.create(name='附件')
        """
        账号和附件是头像关系、
        帖子和新闻以及帖子附属与附件是附件关系
        站点与附件是logo关系
        人、装备、机构、设施与附件是资料以及头像关系
        地点与附件是标志（国旗）和范围关系 注：范围是测绘数据
        """
        attachment.properties.add(*(parse_result, start_time, end_time, name))
        attachment.node_from.add(*(account, clue, clue_other, site, person, equipment, organization, facility, place))
        attachment.node_to.add(file)

        stationed = Relation.objects.create(name='驻扎')
        """
        机构与地点是驻扎关系
        """
        stationed.properties.add(*(name, start_time, end_time))
        stationed.node_from.add(organization)
        stationed.node_to.add(place)

        attach = Relation.objects.create(name='隶属')
        """
        机构互相喂隶属关系
        """
        attach.properties.add(*(name, start_time, end_time))
        attach.node_from.add(organization)
        attach.node_to.add(organization)

        serve = Relation.objects.create(name='服役')
        """
        人与机构为服役关系
        人与装备使用、配备、平台关系 例:张三某段时间使用了xxx导弹, 张三配备了马格南手枪，张三在里根号平台上
        """
        serve.properties.add(*(name, start_time, end_time))
        serve.node_from.add(person)
        serve.node_to.add(*(organization, equipment))

        masses = Relation.objects.create(name='家乡')
        """
        人员与地点为出生地关系（家乡） 注释：虽然他也可以直接关联到国家上,但关联到具体的地方在由小地方找到国家会更合理
        """
        masses.properties.add(*(name, start_time, end_time))
        masses.node_from.add(person)
        masses.node_to.add(place)

        categories = Relation.objects.create(name='类型')
        """
        账号:   facebook twitter等
        帖子附属:   评论 点赞 回复
        新闻: 军 民
        文件：音频 视频 图片 文档
        规则：任务 空间 时间 新闻
        装备：导弹 航母 潜艇 坦克等
        机构：学校 医院 政府 编制等
        地点：国家 港口 基地 机场 核电站等
        """
        categories.node_from.add(*(account, clue, file, algo, equipment, organization, place))
        categories.node_to.add(category)

        ability = Relation.objects.create(name='能力')
        """
        装备和地点存在战备张台关系，一条船到了某个地方 名字为 航行 时间xxx batch为第几次任务, score为当前任务的分值
        """
        ability.properties.add(*(name, date, batch, score))
        ability.node_from.add(*(equipment, ))
        ability.node_to.add(*(place, ))
    except Exception as e:
      self.stdout.write(self.style.ERROR(f'错误: 初始化关系失败 -> {e}'))

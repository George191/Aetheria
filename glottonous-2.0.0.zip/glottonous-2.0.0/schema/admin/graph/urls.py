#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:37
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :urls.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.urls import re_path
from rest_framework.routers import DefaultRouter

from schema.admin.graph.views import GetAllNodes, GetEntityRecursion, GetEntityRecursionSubordinate, GetNodeRelNode, GetNodesRelSubordinate, NodeModelViewSet, LabelsModelViewSet, PropertyModelViewSet, RelationModelViewSet

router = DefaultRouter()
router.register(r'node', NodeModelViewSet)
router.register(r'label', LabelsModelViewSet)
router.register(r'property', PropertyModelViewSet)
router.register(r'relation', RelationModelViewSet)

urlpatterns = [
    re_path(r'^GetAllNodes/$', GetAllNodes.as_view()),
    # 递归获取当前实体的数据
    re_path(r'^GetEntityRecursion/$', GetEntityRecursion.as_view()),
    # 递归获取当前实体下级指定的数据
    re_path(r'^GetEntityRecursionSubordinate/$', GetEntityRecursionSubordinate.as_view()),
    # 获取实体数据：当前节点下一层的关系节点
    re_path(r'^GetNodesRelSubordinate/$', GetNodesRelSubordinate.as_view()),
    # 获取关系数据：当前表中指定节点相互之间所存在的关系
    re_path(r'^GetNodeRelNode/$', GetNodeRelNode.as_view()),

    re_path('node/(?P<schema_id>.*)/create', NodeModelViewSet.as_view({'post': 'create_node'})),
    re_path('node/(?P<schema_id>.*)/delete/(?P<node_id>.*)', NodeModelViewSet.as_view({'delete': 'delete_node'})),
    # 传入node就是具体数 据查询，不传入就是某一个实体全部数据
    re_path('node/(?P<schema_id>.*)/retrieve/(?P<node_id>.*)', NodeModelViewSet.as_view({'get': 'get_nodes'})),
    re_path('node/(?P<schema_id>.*)/update/(?P<node_id>.*)', NodeModelViewSet.as_view({'put': 'update_node'})),
    re_path('node/(?P<schema_id>.*)/get_children/(?P<node_id>.*)/by/(?P<rel_name>.*)', NodeModelViewSet.as_view({'get': 'get_children'})),

    re_path('relation/(?P<schema_id>.*)/create', RelationModelViewSet.as_view({'post': 'create_relation'})),
    re_path('relation/(?P<schema_id>.*)/delete/(?P<rel_id>.*)', RelationModelViewSet.as_view({'delete': 'delete_relation'})),
    re_path('relation/(?P<schema_id>.*)/update/(?P<rel_id>.*)', RelationModelViewSet.as_view({'put': 'update_relation'})),
    re_path('relation/(?P<schema_id>.*)/retrieve/(?P<rel_id>.*)', RelationModelViewSet.as_view({'get': 'get_relations'})),

    re_path('label/(?P<node_id>.*)/create_label', LabelsModelViewSet.as_view({'post': 'create_label'})),
    re_path('label/(?P<node_id>.*)/update_label', LabelsModelViewSet.as_view({'put': 'update_label'})),
    re_path('label/(?P<node_id>.*)/destroy_label', LabelsModelViewSet.as_view({'delete': 'destroy_label'})),

]
urlpatterns += router.urls

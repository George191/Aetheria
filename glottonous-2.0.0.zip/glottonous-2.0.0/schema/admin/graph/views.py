#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:37
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :views.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from schema.admin.graph.models import Node, Labels, Property, Relation, Relation
from rest_framework.request import Request
from rest_framework.views import APIView

from schema.admin.graph.serializers import (
  NodeListSerializer, NodeRetrieveSerializer, LabelListSerializer, LabelRetrieveSerializer, 
  PropertyListSerializer, PropertyRetrieveSerializer, RelationListSerializer, RelationRetrieveSerializer,
  NodeCreateSerializer, LabelCreateSerializer, RelationCreateSerializer
)
from schema.admin.permission.permissions import CommonPermission
from utils.operations.filters import DataLevelPermissionsFilter
from utils.response import SuccessResponse
from utils.operations.viewsets import CustomModelViewSet, JsonPagination
from schema.admin.graph.service import GraphService
from schema.admin.permission.views import get_object_or_404
from django.conf import settings


class NodeModelViewSet(CustomModelViewSet):
    """
    Schema层, 对Neo4j图数据库中类型以及属性进行管理
    包含
        1. 创建节点
        2. 删除节点
        3. 修改节点
        4. 获取节点，可以是列表，可以是详情
        5. 获取子节点
        6. 以及schema本身增删改查
    
    注释： 如果节点下有数据应提示无法删除，请先删除下级数据
    """
    queryset = Node.objects.all()
    serializer_class = NodeListSerializer
    update_serializer_class = NodeCreateSerializer
    retrieve_serializer_class = NodeRetrieveSerializer
    create_serializer_class = NodeCreateSerializer
    extra_filter_backends = [DataLevelPermissionsFilter]
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    ordering = '-create_datetime'  # 默认排序
    graph_service = GraphService
    json_page_pagination = JsonPagination
    lookup_field = 'secret'

    # 统一修改： 是否需要查询到schema id 再去查看schema所对应的额节点， 还是全部节点中获取即可
    def create_node(self, request: Request, *args, **kwargs):
        schema = get_object_or_404(self.queryset.filter(secret=kwargs.get('schema_id', None)))
        node = self.graph_service().__create_node__(schema=schema, params=request.query_params, *args, **kwargs)
        return SuccessResponse(data=node)

    def delete_node(self, request: Request, *args, **kwargs):
        schema = get_object_or_404(self.queryset.filter(secret=kwargs.get('schema_id', None)))
        node = self.graph_service().__delete_node__(schema.name, secret=kwargs.get('node_id', None))
        return SuccessResponse(node)

    def update_node(self, request: Request, *args, **kwargs):
        schema = get_object_or_404(self.queryset.filter(secret=kwargs.get('schema_id', None)))
        node = self.graph_service().__update_node__(schema.name, secret=kwargs.get('node_id', None), params=request.data.dict())
        return SuccessResponse(node)

    def get_nodes(self, request: Request, *args, **kwargs):
        # 会需要自己写翻页
        schema = get_object_or_404(self.queryset.filter(secret=kwargs.get('schema_id', None)))
        is_root = request.query_params.get('is_root')
        queryset = self.graph_service().__get_node__(schema=schema.name, secret=kwargs.get('node_id'), is_root=is_root, *args, **kwargs)
        if not kwargs.get('node_id'):
            pagination = self.json_page_pagination()
            page = pagination.paginate_queryset(queryset, request=request)
            if page is not None:
                return pagination.get_paginated_response(page)
            return SuccessResponse(page)
        return SuccessResponse(queryset)

    def get_children(self, request: Request, *args, **kwargs):
        schema = get_object_or_404(self.queryset.filter(secret=kwargs.get('schema_id', None)))
        queryset = self.graph_service().__get_child_node__(schema=schema.name, node_id=kwargs.get('node_id', None), rel_name=kwargs.get('rel_name', None))
        return SuccessResponse(queryset)

    def update(self, request: Request, *args, **kwargs):
        # 不建议修改
        """
            名称可以直接变更
            但是如果修改属性（删减了某一个属性，无需同步，固定字段还在，如果新增出现历史没有的历史无法变更字段） ###########    补空自断
            历史所有数据记录无法同步修改，
            实现出来可能就是每条记录用户都需要人工添加新增字段
            所以修改属性只针对于新入库的数据记录
        """
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        serializer.is_valid(raise_exception=True)
        self.graph_service().__update_node_schema__(instance, request.data)
        self.perform_update(serializer)
        if getattr(instance, '_prefetched_objects_cache', None):
            instance._prefetched_objects_cache = {}
        if hasattr(self, 'handle_logging'):
            self.handle_logging(request, instance=instance, *args, **kwargs)
        return SuccessResponse(serializer.data)

    def destroy(self, request: Request, *args, **kwargs):
        # 不建议删除
        """
        schema 若删除
        图数据库中所有该类别节点及节点关系
        相对应删除
        """
        instance = get_object_or_404(self.get_object_list())
        self.graph_service().__delete_node_schema__(instance)
        if hasattr(self, 'handle_logging'):
            self.handle_logging(request, instance=instance, *args, **kwargs)
        self.perform_destroy(instance)
        return SuccessResponse()


class LabelsModelViewSet(CustomModelViewSet):
    """
    如果要修改
    图数据库已有的标签需要对应修改
    如果要删除
    图数据库与有的标签需要对应删除
    如果要添加
    会关联到对应的实体上，对应的实体会增加标签
    """
    queryset = Labels.objects.all()
    serializer_class = LabelListSerializer
    update_serializer_class = LabelCreateSerializer
    retrieve_serializer_class = LabelRetrieveSerializer
    create_serializer_class = LabelCreateSerializer
    extra_filter_backends = [DataLevelPermissionsFilter]
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    ordering = '-create_datetime'  # 默认排序
    graph_service = GraphService
    lookup_field = 'secret'

    def create_label(self, request: Request, *args, **kwargs):
        instance = get_object_or_404(self.queryset.filter(name=request.POST.get('schema_name', None)))

        result = self.graph_service().__add_label__(
            label_name=request.POST.get('name', None), 
            node=request.POST.get('node', None),
            schema_name=instance.name,
        )
        return SuccessResponse(result)
    
    def update_label(self, request: Request, *args, **kwargs):
        get_object_or_404(self.queryset.filter(name=request.POST.get('schema_name', None)))

        result = self.graph_service().__update_label__(
            node_id=request.POST.get('node', None),
            old_name=request.POST.get('old_name', None), 
            new_name=request.POST.get('new_name', None))

        return SuccessResponse(result)

    def destroy_label(self, request, *args, **kwargs):
        get_object_or_404(self.queryset.filter(name=request.POST.get('schema_name', None)))

        self.graph_service().__delete_label__(
            name=request.POST.get('name', None),
            node_id=request.POST.get('node', None)
        )
        return SuccessResponse()

    
class PropertyModelViewSet(CustomModelViewSet):
    """
    随便增删改查
    基于node和relation触发
    """
    queryset = Property.objects.all()
    serializer_class = PropertyListSerializer
    update_serializer_class = PropertyRetrieveSerializer
    retrieve_serializer_class = PropertyRetrieveSerializer
    create_serializer_class = PropertyRetrieveSerializer
    extra_filter_backends = [DataLevelPermissionsFilter]
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    ordering = '-create_datetime'  # 默认排序
    lookup_field = 'secret'


class RelationModelViewSet(CustomModelViewSet):
    """
    增加
        无需操作xx图
    修改
        对应已经有的关系要修改（名称可以直接改，数据当新关系入库才会体现 同node）
    删除
        如果库里存在这种关系，是否删除所有该关系，还是保留历史，新增时再无此关系
    """
    queryset = Relation.objects.all()
    serializer_class = RelationListSerializer
    update_serializer_class = RelationCreateSerializer
    retrieve_serializer_class = RelationRetrieveSerializer
    create_serializer_class = RelationCreateSerializer
    extra_filter_backends = [DataLevelPermissionsFilter]
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    ordering = '-create_datetime'  # 默认排序
    graph_service = GraphService
    json_page_pagination = JsonPagination
    lookup_field = 'secret'

    def update(self, request: Request, *args, **kwargs):
        partial = kwargs.pop('partial', False)
        instance = self.get_object()
        serializer = self.get_serializer(instance, data=request.data, partial=partial)
        self.graph_service().__update_relation_schema__(instance, request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_update(serializer)
        if getattr(instance, '_prefetched_objects_cache', None):
            instance._prefetched_objects_cache = {}
        if hasattr(self, 'handle_logging'):
            self.handle_logging(request, instance=instance, *args, **kwargs)
        return SuccessResponse(serializer.data)

    def destroy(self, request, *args, **kwargs):
        instance = get_object_or_404(self.get_object_list())
        self.graph_service().__delete_relation_schema__(instance)
        if hasattr(self, 'handle_logging'):
            self.handle_logging(request, instance=instance, *args, **kwargs)
        self.perform_destroy(instance)
        return SuccessResponse()

    def create_relation(self, request: Request, *args, **kwargs):
        schema = get_object_or_404(self.queryset.filter(secret=kwargs.get('schema_id')))
        node = self.graph_service().__create_relation__(schema=schema, params=request.query_params, *args, **kwargs)
        return SuccessResponse(data=node)

    def update_relation(self, request: Request, *args, **kwargs):
        schema = get_object_or_404(self.queryset.filter(secret=kwargs.get('schema_id')))
        relation = self.graph_service().__update_relation__(schema.name, secret=kwargs.get('rel_id'), params=request.data.dict())
        return SuccessResponse(relation)
    
    def delete_relation(self, request: Request, *args, **kwargs):
        schema = get_object_or_404(self.queryset.filter(secret=kwargs.get('schema_id')))
        node = self.graph_service().__delete_relation__(schema.name, secret=kwargs.get('rel_id'))
        return SuccessResponse(node)

    def get_relations(self, request: Request, *args, **kwargs):
        schema = get_object_or_404(self.queryset.filter(secret=kwargs.get('schema_id')))
        queryset = self.graph_service().__get_relation__(schema_name=schema.name, secret=kwargs.get('rel_id'))
        pagination = self.json_page_pagination()
        page = pagination.paginate_queryset(queryset=queryset, request=request)
        if page is not None:
            return pagination.get_paginated_response(page)
        return SuccessResponse(queryset)


class GetShortestPaths(APIView):
    """
    获取两个节点最短关系路径
    """
    graph_service = GraphService

    def post(self, request, format=None):
        result = self.graph_service().__get_shortest_paths__(
            request.POST.get('to_schema', None),
            request.POST.get('from_schema', None),
            request.POST.get('to_value', None),
            request.POST.get('from_value', None),
        )
        return SuccessResponse(result)


class GetAllNodes(APIView):
    """
    获取全部节点
    """
    graph_service = GraphService

    def post(self, request, format=None, ):
        result = self.graph_service().__get_all_nodes__(
            request.POST.get('limit', settings.GRAPH_DEFAULT_SHOW_NUMBER))
        return SuccessResponse(result)


class GetEntityRecursion(APIView):
    """
    获取实体数据：递归获取当前实体的数据,
    例如：战斗序列下的所有战斗序列，递归战斗序列
    """
    graph_service = GraphService

    def post(self, request, format=None, ):
        result = self.graph_service().__get_entity_recursion__(
            request.POST.get('schema_name', None),
            request.POST.get('number', 1),
            request.POST.get('secret_list', []),
        )
        return SuccessResponse(result)


class GetEntityRecursionSubordinate(APIView):
    """
    获取实体数据：递归获取当前实体下级指定的数据
    例如：战斗序列下的所有人，递归战斗序列
    """
    graph_service = GraphService

    def post(self, request, format=None, ):
        result = self.graph_service().__get_entity_recursion_subordinate__(
            request.POST.get('to_schema', None),
            request.POST.get('from_schema', None),
            request.POST.get('number', None),
            request.POST.get('secret_list', []),
        )
        return SuccessResponse(result)


class GetNodesRelSubordinate(APIView):
    """
    获取实体数据：当前节点下一层的关系节点
    """
    graph_service = GraphService

    def post(self, request, format=None, ):
        result = self.graph_service().__get_nodes_rel_subordinate__(
            request.POST.get('to_schema', None),
            request.POST.get('from_schema', None),
            request.POST.get('secret', None),
            request.POST.get('rel_name', None),
        )
        return SuccessResponse(result)


class GetNodeRelNode(APIView):
    """
    获取关系数据：当前表中指定节点相互之间所存在的关系
    """
    graph_service = GraphService

    def post(self, request, format=None, ):
        result = self.graph_service().__get_node_rel_node__(
            request.POST.get('nodes_name', []),
            request.POST.get('schema_name', None),
            request.POST.get('filed_name', None),
        )
        return SuccessResponse(result)

from django.http import QueryDict
from py2neo import Node
from utils.graphdb_utils import Pyneo4j
from schema.admin.graph.models import Node, Property, Relation


# 继承schema graph
class GraphService(Pyneo4j):

    def __init__(self):
        super().__init__()

    def __add_properties__(self, schema: any, entity: any, params: QueryDict) -> any:
        for property in schema.properties.all():
            if property.name not in params:
                raise KeyError(f'A required attribute named {property.name} is missing')
            entity[property.name] = params.get(property.name)
        self.graph.create(entity)
        return entity

    def __create_node__(self, schema: any, params: QueryDict, *args, **kwargs) -> Node:
        node = super().__create_node__(node, *args, **kwargs)
        return self.__add_properties__(schema=schema, entity=node, params=params)
    
    def __create_relation__(self, schema: any, params: QueryDict, *args, **kwargs) -> Relation:
        relation = super().__create_relation__(relation=schema.name, entity_from=schema.node_from, entity_to=schema.node_to, *args, **kwargs)
        return self.__add_properties__(schema=schema, entity=relation, params=params)

    def __get_child_node__(self, schema, node_id, rel_name, *args, **kwargs) -> Node:

        assert rel_name, 'A required attribute named rel_name is missing'
        
        return self.__get_child_node__(schema, node_id, rel_name, *args, **kwargs)

    def __unique_properties__(self, instance, data: QueryDict):
        instance_data = {
            i.id for i in instance.properties.all()
        }
        new_properties = {
            int(i) for i in data.getlist('properties')
        }

        differece = new_properties - instance_data

        result = (i.name for i in Property.objects.filter(pk__in=differece))
        return result

    def __update_node_schema__(self, instance, data: QueryDict, *args, **kwargs) -> any:
        return super().__update_node_schema__(instance.name, data.get('name'), self.__unique_properties__(instance, data), *args, **kwargs)

    
    def __add_label__(self, label_name, node_id, schema_name, *args, **kwargs) -> Node:

        assert label_name, '请输入要新增节点的标签名称！'
        assert node_id, '请输入要新增节点的唯一编号！'

        node = self.__get_node__(schema_name=schema_name, secret=node_id)
        return super().__add_label__(label_name, node, *args, **kwargs)

    def __update_label__(self, node_id: str, old_name: str, new_name: str, *args, **kwargs) -> any:

        assert new_name, '请输入要新增节点的标签名称！'
        assert old_name, '请输入要新增节点的标签名称！'
        assert node_id, '请输入要新增节点的唯一编号！'

        return super().__update_label__(node_id=node_id, new_name=new_name, old_name=old_name)

    def __delete_label__(self, name: str, node_id: str) -> any:

        assert name, '请输入要新增节点的标签名称！'
        assert node_id, '请输入要新增节点的唯一编号！'
        return super().__delete_label__(name, node_id)

    def __update_relation__(self, schema, secret, params, *args, **kwargs) -> Node:
        return super().__update_properties__(schema, secret, params, *args, **kwargs)

    def __update_relation_schema__(self, instance, data: QueryDict, *args, **kwargs) -> any:
        return super().__update_relation_schema__(instance.name, data.get('name'), self.__unique_properties__(instance, data), *args, **kwargs)
    
    def __get_shortest_paths__(self, to_schema: str, from_schema: str, to_value: str, from_value: str) -> any:

        assert from_schema, '请输入要来源节点的标签名！'
        assert from_value, '请输入要来源节点的过滤值！'
        assert to_schema, '请输入要目的节点的标签名！'
        assert to_value, '请输入要目的节点的过滤值！'

        return super().__shortest_path__(to_schema, from_schema, to_value, from_value)

    def __get_entity_recursion__(self, schema_name: str, number: int, secret_list: list) -> any:

        assert schema_name, '请输入要来当前实体名！'
        assert number, '请输入要抽取节点的数量！'
        assert secret_list, '请输入要源实体的secret！'

        return super().__init_entity_recursion__(schema_name, number, secret_list)

    def __get_entity_recursion_subordinate__(self, to_schema: str, from_schema: str, number: int, secret_list: list) -> any:

        assert to_schema, '请输入目的的实体名！'
        assert from_schema, '请输入来源的实体名！'
        assert number, '请输入要抽取实体的数量！'
        assert secret_list, '请输入要源实体的secret！'

        return super().__init_entity_recursion_subordinate__(to_schema, from_schema, number, secret_list)

    def __get_nodes_rel_subordinate__(self, to_schema: str, from_schema: str, rel_name: str, secret=None) -> any:

        assert to_schema, '请输入目的的实体名！'
        assert from_schema, '请输入来源的实体名！'
        assert rel_name, '请输入要实体之间的关系！'
        assert secret, '请输入要源实体的secret！'

        return super().__nodes_rel_subordinate__(to_schema, from_schema, secret, rel_name)

    def __get_node_rel_node__(self, nodes_name: list, schema_name: str, filed_name: str) -> any:

        assert nodes_name, '请输入要过滤的Value列表！'
        assert schema_name, '请输入要查询的实体名！'
        assert filed_name, '请输入要查询的Key名！'

        return super().__nodes_rel_nodes__(nodes_name, schema_name, filed_name)
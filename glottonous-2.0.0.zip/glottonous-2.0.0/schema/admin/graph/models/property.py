#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:56
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :celery_log.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.utils.translation import ugettext_lazy as _
from django.db import models
from utils.operations.models import CoreModel


class Property(CoreModel):

    name = models.CharField(max_length=64, verbose_name=_('属性名称'), help_text=_('属性名称'))
    is_unique = models.BooleanField(_('是否唯一性'), help_text=_('是否唯一性'), default=False)
    is_index = models.BooleanField(_('是否索引项'), help_text=_('是否索引项'), default=False)
    is_required = models.BooleanField(_('是否必填'), help_text=_('是否必填'), default=True)
    property_type = models.ForeignKey(to='graph.FieldType', to_field='secret', on_delete=models.SET_NULL, null=True)
    default = models.CharField(_('默认值'), help_text=_('默认值'), null=False, default='', max_length=32)

    class Meta:
        verbose_name = '节点属性' # 固定字段
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.name}"


class FieldType(CoreModel):
    name = models.CharField(_('名称'), help_text=_('名称'), max_length=32)
    code = models.CharField(_('类型代号'), help_text=_('类型代号'), max_length=32)

    class Meta:
        verbose_name = verbose_name_plural = '节点属性类型'

    def __str__(self):
        return f'{self.name}'

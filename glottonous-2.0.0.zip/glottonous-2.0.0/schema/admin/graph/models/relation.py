#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:56
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :celery_log.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.utils.translation import ugettext_lazy as _
from django.db import models
from utils.operations.models import CoreModel


class Relation(CoreModel):
    DIRECTION_CHOICES = (
        (0, "---"),
        (1, "<---"),
        (2, "--->"),
    )
    name = models.CharField(max_length=64, verbose_name=_('关系名称'), help_text='关系名称')
    properties = models.ManyToManyField(to='graph.Property', verbose_name='关系属性', help_text='关系属性')
    color = models.CharField(_('边颜色'), help_text=_('边颜色'), default='#FF0000', max_length=8)
    size = models.PositiveSmallIntegerField(_('边大小, n/px'), help_text=_('边大小 n/px'), default=18)
    direction = models.SmallIntegerField(_('方向'), help_text=_('方向'), choices=DIRECTION_CHOICES)
    allow_multi = models.BooleanField(_('允许多次链接'), help_text=_('允许多次链接'), default=False)
    show_field = models.CharField(_('展示属性'), help_text=_('展示属性'), max_length=32)

    node_from = models.ManyToManyField(to='graph.Node', verbose_name='节点from', help_text='节点from', related_name='node_from')
    node_to = models.ManyToManyField(to='graph.Node', verbose_name='节点to', help_text='节点to', related_name='node_to')

    class Meta:
        verbose_name = '图关系'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.name}"

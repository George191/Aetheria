#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:56
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :celery_log.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.utils.translation import ugettext_lazy as _
from django.db import models
from utils.operations.models import CoreModel


class Node(CoreModel):

    VIEWER_CODE_CHOICES = (
        (0, "POST"),      # 帖子
        (1, "NEWS"),      # 新闻
        (2, "PERSON"),    # 人
        (3, "ACCOUNT"),   # 账号
        (4, "FILE"),      # 文件
        (5, "SITE"),      # 站点
        (6, "REG"),       # 规则  
        (7, "EQUIPMENT"), # 装备
        (8, "TAG"),       # 标签
        (9, "ORG"),       # 机构
        (10, "PLACE"),    # 地点
        (11, "CLASS"),    # 级别
        (-1, None),    # 级别
    )

    name = models.CharField(max_length=32, verbose_name=_('节点名称'), help_text=_('节点名称'))
    properties = models.ManyToManyField(to='graph.Property', verbose_name='节点属性', help_text='节点属性')
    has_operate = models.BooleanField(_('是否可以操作'), help_text=_('是否可以操作'), default=True)
    has_relation = models.BooleanField(_('是否关系'), help_text=_('必须关联'), default=False)
    color = models.CharField(_('节点颜色'), help_text=_('节点颜色'), default='#FF0000', max_length=8)
    size = models.PositiveSmallIntegerField(_('节点大小, n/px'), help_text=_('节点大小 n/px'), default=18)
    show_field = models.CharField(_('展示属性'), help_text=_('展示属性'), max_length=32)
    view_flag = models.PositiveSmallIntegerField(_('前端展示形式'), help_text=_('前端展示形式'), choices=VIEWER_CODE_CHOICES)

    class Meta:
        verbose_name = '图节点'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.name}"


class Labels(CoreModel):
    name = models.CharField(max_length=32, verbose_name=_('标签名称'), help_text=_('标签名称'))

    class Meta:
        verbose_name = '节点标签'
        verbose_name_plural = verbose_name

from schema.admin.workflow.views import (
    WorkflowTypeViewSet, WorkflowViewSet, StateViewSet, TransitionViewSet, CustomFieldViewSet, WorkflowBpmnViewSet
)
from rest_framework.routers import DefaultRouter


router = DefaultRouter()
router.register(r'workflow-type', WorkflowTypeViewSet)
router.register(r'workflow', WorkflowViewSet)
router.register(r'state', StateViewSet)
router.register(r'transition', TransitionViewSet)
router.register(r'custom-field', CustomFieldViewSet)
router.register(r'workflow-bpmn', WorkflowBpmnViewSet)

urlpatterns = router.urls

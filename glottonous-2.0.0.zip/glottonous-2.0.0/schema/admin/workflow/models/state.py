import imp
from django.db.models import (ForeignKey, CASCADE, CharField, BooleanField, ManyToManyField)
from django.db import models
from utils.operations.models import CoreModel
from django.utils.translation import ugettext_lazy as _


class State(CoreModel):
    state_type = {
        0: '普通状态',
        1: '初始状态',
        2: '结束状态',
    }

    participant_type = {
        'none': '无处理人',
        'user': '个人',
        'group': '部门',
        'role': '角色',
    }
    """
    状态记录, 变量支持通过脚本获取
    """
    name = CharField(verbose_name='名称', max_length=50)
    workflow = ForeignKey(to='workflow.Workflow', on_delete=CASCADE, verbose_name='工作流')
    is_hidden = BooleanField(verbose_name='是否隐藏', default=False, help_text='设置为True时,获取工单步骤api中不显示此状态(当前处于此状态时除外)')
    order_id = models.PositiveSmallIntegerField(_("状态顺序"), default=1)
    state_type = CharField(max_length=1, choices=tuple(state_type.items()), default=0, verbose_name='状态类型')
    enable_retreat = BooleanField(verbose_name='允许撤回', default=False, help_text='开启后允许工单创建人在此状态直接撤回工单到初始状态')
    part_type = CharField(max_length=5, choices=tuple(participant_type.items()), default='none', verbose_name='参与者类型')
    user_part = ManyToManyField(to='permission.UserProfile', blank=True, verbose_name='参与用户', related_name='state_user')
    group_part = ManyToManyField(to='permission.Dept', blank=True, verbose_name='参与组')
    role_part = ManyToManyField(to='permission.Role', blank=True, verbose_name='参与角色')
    fields = ManyToManyField(to='workflow.CustomField', blank=True, verbose_name='可编辑字段')

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['order_id']
        verbose_name = '工作流状态'
        verbose_name_plural = verbose_name
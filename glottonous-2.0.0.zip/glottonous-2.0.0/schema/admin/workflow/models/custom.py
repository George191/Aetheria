from django.db.models import (ForeignKey, CASCADE, CharField, BooleanField, TextField)
from django.db import models
from django.utils.translation import ugettext_lazy as _

from utils.operations.models import CoreModel


class CustomField(CoreModel):
    field_type = {
        1: '字符串',
        2: '整型',
        3: '浮点型',
        4: '布尔',
        5: '日期',
        6: '日期时间',
        7: '范围日期',
        8: '文本域',
        9: '单选框',
        10: '下拉列表',
        11: '用户名',
        12: '多选框',
        13: '多选下拉',
        14: '多选用户名',
    }
    """自定义字段, 设定某个工作流有哪些自定义字段"""
    workflow = ForeignKey(to='workflow.Workflow', on_delete=CASCADE, verbose_name='工作流')
    field_attr = BooleanField(verbose_name='字段是否内置', default=False)
    field_type = CharField(max_length=1, choices=tuple(field_type.items()), default=0, verbose_name='字段类型')
    field_key = CharField(verbose_name='字段标识', max_length=50, help_text='字段类型请尽量特殊，避免与系统中关键字冲突')
    field_name = CharField(verbose_name='字段名称', max_length=50)
    # 内置 field 的 order_id 不要超过10
    order_id = models.PositiveSmallIntegerField(verbose_name='排序', default=0)
    default_val = CharField(verbose_name='默认值', null=True, blank=True, max_length=100, help_text='前端展示时，可以将此内容作为表单中的该字段的默认值')
    field_temp = TextField(verbose_name='文本域模板', default='', blank=True, help_text='文本域类型字段前端显示时可以将此内容作为字段的placeholder')
    bool_display = CharField(verbose_name='布尔类型显示名', max_length=100, default='{}', blank=True,
                                             help_text='当为布尔类型时候，可以支持自定义显示形式。{"1":"是","0":"否"}或{"1":"需要","0":"不需要"}，注意数字也需要引号')
    field_choice = CharField(verbose_name='radio、checkbox、select的选项', max_length=255, default='{}', blank=True,
                                    help_text='radio,checkbox,select,multiselect类型可供选择的选项，格式为json如:{"1":"中国", "2":"美国"},注意数字也需要引号')
    label = CharField(verbose_name='标签', max_length=100, blank=True, default='{}',
                             help_text='自定义标签，json格式，调用方可根据标签自行处理特殊场景逻辑，loonflow只保存文本内容')

    def __str__(self):
        return self.field_name

    class Meta:
        ordering = ['order_id']
        verbose_name = '工作流自定义字段'
        verbose_name_plural = verbose_name
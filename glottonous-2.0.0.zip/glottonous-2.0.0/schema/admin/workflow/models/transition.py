import imp
from django.db.models import (ForeignKey, SET_NULL, CASCADE, CharField, BooleanField, TextField)
from django.utils.translation import ugettext_lazy as _
from django.db import models

from utils.operations.models import CoreModel


class Transition(CoreModel):
    transition_name = {
        0: '保存',
        1: '转交下一步',
        2: '驳回',
        3: '撤销',
        4: '关闭',
    }

    transition_type = {
        0: '常规流转',
        1: '定时器流转',
    }

    attribute_type = {
        0: '草稿',
        1: '待审',
        2: '驳回',
        3: '撤销',
        4: '结束',
        5: '已关闭',
    }
    """
    工作流流转，定时器，条件(允许跳过)， 条件流转与定时器不可同时存在
    """
    name = CharField(verbose_name='名称类型', max_length=1, choices=tuple(transition_name.items()), default=1)
    workflow = ForeignKey('workflow.Workflow', on_delete=CASCADE, verbose_name='工作流')
    transition_type = CharField(verbose_name='流转类型', max_length=1, choices=tuple(transition_type.items()), default=0)
    timer = models.PositiveIntegerField(_("定时器(单位秒)"), default=0, help_text='流转类型设置为定时器流转时生效,单位秒。处于源状态X秒后如果状态都没有过变化则自动流转到目标状态')
    source_state = ForeignKey(to='workflow.State', null=True, blank=True, on_delete=SET_NULL, related_name="source_state", verbose_name='源状态')
    dest_state = ForeignKey(to='workflow.State', null=True, blank=True, on_delete=SET_NULL, related_name="dest_state", verbose_name='目的状态')
    condition_expression = TextField(verbose_name='条件表达式', default='[]',
                                            help_text='流转条件表达式，根据表达式中的条件来确定流转的下个状态，格式为[{"expression":"{days} > 3 and {days}<10", "target_state_id":11}] 其中{}用于填充工单的字段key,运算时会换算成实际的值，当符合条件下个状态将变为target_state_id中的值,表达式只支持简单的运算或datetime/time运算.loonflow会以首次匹配成功的条件为准，所以多个条件不要有冲突')
    attribute_type = CharField(max_length=1, choices=tuple(attribute_type.items()), default=0, verbose_name='属性类型')
    alert_enable = BooleanField(verbose_name='点击弹窗提示', default=False)
    alert_text = CharField(verbose_name='弹窗内容', max_length=100, default='', blank=True)

    def __str__(self):
        return str(self.name)

    class Meta:
        verbose_name = '工作流流转'
        verbose_name_plural = verbose_name
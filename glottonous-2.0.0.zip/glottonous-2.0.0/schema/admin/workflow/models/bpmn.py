from django.db.models import (ForeignKey, CASCADE, TextField)
from utils.operations.models import CoreModel


class WorkflowBpmn(CoreModel):
    workflow = ForeignKey('workflow.Workflow', on_delete=CASCADE, verbose_name='工作流')
    xml = TextField('xml数据', blank=True)
    svg = TextField('svg数据', blank=True)

    class Meta:
        verbose_name = '工作流bpmn'
        verbose_name_plural = verbose_name

from django.db.models import (CharField, BooleanField)
from django.db import models
from django.utils.translation import ugettext_lazy as _

from utils.operations.models import CoreModel


class WorkflowType(CoreModel):
    name = CharField(verbose_name='名称', max_length=50)
    status = BooleanField(default=True)
    code = CharField(max_length=32, unique=True, verbose_name='代码')
    order_id = models.PositiveSmallIntegerField(_("状态顺序"), default=1)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['order_id']
        verbose_name = '工作流类型'
        verbose_name_plural = verbose_name
from django.db.models import (ForeignKey, CASCADE, CharField, BooleanField, ManyToManyField, TextField)

from utils.operations.models import CoreModel



class Workflow(CoreModel):
    """
    工作流
    """
    name = CharField(verbose_name='名称', max_length=50)
    key = CharField(verbose_name='流程标识key', blank=True, max_length=168)
    ticket_sn_prefix = CharField(verbose_name='工单流水号前缀', default='bt', max_length=20)
    status = BooleanField(verbose_name='状态', default=True)
    type = ForeignKey(to='workflow.WorkflowType', on_delete=CASCADE, verbose_name='工作流类型')
    roles = ManyToManyField(to='permission.Role', verbose_name='关联角色', blank=True, related_name="workflow_set", related_query_name="workflow")
    perm_check = BooleanField('查看权限校验', default=True, help_text='开启后，只允许工单的关联人(创建人、曾经的处理人)有权限查看工单')
    limit_re = TextField('限制表达式', default='{}', blank=True,
                                        help_text='限制周期({"period":24} 24小时), 限制次数({"count":1}在限制周期内只允许提交1次), 限制级别({"level":1} 针对(1单个用户 2全局)限制周期限制次数,默认特定用户);允许特定人员提交({"allow_persons":"zhangsan,lisi"}只允许张三提交工单,{"allow_depts":"1,2"}只允许部门id为1和2的用户提交工单，{"allow_roles":"1,2"}只允许角色id为1和2的用户提交工单)')
    display_form = TextField('展现表单字段', default='[]', blank=True,
                                        help_text='默认"[]"，用于用户只有对应工单查看权限时显示哪些字段,field_key的list的json,如["days","sn"],内置特殊字段participant_info.participant_name:当前处理人信息(部门名称、角色名称)，state.state_name:当前状态的状态名,workflow.workflow_name:工作流名称')
    title_temp = CharField('标题模板', max_length=50, default='你有一个待办工单:{name}', null=True, blank=True,
                                      help_text='工单字段的值可以作为参数写到模板中，格式如：你有一个待办工单:{name}')

    def __str__(self):
        return self.name

    class Meta:
        verbose_name = '工作流'
        verbose_name_plural = verbose_name
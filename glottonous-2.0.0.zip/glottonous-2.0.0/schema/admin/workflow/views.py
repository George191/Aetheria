from schema.admin.workflow.serializers import (
    WorkflowBpmnSerializer, WorkflowReadSerializer, WorkflowSerializer, WorkflowTypeSerializer,
    StateSerializer, TransitionReadSerializer, TransitionSerializer, CustomFieldSerializer
)
from schema.admin.workflow.models import (
    State, Transition, Workflow, WorkflowType, WorkflowBpmn, CustomField
)
from schema.admin.permission.permissions import CommonPermission
from utils.operations.viewsets import CustomModelViewSet


class WorkflowTypeViewSet(CustomModelViewSet):
    queryset = WorkflowType.objects.all()
    serializer_class = WorkflowTypeSerializer
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    search_fields = ['name']
    filter_fields = ['name', 'code', 'status']
    lookup_field = 'secret'


class WorkflowViewSet(CustomModelViewSet):
    queryset = Workflow.objects.all()
    serializer_class = WorkflowSerializer
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    search_fields = ['name']
    filter_fields = ['name', 'id', 'type']
    lookup_field = 'secret'

    def get_serializer_class(self):
        if self.action in ['list', 'retrieve']:
            return WorkflowReadSerializer
        return WorkflowSerializer


class StateViewSet(CustomModelViewSet):
    queryset = State.objects.all()
    serializer_class = StateSerializer
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    search_fields = ['name']
    filter_fields = ['workflow', 'is_hidden']
    ordering_fields = ['state_type', 'order_id']
    lookup_field = 'secret'


class TransitionViewSet(CustomModelViewSet):
    queryset = Transition.objects.all()
    serializer_class = TransitionSerializer
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    search_fields = ['name']
    filter_fields = ['workflow', 'transition_type', 'source_state', 'dest_state']
    lookup_field = 'secret'

    def get_serializer_class(self):
        if self.action in ['list', 'retrieve']:
            return TransitionReadSerializer
        return TransitionSerializer


class CustomFieldViewSet(CustomModelViewSet):
    queryset = CustomField.objects.all()
    serializer_class = CustomFieldSerializer
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    search_fields = ['field_name']
    filter_fields = ['workflow', 'field_type']
    ordering_fields = ['field_type', 'order_id']
    lookup_field = 'secret'


class WorkflowBpmnViewSet(CustomModelViewSet):
    queryset = WorkflowBpmn.objects.filter()
    serializer_class = WorkflowBpmnSerializer
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    lookup_field = 'secret'

from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = '初始化工作流'

    def handle(self, *args, **options):
        # topmenu = Menu.objects.get(name='top', code='top')
        self.stdout.write(self.style.SUCCESS('############ 初始化工作流菜单 ###########'))

        self.stdout.write(self.style.SUCCESS('初始化完成'))
        self.stdout.write(self.style.ERROR('初始化失败'))
        self.stdout.write(self.style.WARNING('初始化警告'))
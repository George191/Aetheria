from schema.admin.workflow.models import Workflow, State, Transition, CustomField, WorkflowType, WorkflowBpmn
from schema.admin.permission.models import Role

from rest_framework import serializers
from schema.admin.permission.serializers import CustomModelSerializer



class WorkflowReadSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = Workflow
        fields = '__all__'
        depth = 1


class WorkflowSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]

    Returns:
        [type]: [description]
    """
    class Meta:
        model = Workflow
        fields = '__all__'

    def create(self, validated_data):
        roles = validated_data.pop('roles')
 
        obj = Workflow.objects.create(**validated_data)
        obj.roles.add(Role.objects.get(roleName=roles[0]))
        obj.save()
        
        # 建立初始和结束状态
        State.objects.create(name="开始", order_id=1, state_type=1, is_hidden=True, part_type=0, workflow=obj)
        State.objects.create(name="关闭", order_id=99, state_type=2, is_hidden=True, part_type=0, workflow=obj)

        # 建立内置字段
        CustomField.objects.create(field_name="申请人", order_id=1, field_attr=True, field_type=1,
                                   field_key="create_user", workflow=obj)
        CustomField.objects.create(field_name="申请时间", order_id=2, field_attr=True, field_type=6,
                                   field_key="create_time", workflow=obj)
        CustomField.objects.create(field_name="部门", order_id=3, field_attr=True, field_type=1, field_key="group",
                                   workflow=obj)
        CustomField.objects.create(field_name="工号", order_id=4, field_attr=True, field_type=1, field_key="id",
                                   workflow=obj)

        return obj


class WorkflowTypeSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]

    Returns:
        [type]: [description]
    """
    workflow_list = serializers.SerializerMethodField()
    # workflow_set = WorkflowSerializer(many=True, read_only=True,)

    def get_workflow_list(self, instance):
        a = instance.workflow_set.get_queryset().filter(status=True)
        return a.values()

    class Meta:
        model = WorkflowType
        fields = '__all__'


class StateReadSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = State
        fields = '__all__'
        depth = 1


class StateSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = State
        fields = '__all__'


class TransitionReadSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = Transition
        fields = '__all__'
        depth = 2


class TransitionSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = Transition
        fields = '__all__'


class CustomFieldSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = CustomField
        fields = '__all__'


class WorkflowBpmnSerializer(CustomModelSerializer):
    """[summary]

    Args:
        CustomModelSerializer ([type]): [description]
    """
    class Meta:
        model = WorkflowBpmn
        fields = '__all__'
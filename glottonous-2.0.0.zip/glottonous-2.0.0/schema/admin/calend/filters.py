import django_filters
from schema.admin.calend.models import Calendar


class CalendarFilter(django_filters.rest_framework.FilterSet):
    """
    基于日历名称进行过滤
    """
    CalendarName = django_filters.CharFilter(lookup_expr='icontains')

    class Meta:
        model = Calendar
        exclude = ('title', 'notes', 'creator', 'modifier')




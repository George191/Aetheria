'''
Author: your name
Date: 2022-04-08 14:40:28
LastEditTime: 2022-04-12 14:57:14
LastEditors: your name
Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
FilePath: /backend/apps/admin/calend/serializers.py
'''
from schema.admin.calend.models import (
    Calendar, CalendarTag,
)
from schema.admin.permission.serializers import CustomModelSerializer

from rest_framework import serializers


class CalendarTagSerializer(CustomModelSerializer):
    """[summary]

    Args:
        serializers ([type]): [description]
    """
    class Meta:
        model = CalendarTag
        exclude = ('id',)


class CalendarSerializer(CustomModelSerializer):
    """[summary]

    Args:
        serializers ([type]): [description]
    """
    tags_name = serializers.SerializerMethodField()

    class Meta:
        model = Calendar
        exclude = ('id',)

    def get_tags_name(self, obj):
        return obj.tags.name




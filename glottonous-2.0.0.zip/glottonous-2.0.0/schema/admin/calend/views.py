'''
Author: your name
Date: 2022-04-08 14:40:28
LastEditTime: 2022-04-12 14:55:33
LastEditors: your name
Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
FilePath: /backend/apps/admin/calend/views.py
'''
from schema.admin.calend.serializers import (
    CalendarSerializer, CalendarTagSerializer
)
from schema.admin.calend.models import (
    Calendar, CalendarTag
)
from schema.admin.calend.filters import CalendarFilter
from schema.admin.permission.permissions import CommonPermission

from utils.operations.filters import DataLevelPermissionsFilter
from utils.operations.viewsets import CustomModelViewSet



class CalendarViewSet(CustomModelViewSet):
    """[summary]

    Args:
        ModelViewSet ([type]): [description]
    """
    queryset = Calendar.objects.filter()
    serializer_class = CalendarSerializer
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    filter_class = CalendarFilter
    extra_filter_backends = [DataLevelPermissionsFilter]
    search_fields = ('title', 'notes')
    ordering = '-create_datetime'
    lookup_field = 'secret'


class CalendarTagViewSet(CustomModelViewSet):
    """[summary]

    Args:
        ModelViewSet ([type]): [description]
    """
    queryset = CalendarTag.objects.filter()
    serializer_class = CalendarTagSerializer
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    search_fields = ('name', 'description')
    ordering = '-create_datetime'
    lookup_field = 'secret'

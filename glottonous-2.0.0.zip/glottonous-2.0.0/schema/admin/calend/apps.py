from django.apps import AppConfig


class CalendConfig(AppConfig):
    name = 'calend'

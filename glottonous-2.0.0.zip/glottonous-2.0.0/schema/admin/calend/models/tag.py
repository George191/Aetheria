'''
Author: your name
Date: 2022-04-08 14:40:28
LastEditTime: 2022-04-12 14:52:48
LastEditors: your name
Description: 打开koroFileHeader查看配置 进行设置: https://github.com/OBKoro1/koro1FileHeader/wiki/%E9%85%8D%E7%BD%AE
FilePath: /backend/apps/admin/calend/models/tag.py
'''
from django.db.models import (CharField, TextField)
from utils.operations.models import CoreModel


# Create your models here.
class CalendarTag(CoreModel):
    COLOR_CHOICES = (
        ('green', 'success'),
        ('red', 'danger'),
        ('yellow', 'warning'),
    )
    """
    
    """
    name = CharField(max_length=200, verbose_name='名称', help_text='名称')
    color = CharField(max_length=64, verbose_name='显示颜色', help_text='颜色')

    class Meta:
        app_label = 'calend'
        verbose_name = '日历标签'
        verbose_name_plural = '日历标签'
    
    def __str__(self):
        return self.name
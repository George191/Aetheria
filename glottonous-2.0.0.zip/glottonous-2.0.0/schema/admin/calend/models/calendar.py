from utils.operations.models import CoreModel
from django.db.models import (CharField, URLField, DateField, TextField, CASCADE, ForeignKey)



class Calendar(CoreModel):
    """
    可在每月日历一眼确认所有日程
    能自动调整画面大小,因此就算日程再多,也能让使用者一眼确认日程
    """
    title = CharField(max_length=200, verbose_name='标题', blank=True, null=True, help_text='标题')
    start_date = DateField(verbose_name='开始时间', help_text='开始时间', blank=True, null=True)
    stop_date = DateField(verbose_name='结束时间', help_text='结束时间', blank=True, null=True)
    notes = TextField(verbose_name='注释', help_text='注释', blank=True, null=True)
    uri = URLField(max_length=200, verbose_name='URI', help_text='URI', blank=True, null=True)
    tags = ForeignKey(to='calend.CalendarTag', on_delete=CASCADE, help_text='tag外键')

    def __str__(self):
        return self.title

    class Meta:
        app_label = 'calend'
        verbose_name = '日历'
        verbose_name_plural = '日历'

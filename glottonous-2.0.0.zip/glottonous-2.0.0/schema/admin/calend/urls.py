from rest_framework.routers import DefaultRouter
from schema.admin.calend.views import (
    CalendarViewSet, CalendarTagViewSet
)


router = DefaultRouter()
router.register(r'calendar', CalendarViewSet)
router.register(r'calendar-tag', CalendarTagViewSet)

urlpatterns = router.urls


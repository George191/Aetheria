from django.core.management.base import BaseCommand
from schema.admin.permission.models import *
from schema.admin.permission.tools import init_menu
from django.contrib.auth.hashers import make_password


class Command(BaseCommand):
    """
    初始化默认部门，岗位，角色，用户，以及已有的菜单
    """
    help = '初始化 菜单 角色 用户 岗位 部门'

    def handle(self, *args, **options):
      """
      部门数据初始化
      """
      try:
        self.stdout.write(self.style.SUCCESS('############ 初始化部门 ###########'))
        has_dept = Dept.objects.count()
        if not has_dept:
          dept = Dept.objects.create(
            id=0,
            deptName='北京盘拓数据科技有限公司', 
            orderNum=0, 
            owner='周宇', 
            phone='13293359750', 
            email='zhouyu674896488@gmail.com', 
            status=1, 
            parentId=None,
            dept_belong_id=0
          )
      except Exception as e:
        self.stdout.write(self.style.ERROR(f'错误: 初始化部门失败 -> {e}'))
      """
      岗位数据初始化
      """
      try:
        self.stdout.write(self.style.SUCCESS('############ 初始化岗位 ###########'))
        has_post = Post.objects.count()
        if not has_post:
          post = Post.objects.create(
            id=0,
            postName='数据运维', 
            postCode='data-maintenance', 
            postSort=0, 
            status=1,
            remark='数据运维，针对目标系统所有数据进行统一维护及修正',
            dept_belong_id=0
          )
      except Exception as e:
        self.stdout.write(self.style.ERROR(f'错误: 初始化岗位失败 -> {e}'))
      """
      角色数据初始化
      """
      try:
        self.stdout.write(self.style.SUCCESS('############ 初始化角色 ###########'))
        has_role = Role.objects.count()
        if not has_role:
          role = Role.objects.create(
            id=0,
            roleName='超级管理员', 
            roleKey='admin', 
            roleSort=0, 
            status=1,
            admin=True,
            dataScope=0,
            remark='系统超级管理员，拥有全部权限',
            dept_belong_id=0
          )
          role.dept.add(dept)  
      except Exception as e:
        self.stdout.write(self.style.ERROR(f'错误: 初始化角色失败 -> {e}'))
      """
      用户数据初始化
      """
      try:
        self.stdout.write(self.style.SUCCESS('############ 初始化用户 ###########'))
        has_user = UserProfile.objects.count()
        if not has_user:
          user = UserProfile.objects.create(
            id=0,
            password=make_password('admin'),
            username='admin', 
            email='674896488@qq.com', 
            mobile='13293359750', 
            name='周宇',
            gender='男',
            birth='1993-04-15',
            user_type=0,
            status=1,
            dept_belong_id=0,
            is_superuser=True,
            first_name='周',
            last_name='宇',
            is_staff=True,
            is_active=True,
            dept=Dept.objects.get(deptName='北京盘拓数据科技有限公司')
          )
          user.post.add(post)
          user.role.add(role)
      except Exception as e:
        self.stdout.write(self.style.ERROR(f'错误: 初始化用户失败 -> {e}'))
      """
      菜单数据初始化
      """
      try:
        self.stdout.write(self.style.SUCCESS('############ 初始化权限菜单 ###########'))
        permission_menu = Menu.objects.create(
          parentId=None,
          menuType=0,
          icon='ion:people',
          name='权限管理',
          orderNum=2,
          isFrame=False,
          web_path='permission',
          component_path='src/views/permission/',
          status=1,
          visible=1,
          isCache=0,
          dept_belong_id=0,
          creator_id=0
        )
        role.menu.add(permission_menu)
      except Exception as e:
        self.stdout.write(self.style.ERROR(f'错误: 初始化部门菜单失败 -> {e}'))

      try:
        role_menu = Menu.objects.create(
          parentId=permission_menu,
          menuType=1,
          icon='ion:id-card-outline',
          name='角色管理',
          orderNum=2,
          isFrame=False,
          web_path='permission/role',
          interface_path='admin/permission/role',
          interface_method='GET',
          component_path='src/views/permission/role/',
          status=1,
          visible=1,
          isCache=0,
          dept_belong_id=0,
          creator_id=0
        )
        role.menu.add(role_menu)
        init_menu(role_menu)
      except Exception as e:
        self.stdout.write(self.style.ERROR(f'错误: 初始化角色菜单失败 -> {e}'))

      try:
        dept_menu = Menu.objects.create(
          parentId=permission_menu,
          menuType=1,
          icon='ion:business',
          name='部门管理',
          orderNum=2,
          isFrame=False,
          web_path='permission/dept',
          interface_path='admin/permission/dept',
          component_path='src/views/permission/dept/',
          interface_method='GET',
          status=1,
          visible=1,
          isCache=0,
          dept_belong_id=0,
          creator_id=0
        )
        role.menu.add(dept_menu)
        init_menu(dept_menu)
      except Exception as e:
        self.stdout.write(self.style.ERROR(f'错误: 初始化部门菜单失败 -> {e}'))

      try:
        post_menu = Menu.objects.create(
          parentId=permission_menu,
          menuType=1,
          icon='ion:ios-medal',
          name='岗位管理',
          orderNum=2,
          isFrame=False,
          web_path='permission/post',
          interface_path='admin/permission/post',
          component_path='src/views/permission/post/',
          interface_method='GET',
          status=1,
          visible=1,
          isCache=0,
          creator_id=0,
          dept_belong_id=0,
        )
        role.menu.add(post_menu)
        init_menu(post_menu)
      except Exception as e:
        self.stdout.write(self.style.ERROR(f'错误: 初始化岗位菜单失败 -> {e}'))

      try:
        user_menu = Menu.objects.create(
          parentId=permission_menu,
          menuType=1,
          icon='ion:person',
          name='用户管理',
          orderNum=2,
          isFrame=False,
          web_path='permission/user',
          interface_path='admin/permission/user',
          component_path='src/views/permission/user/',
          interface_method='GET',
          status=1,
          visible=1,
          isCache=0,
          dept_belong_id=0,
          creator_id=0
        )
        role.menu.add(user_menu)
        init_menu(user_menu)
      except Exception as e:
        self.stdout.write(self.style.ERROR(f'错误: 初始化用户菜单失败 -> {e}'))

      try:
        menu_menu = Menu.objects.create(
          parentId=permission_menu,
          menuType=1,
          icon='ion:list-outline',
          name='菜单管理',
          orderNum=2,
          isFrame=False,
          web_path='permission/menu',
          interface_path='admin/permission/menu',
          component_path='src/views/permission/menu/',
          interface_method='GET',
          status=1,
          visible=1,
          isCache=0,
          dept_belong_id=0,
          creator_id=0,
        )
        role.menu.add(menu_menu)
        init_menu(menu_menu)
      except Exception as e:
        self.stdout.write(self.style.ERROR(f'错误: 初始化菜单菜单失败 -> {e}'))
      self.stdout.write(self.style.SUCCESS('初始化菜单完成'))

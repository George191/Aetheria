#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:54
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :dept.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.utils.translation import ugettext_lazy as _
from django.db import models
from utils.operations.models import CoreModel


class Dept(CoreModel):
    deptName = models.CharField(max_length=64, verbose_name=_("部门名称"))
    orderNum = models.PositiveSmallIntegerField(verbose_name=_("显示排序"))
    owner = models.CharField(max_length=32, verbose_name=_("负责人"), null=True, blank=True)
    phone = models.CharField(max_length=32, verbose_name=_("联系电话"), null=True, blank=True)
    email = models.CharField(max_length=32, verbose_name=_("邮箱"), null=True, blank=True)
    status = models.CharField(max_length=8, verbose_name=_("部门状态"), null=True, blank=True)
    parentId = models.ForeignKey(to='permission.Dept', on_delete=models.CASCADE, default=False, verbose_name=_("上级部门"),
                          db_constraint=False, null=True, blank=True)

    class Meta:
        app_label = "permission"
        verbose_name = '部门管理'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.deptName}"

#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:54
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :__init__.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司

from schema.admin.permission.models.dept import Dept
from schema.admin.permission.models.menu import Menu
from schema.admin.permission.models.post import Post
from schema.admin.permission.models.role import Role
from schema.admin.permission.models.users import UserProfile

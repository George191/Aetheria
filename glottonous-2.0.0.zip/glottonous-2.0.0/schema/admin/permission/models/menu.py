#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:54
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :menu.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.core.cache import cache
from django.utils.translation import ugettext_lazy as _
from django.db import models
from utils.operations.models import CoreModel


class Menu(CoreModel):

    parentId = models.ForeignKey(to='Menu', on_delete=models.CASCADE, verbose_name=_("上级菜单"), null=True, blank=True, db_constraint=False)
    menuType = models.CharField(max_length=8, verbose_name=_("菜单类型"))
    icon = models.CharField(max_length=64, verbose_name=_("菜单图标"), null=True, blank=True)
    name = models.CharField(max_length=64, verbose_name=_("菜单名称"))
    orderNum = models.PositiveSmallIntegerField(_("显示排序"))
    isFrame = models.CharField(max_length=8, verbose_name=_("是否外链"))
    web_path = models.CharField(max_length=128, verbose_name=_("前端路由地址"), null=True, blank=True)
    component_path = models.CharField(max_length=128, verbose_name=_("前端组件路径"), null=True, blank=True)
    interface_path = models.CharField(max_length=256, verbose_name=_("后端接口路径"), null=True, blank=True)
    interface_method = models.CharField(max_length=16, default='GET', verbose_name=_("接口请求方式"))
    perms = models.CharField(max_length=256, verbose_name=_("权限标识"), null=True, blank=True)
    status = models.CharField(max_length=8, verbose_name=_("菜单状态"))
    visible = models.CharField(max_length=8, verbose_name=_("显示状态"))
    isCache = models.CharField(max_length=8, verbose_name=_("是否缓存"))

    @classmethod
    def get_interface_dict(cls):
        """
        获取所有接口列表
        :return:
        """
        try:
            interface_dict = cache.get('permission_interface_dict', {})
        except:
            interface_dict = {}
        if not interface_dict:
            for ele in Menu.objects.filter(~models.Q(interface_path=''), ~models.Q(interface_path=None), status='1', ).values(
                    'interface_path', 'interface_method'):
                if ele.get('interface_method') in interface_dict:
                    interface_dict[ele.get('interface_method', '')].append(ele.get('interface_path'))
                else:
                    interface_dict[ele.get('interface_method', '')] = [ele.get('interface_path')]
            cache.set('permission_interface_dict', interface_dict, 84600)
        return interface_dict

    @classmethod
    def delete_cache(cls):
        """
        清空缓存中的接口列表
        :return:
        """
        cache.delete('permission_interface_dict')

    class Meta:
        app_label = "permission"
        verbose_name = '菜单管理'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.name}"

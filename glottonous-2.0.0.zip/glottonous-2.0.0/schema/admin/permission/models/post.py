#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:54
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :post.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.utils.translation import ugettext_lazy as _
from django.db import models
from utils.operations.models import CoreModel


class Post(CoreModel):
    postName = models.CharField(null=False, max_length=64, verbose_name=_("岗位名称"))
    postCode = models.CharField(max_length=32, verbose_name=_("岗位编码"))
    postSort = models.PositiveSmallIntegerField(verbose_name=_("岗位顺序"))
    status = models.CharField(max_length=8, verbose_name=_("岗位状态"))
    remark = models.TextField(verbose_name=_("备注"), help_text="备注", null=True, blank=True)

    class Meta:
        app_label = "permission"
        verbose_name = '岗位管理'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.postName}"

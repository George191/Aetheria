#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:55
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :users.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司
import uuid
from uuid import uuid4
import os
from django.conf import settings
from django.contrib.auth.models import UserManager, AbstractUser
from django.core.cache import cache
from django.utils.translation import ugettext_lazy as _
from django.db import models
from django_minio_backend import MinioBackend

from utils.operations.models import CoreModel


def upload_avatar(instance, file_name):
    return os.path.join('user', instance.username, 'avatar', f'{uuid.uuid4()}{os.path.splitext(file_name)[-1]}')


class UserProfile(AbstractUser, CoreModel):

    objects = UserManager()
    username = models.CharField(max_length=150, unique=True, db_index=True, verbose_name=_('用户账号'))
    secret = models.CharField(max_length=255, default=uuid4, verbose_name=_('加密秘钥'), unique=True)
    email = models.CharField(max_length=255, verbose_name=_("邮箱"), null=True, blank=True)
    mobile = models.CharField(max_length=255, verbose_name=_("电话"), null=True, blank=True)
    avatar = models.FileField(_('头像'), storage=MinioBackend(bucket_name='public'), upload_to=upload_avatar, null=True)
    name = models.CharField(max_length=40, verbose_name=_("姓名"))
    gender = models.CharField(max_length=8, verbose_name=_("性别"), null=True, blank=True)
    birth = models.DateField(verbose_name=_("生日"), null=True, blank=True)
    user_type = models.PositiveSmallIntegerField(default=0, verbose_name=_("用户类型"))
    post = models.ManyToManyField(to='permission.Post', verbose_name=_('关联岗位'), db_constraint=False)
    role = models.ManyToManyField(to='permission.Role', verbose_name=_('关联角色'), db_constraint=False)
    dept = models.ForeignKey(to='permission.Dept', verbose_name=_('归属部门'), on_delete=models.CASCADE, db_constraint=False, null=True, blank=True)
    status = models.CharField(max_length=32, verbose_name=_('状态'), default=0)

    @property
    def get_user_interface_dict(self):
        interface_dict = cache.get(f'permission_interface_dict_{self.username}', {})
        if not interface_dict:
            for ele in self.role.filter(status='1', menu__status='1').values('menu__interface_path',
                                                                             'menu__interface_method').distinct():
                interface_path = ele.get('menu__interface_path')
                if interface_path is None or interface_path == '':
                    continue
                if ele.get('menu__interface_method') in interface_dict:
                    interface_dict[ele.get('menu__interface_method', '')].append(interface_path)
                else:
                    interface_dict[ele.get('menu__interface_method', '')] = [interface_path]
            cache.set(f'permission_interface_dict_{self.username}', interface_dict, 84600)
        return interface_dict
    
    def last_seen(self):
        return cache.get('last_seen_%s' % self.user.username)
            
    @property
    def delete_cache(self):
        """
        清空缓存中的接口列表
        :return:
        """
        return cache.delete(f'permission_interface_dict_{self.username}')

    class Meta:
        app_label = "permission"
        abstract = settings.AUTH_USER_MODEL != 'permission.UserProfile'
        verbose_name = '用户管理'
        verbose_name_plural = verbose_name

    def __str__(self):
        if self.name:
            return f"{self.username}({self.name})"
        return f"{self.username}"

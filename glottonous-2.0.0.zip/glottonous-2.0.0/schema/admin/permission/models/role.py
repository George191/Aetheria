#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:55
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :role.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.utils.translation import ugettext_lazy as _
from django.db import models
from utils.operations.models import CoreModel


class Role(CoreModel):
    DATASCOPE_CHOICES = (
        (0, "全部数据权限"),
        (1, "自定数据权限"),
        (2, "本部门数据权限"),
        (3, "本部门及以下数据权限"),
        (4, "仅本人数据权限"),
    )
    roleName = models.CharField(max_length=64, verbose_name=_("角色名称"))
    roleKey = models.CharField(max_length=64, verbose_name=_("权限字符"))
    roleSort = models.PositiveSmallIntegerField(verbose_name=_("角色顺序"))
    status = models.CharField(max_length=8, verbose_name=_("角色状态"))
    admin = models.BooleanField(default=False, verbose_name=_("是否为admin"))
    dataScope = models.SmallIntegerField(default=0, choices=DATASCOPE_CHOICES, verbose_name=_("权限范围"))
    remark = models.TextField(verbose_name=_("备注"), help_text="备注", null=True, blank=True)
    dept = models.ManyToManyField(to='permission.Dept', verbose_name=_('数据权限-关联部门'), db_constraint=False)
    menu = models.ManyToManyField(to='permission.Menu', verbose_name=_('关联菜单权限'), db_constraint=False)

    class Meta:
        app_label = "permission"
        verbose_name = '角色管理'
        verbose_name_plural = verbose_name

    def __str__(self):
        return f"{self.roleName}"

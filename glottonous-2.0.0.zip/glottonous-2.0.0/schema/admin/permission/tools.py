from permission.models import Menu, Role


# 新增菜单后自动添加菜单下的常规操作
def init_menu(menu):
    menu_list = [
        {"name": "新增", "web_path": menu.web_path if menu.web_path else '', "orderNum": 0, 'interface_method': 'POST', 'component_path': menu.component_path + 'insert/'},
        {"name": "删除", "web_path": menu.web_path if menu.web_path else '', "orderNum": 1, 'interface_method': 'DELETE', 'component_path': menu.component_path + 'delete/'},
        {"name": "编辑", "web_path": menu.web_path if menu.web_path else '', "orderNum": 2, 'interface_method': 'PUT', 'component_path': menu.component_path + 'update/'},
        {"name": "查看", "web_path": menu.web_path if menu.web_path else '' + "/:id", "orderNum": 3, 'interface_method': 'GET', 'component_path': menu.component_path + 'retrieve/'},
    ]

    try:
        role = Role.objects.get(roleName='超级管理员')
    except:
        raise KeyError('错误: 超级管理员不存在,请创建后重试!')

    for item in menu_list:
        new_menu = Menu.objects.create(name=item['name'], web_path=item['web_path'], menuType=menu.menuType + 1, interface_method=item['interface_method'],
                                orderNum=item['orderNum'], parentId=menu, isFrame=False, is_delete=False, dept_belong_id=0,
                                status=1, visible=0, isCache=0, interface_path=item['web_path'], component_path=item['component_path'], creator_id=0)
        role.menu.add(new_menu)
    

from schema.admin.permission.serializers import CustomModelSerializer
from schema.admin.todo.models import Todo

class TodoSerializer(CustomModelSerializer):
    """[summary]

    Args:
        serializers ([type]): [description]
    """
    class Meta:
        model = Todo
        exclude = ('id',)
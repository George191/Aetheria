from utils.operations.models import CoreModel
from django.db.models import (TextField, BooleanField, CharField)


# Create your models here.

class Todo(CoreModel):
    title = CharField(max_length=200, verbose_name='标题', blank=True, null=True)
    description = TextField(verbose_name='描述', blank=True, null=True)
    is_important = BooleanField(default=0, verbose_name='重要')
    is_starred = BooleanField(default=0, verbose_name='星标')
    is_completed = BooleanField(default=0, verbose_name='完成')
    is_trashed = BooleanField(default=0, verbose_name='删除')

    def __str__(self):
        return self.title

    class Meta:
        verbose_name = '待办清单'
        verbose_name_plural = '待办清单'

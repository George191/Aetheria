from schema.admin.todo.serializers import TodoSerializer
from schema.admin.todo.models import Todo
from schema.admin.todo.filters import TodoFilter
from schema.admin.permission.permissions import CommonPermission

from utils.operations.filters import DataLevelPermissionsFilter
from utils.operations.viewsets import CustomModelViewSet


class TodoViewSet(CustomModelViewSet):
    """[summary]

    Args:
        ModelViewSet ([type]): [description]
    """
    queryset = Todo.objects.filter(is_trashed=False)
    serializer_class = TodoSerializer
    update_extra_permission_classes = (CommonPermission,)
    destroy_extra_permission_classes = (CommonPermission,)
    create_extra_permission_classes = (CommonPermission,)
    filter_class = TodoFilter
    extra_filter_backends = [DataLevelPermissionsFilter]
    search_fields = ('title', 'description')
    ordering = '-create_datetime'
    lookup_field = 'secret'

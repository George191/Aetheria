import django_filters
from schema.admin.todo.models import Todo


class TodoFilter(django_filters.rest_framework.FilterSet):

    TodoName = django_filters.CharFilter(lookup_expr='icontains')

    class Meta:
        model = Todo
        exclude = ('title', 'description', 'is_important', 'is_starred', 'is_completed', 'is_trashed', 'creator', 'modifier')
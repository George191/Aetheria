#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:33
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :tasks.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from utils.decorators import BaseCeleryApp

from django.template import loader
from django.core.mail import EmailMultiAlternatives


@BaseCeleryApp(name='apps.admin.auth.tasks.end_email_task', save_success_logs=False)
def send_email_task(subject_template_name, email_template_name,
                  context, from_email, to_email, html_email_template_name=None):
    """Celery 任务，用于发送有重置密码的电子邮件通知。"""
    """
    Send a django.core.mail.EmailMultiAlternatives to `to_email`.
    """
    subject = loader.render_to_string(subject_template_name, context)
    # Email subject *must not* contain newlines
    subject = ''.join(subject.splitlines())
    body = loader.render_to_string(email_template_name, context)

    email_message = EmailMultiAlternatives(subject, body, from_email, [to_email])
    if html_email_template_name is not None:
        html_email = loader.render_to_string(html_email_template_name, context)
        email_message.attach_alternative(html_email, 'text/html')

    email_message.send()
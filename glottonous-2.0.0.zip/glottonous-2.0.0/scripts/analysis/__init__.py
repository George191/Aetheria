#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/13 10:13
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :__init__.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from scripts.analysis.emotion import *
from scripts.analysis.estimate import *
from scripts.analysis.event import *
from scripts.analysis.location import *
from scripts.analysis.major import *
from scripts.analysis.regnorization import *
from scripts.analysis.wordfreq import *

from application.service.command.models import Ship
from application.service.resources.models import Timeline


class ObjectsForAnalysis:

    def __init__(self) -> None:
        AnalysisMajorUser()

    def get_objects(self):
        objects = Ship.nodes.filter(is_delete=False)

        for obj in objects:

            while 1:
                posts = Timeline.objects.filter(is_delete=False, is_handled=False, obj_number=obj.obj_numer)[:500]
                if not len(posts): 
                    break
                for post in posts:
                    AnalysisEmotion(post)
                    AnalysisWordFreq(post)
                    event_active = AnalysisEvent(post, AnalysisRegnorization(post))
                    locat_active = AnalysisLocation(post)
                    estim_active = AnalysisEstimate(post)
                    
                    area, level = self.analysis_warning(post=post, location=locat_active, event=event_active, estimate=estim_active)

                    obj.area = area
                    obj.level = level
                    obj.is_handled = 1
                    obj.save()
                    

    def analysis_warning(self, post, location, event, estimate):
        if estimate:
            if location and event: return 'all', 2
            elif location or event: return 'location' if location else 'event', 1
            else: return 'estimate', 0
        else: return None, -1

#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/13 14:15
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :major.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from time import localtime
from application.service.resources.models import User
from application.service.analysis.models import EventMatch, LocationMatch, EstimateMatch
from application.service.command.models import Ship

import pandas as pd

class AnalysisMajorUser:

    def __init__(self) -> None:
        self.__algorithm__()
    
    @staticmethod
    def percentage(data, percent=0.05, number=10):
        data = data.sort_values(['count'], ascending=False)
        if percent:
            data = data.head(int(len(data) * percent))
        elif number:
            data = data[data['count'] >= number]
        return data['post_user']

    def __algorithm__(self) -> pd.DataFrame:
        ships = Ship.nodes.filter(is_delete=False)

        for ship in ships:
            obj_number = ship.obj_number
            event = pd.DataFrame.from_records(EventMatch.objects.filter(is_delete=False, obj_number=obj_number).values('post_user'))
            location = pd.DataFrame.from_records(LocationMatch.objects.filter(is_delete=False, obj_number=obj_number).values('post_user'))
            estimate = pd.DataFrame.from_records(EstimateMatch.objects.filter(is_delete=False, obj_number=obj_number).values('post_user'))

            count = pd.concat([event, location, estimate])

            group = count['post_user'].value_counts().reset_index()
            group.columns = ['post_user', 'count']
            data = self.percentage(group, percent=True, number=10)
            count = 0
            for i in data:
                try:
                    obj = User.objects.get(account=i, ship_hull_number=obj_number)
                    obj.star = 1
                    obj.save()
                    count += 1
                except:
                    pass
            print('{}: 星级账号：{}'.format(obj_number, count))
            

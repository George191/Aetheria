#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/01/26 15:32:08
# @Author      :周宇
# @Email       :zhouyu674896488@gmail.com
# @Version     :v1.0
# @File        :run_cnn.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


import warnings
import os
import tensorflow as tf
import pandas as pd
import numpy as np
from nltk.tokenize import word_tokenize
import re
import gc
import matplotlib.pyplot as plt
from sklearn.metrics import f1_score, confusion_matrix
from keras import backend as K
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.utils import to_categorical
from keras.models import Sequential, load_model
from keras.layers import Embedding, Conv1D, GlobalMaxPooling1D, Dense

from application.service.analysis.models import Emotion, emotion

class AnalysisEmotion:
    def __init__(self, train:str='data/data_train.csv', test:str='data/data_test.csv', model_path:str='models', post=''):
        super().__init__()
        # Number of labels: joy, anger, fear, sadness, neutral
        self.num_classes = 5
        # Number of dimensions for word embedding
        self.embed_num_dims = 300
        # Max input length (max number of words) 
        self.max_seq_len = 500
        self.class_names = ['joy', 'fear', 'anger', 'sadness', 'neutral']
        self.fname = 'embeddings/wiki-news-300d-1M.vec'
        self.df_train = pd.read_csv(train, encoding='utf-8')
        self.df_test = pd.read_csv(test, encoding='utf-8')
        self.x_train = self.df_train.Text
        self.x_test = self.df_test.Text
        self.y_train = self.df_train.Emotion
        self.y_test = self.df_test.Emotion
        self.data = self.df_train.append(self.df_test, ignore_index=True)

        texts = [' '.join(self.clean_text(text)) for text in self.data.Text]
        self.tokenizer = Tokenizer()
        self.tokenizer.fit_on_texts(texts)

        self.test(post)

    @staticmethod
    def clean_text(data):
        # remove hashtags and @usernames
        data = re.sub(r"(#[\d\w\.]+)", '', data)
        data = re.sub(r"(@[\d\w\.]+)", '', data)
        
        # tekenization using nltk
        data = word_tokenize(data)
        
        return data

    def train(self):
        texts_train = [' '.join(self.clean_text(text)) for text in self.x_train]
        texts_test = [' '.join(self.clean_text(text)) for text in self.x_test]
        sequence_train = self.tokenizer.texts_to_sequences(texts_train)
        sequence_test = self.tokenizer.texts_to_sequences(texts_test)
        index_of_words = self.tokenizer.word_index

        # vacab size is number of unique words + reserved 0 index for padding
        vocab_size = len(index_of_words) + 1
        x_train_pad = pad_sequences(sequence_train, maxlen=self.max_seq_len )
        x_test_pad = pad_sequences(sequence_test, maxlen=self.max_seq_len )

        encoding = {
            'joy': 0,
            'fear': 1,
            'anger': 2,
            'sadness': 3,
            'neutral': 4
        }

        # Integer labels
        y_train = [encoding[x] for x in self.df_train.Emotion]
        y_test = [encoding[x] for x in self.df_test.Emotion]
        y_train = to_categorical(y_train)
        y_test = to_categorical(y_test)

        embedd_matrix = self.create_embedding_matrix(self.fname, index_of_words, self.embed_num_dims)

        # Inspect unseen words
        new_words = 0

        for word in index_of_words:
            entry = embedd_matrix[index_of_words[word]]
            if all(v == 0 for v in entry):
                new_words = new_words + 1

        # Embedding layer before the actaul BLSTM 
        embedd_layer = Embedding(vocab_size, self.embed_num_dims, input_length=self.max_seq_len,
                                 weights=[embedd_matrix], trainable=False)

        # Convolution
        kernel_size = 3
        filters = 256

        model = Sequential()
        model.add(embedd_layer)
        model.add(Conv1D(filters, kernel_size, activation='relu'))
        model.add(GlobalMaxPooling1D())
        model.add(Dense(256, activation='relu'))
        model.add(Dense(self.num_classes, activation='softmax'))
        model.compile(loss = 'categorical_crossentropy', optimizer = 'adam', metrics = ['accuracy'])
        model.summary()

        batch_size = 128
        epochs = 15
        hist = model.fit(x_train_pad, y_train,  batch_size=batch_size, epochs=epochs,
                         validation_data=(x_test_pad, y_test))

        #  "Accuracy"
        plt.plot(hist.history['acc'])
        plt.plot(hist.history['val_acc'])
        plt.title('model accuracy')
        plt.ylabel('accuracy')
        plt.xlabel('epoch')
        plt.legend(['train', 'validation'], loc='upper left')
        plt.show()

        # "Loss"
        plt.plot(hist.history['loss'])
        plt.plot(hist.history['val_loss'])
        plt.title('model loss')
        plt.ylabel('loss')
        plt.xlabel('epoch')
        plt.legend(['train', 'validation'], loc='upper left')
        plt.show()

        predictions = model.predict(x_test_pad)
        predictions = np.argmax(predictions, axis=1)
        predictions = [self.class_names[pred] for pred in predictions]
        print("\nF1 Score: {:.2f}".format(f1_score(self.df_test.Emotion, predictions, average='micro') * 100))

        # Plot normalized confusion matrix
        self.plot_confusion_matrix(self.df_test.Emotion, predictions, classes=self.class_names, normalize=True, title='Normalized confusion matrix')
        plt.show()

        # creates a HDF5 file 'my_model.h5'
        model.save('models/biLstm_model')

    @staticmethod
    def plot_confusion_matrix(y_true, y_pred, classes, normalize=False, title=None, cmap=plt.cm.Blues):
        '''
        This function prints and plots the confusion matrix.
        Normalization can be applied by setting `normalize=True`.
        '''
        if not title:
            if normalize:
                title = 'Normalized confusion matrix'
            else:
                title = 'Confusion matrix, without normalization'

        # Compute confusion matrix
        cm = confusion_matrix(y_true, y_pred)

        if normalize:
            cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]

        fig, ax = plt.subplots()
        
        # Set size
        fig.set_size_inches(12.5, 7.5)
        im = ax.imshow(cm, interpolation='nearest', cmap=cmap)
        ax.figure.colorbar(im, ax=ax)
        ax.grid(False)
        
        # We want to show all ticks...
        ax.set(xticks=np.arange(cm.shape[1]), yticks=np.arange(cm.shape[0]), xticklabels=classes,
               yticklabels=classes, title=title, ylabel='True label', xlabel='Predicted label')

        # Rotate the tick labels and set their alignment.
        plt.setp(ax.get_xticklabels(), rotation=45, ha="right", rotation_mode="anchor")

        # Loop over data dimensions and create text annotations.
        fmt = '.2f' if normalize else 'd'
        thresh = cm.max() / 2.
        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                ax.text(j, i, format(cm[i, j], fmt),
                        ha="center", va="center",
                        color="white" if cm[i, j] > thresh else "black")

        fig.tight_layout()
        return ax

    @staticmethod
    def create_embedding_matrix(filepath, word_index, embedding_dim):
        vocab_size = len(word_index) + 1  # Adding again 1 because of reserved 0 index
        embedding_matrix = np.zeros((vocab_size, embedding_dim))
        with open(filepath) as f:
            for line in f:
                word, *vector = line.split()
                if word in word_index:
                    idx = word_index[word] 
                    embedding_matrix[idx] = np.array(
                        vector, dtype=np.float32)[:embedding_dim]
        return embedding_matrix

    def test(self, post):
        tf.compat.v1.logging.set_verbosity(tf.compat.v1.logging.ERROR)
        os.environ["TF_CPP_MIN_LOG_LEVEL"] = '2'
        warnings.filterwarnings('ignore')

        predictor = load_model('models/cnn_model')
        seq = self.tokenizer.texts_to_sequences(['{} {}'].format(post.title, post_content))
        padded = pad_sequences(seq, maxlen=self.max_seq_len)

        encoding = {
            0: 'joy',
            1: 'fear',
            2: 'anger',
            3: 'sadness',
            4: 'neutral'
        }

        label = encoding[np.argmax(predictor.predict(padded))]
        result = str({encoding[index]: score for index, score in enumerate(predictor.predict(padded).tolist()[0])})

        emotion = Emotion.objects.filter(post__post_id=post.id)
        if not len(emotion):
            Emotion.objects.create(
                post=post.secret, user=post.user, max_result=label, result=result, is_delete=False, creator='pattern'
            ).save()
        

        K.clear_session()
        del predictor, seq, padded
        gc.collect()

#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/13 14:16
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :regnorization.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from application.service.analysis.models import NameRecognition
from nltk.tag import StanfordNERTagger
from nltk.tokenize import word_tokenize
import os
import warnings
import string
from pathlib import Path
warnings.filterwarnings('ignore')
BASE_DIR = Path(__file__).resolve(strict=True).parent.parent

class AnalysisRegnorization:

    def __init__(self, post='') -> None:
        path = os.path.join(BASE_DIR, 'models', 'stanford-ner-2020-11-17')
        jar = os.path.join(path, 'stanford-ner.jar')
        model = os.path.join(path, 'classifiers', 'english.muc.7class.distsim.crf.ser.gz')
        self.st = StanfordNERTagger(model, jar, encoding='utf-8')

        self.post = post

    @staticmethod
    def get_continuous_chunks(tagged_sent):
        continuous_chunk = []
        current_chunk = []

        for token, tag in tagged_sent:
            if tag != "O":
                current_chunk.append((token, tag))
            else:
                if current_chunk: # if the current chunk is not empty
                    continuous_chunk.append(current_chunk)
                    current_chunk = []

        # Flush the final current_chunk into the continuous_chunk, if any.
        if current_chunk:
            continuous_chunk.append(current_chunk)

        return continuous_chunk

    @staticmethod
    def remove_emoji(text: str) -> str:
        import re

        regrex_pattern = re.compile(pattern = "["
            u"\U0001F600-\U0001F64F"  # emoticons
            u"\U0001F300-\U0001F5FF"  # symbols & pictographs
            u"\U0001F680-\U0001F6FF"  # transport & map symbols
            u"\U0001F1E0-\U0001F1FF"  # flags (iOS)
            "]+", flags = re.UNICODE)
        return regrex_pattern.sub('', text)

    @staticmethod
    def remove_punc(text:str) -> str:
        return text.strip(string.punctuation)

    @staticmethod
    def get_continuous_chunks(tagged_sent):
        continuous_chunk = []
        current_chunk = []

        for token, tag in tagged_sent:
            if tag != "O":
                current_chunk.append((token, tag))
            else:
                if current_chunk: # if the current chunk is not empty
                    continuous_chunk.append(current_chunk)
                    current_chunk = []

        # Flush the final current_chunk into the continuous_chunk, if any.
        if current_chunk:
            continuous_chunk.append(current_chunk)
        named_entities_str_tag = [(" ".join([token for token, tag in ne]), ne[0][1]) for ne in continuous_chunk]
        json = {value: key  for key, value in named_entities_str_tag}

        return json


    def __algorithm__(self) -> list:
        text = '{} {}'.format(self.post.title, self.post.content)
        text = self.remove_emoji(text)
        text = self.remove_punc(text)
        tokenized_text = word_tokenize(text)
        classified_text = self.st.tag(tokenized_text)
        result = self.get_continuous_chunks(classified_text)

        recognition = NameRecognition.objects.filter(post__post_id=self.post.id)
        if not len(recognition):
            NameRecognition.objects.create(
                post=self.post.secret, user=self.post.account.secret,
                ner_person=result.pop('PERSON') if 'PERSON' in result.keys() else '', 
                ner_organization=result.pop('ORGNAIZATION') if 'ORGANIZATION' in result.keys() else '',
                ner_date = result.pop('DATE') if 'DATE' in result.keys() else '',
                ner_time = result.pop('TIME') if 'TIME' in result.keys() else '',
                ner_city = result.pop('LOCATION') if 'LOCATION' in result.keys() else '',
                is_delete=False, creator='pattern'
            ).save()
        return result['LOCATION']

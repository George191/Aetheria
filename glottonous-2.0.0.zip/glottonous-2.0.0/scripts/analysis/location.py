#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/13 14:13
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :event.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from application.service.analysis.models import LocationMatch, LocationRule

try:
    import re2 as re
except ModuleNotFoundError:
    import re
from django.db.models import Q


class AnalysisLocation:

    def __init__(self, post) -> None:
        self.post = post
        return self.__run__()

    def __distinct__(self, secret) -> bool:
        return LocationMatch.objects.filter(rule=secret, post=self.post_secret).count()

    def __algorithm__(self) -> bool:
        for rule in LocationRule.objects.filter(Q(scope='All') | Q(scope=self.post.obj_number), is_delete=False, is_apply=True):
            if re.search(rule.re_exp or rule.ori_text, '{} {}'.format(self.post.title, self.post.content), flags=re.I if not rule.ignore_case else 0):
                if self.__distinct__(rule.secret):
                    return self.__create__(rule.secret)

    def __create__(self, secret) -> int:
        return LocationMatch.objects.create(
            rule=secret, user=self.post.user, post=self.post
        ).save()

    def __run__(self) -> None:
        return self.__algorithm__()

#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/13 14:18
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :wordfreq.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from application.service.analysis.models import WordFreq
from collections import Counter

import nltk
nltk.download('averaged_perceptron_tagger')

class AnalysisWordFreq:

    def __init__(self, post) -> None:
        self.post = post
        self.words = dict()
        self.tags = ('NN', 'NNS', 'NNP', 'VB', 'VBD', 'VBG', 'VBN', 'VBP', 'VBZ')
        self.__run__()

    def __distinct__(self) -> bool:
        return WordFreq.objects.filter(is_delete=False, post__post_time=self.post.post_time).count()

    def __algorithm__(self) -> dict:
        token = nltk.word_tokenize('{} {}'.format(
            self.post.title if self.post.title else '', 
            self.post.content if self.post.content else ''
        ))
        pos_tag = nltk.pos_tag(token)
        for word, pos in pos_tag:
            if pos in self.tags:
                if word in self.words: self.words[word] += 1
                else: self.words[word] = 1
        if self.__distinct__(): self.__update__()
        else: self.__create__()

    def __create__(self) -> int:
        WordFreq.objects.create(
            result=self.words, is_delete=False, creator='pattern'
        ).save()

    def __update__(self) -> int:
        obj = WordFreq.objects.get(post__post_time=self.post.post_time)
        old = Counter(eval(obj.result))
        new = Counter(self.words)
        obj.result = dict(old + new)
        obj.save()

    def __run__(self) -> None:
        self.__algorithm__()

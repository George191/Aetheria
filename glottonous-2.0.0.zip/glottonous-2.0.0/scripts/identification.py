#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/01/15 09:58:11
# @Author      :周宇
# @Email       :zhouyu674896488@gmail.com
# @Version     :v1.0
# @File        :authentication.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


import pandas as pd
import os
import datetime
import time

import os
import configparser
import pymysql

from schema.core.verifier.models import SeedBank, SpiderLog, Account, Friends, Posts

from django.conf import settings

from celery import Celery

celery = Celery(__name__)
celery.config_from_object(__name__)

conf = configparser.ConfigParser()
conf.read(os.path.join(getattr(settings, 'BASE_DIR'), 'scripts', 'conf.ini'))

class ConnectMySQL:
    
    def __init__(self, types:str=None, logger=None):
        self.con = pymysql.connect(
            host        = conf[types]['HOST'],
            user        = conf[types]['USER'],
            password    = conf[types]['PASSWORD'],
            db          = conf[types]['NAME']
        )
        self.deployment_columns = conf['Identification']['DEPLOYMENT_COLUMNS']
        self.keywords_columns = conf['Identification']['KEYWORDS_COLUMNS']
        
    def get_cursor(self):
        self.cursor = self.con.cursor()

    def commit(self):
        self.con.commit()

    def close_cursor(self):
        self.cursor.close()

    def close_con(self):
        self.con.close()

    def get_deployment_columns(self) -> list:
        return eval(self.deployment_columns)

    def get_keywords_columns(self) -> list:
        return eval(self.keywords_columns)

    def fetch_sql(self, columns:str, table:str, conditional:str) -> str:
        sql = """
            SELECT {} FROM {} WHERE {};
        """
        return sql.format(columns, table, conditional)

    def insert_sql(self, table:str, columns:str) -> str:
        sql = """
            INSERT INTO {} ({}) VALUES ({});
        """

        sql.format(table, columns, ','.join(['%s' for _ in columns.split(',')]))


def time_to_list(dataframe: pd.DataFrame) -> list:
    """[summary]

    Args:
        dataframe (pd.DataFrame): [pandas type]

    Returns:
        list: [start_time, end_time to list]
    """
    return dataframe['start_time'].tolist(), dataframe['end_time'].tolist()


def ext_days(start:list, end:list, days:int=2) -> list:
    """[summary]

    Args:
        start ([list]): [start_time]
        end ([list]): [end_time]
        days (int, optional): [date zoom, default two days]. Defaults to 2.

    Returns:
        [list]: [date after scaling]
    """
    return [[s + datetime.timedelta(days=-days),
             e + datetime.timedelta(days=days)]
            for s, e in zip(start, end)]


def vector_score(range_time:list, staff_speech:pd.DataFrame) -> pd.DataFrame:
    """[summary]

    Args:
        range_time ([list]): [time limit]
        staff_speech ([pd.DataFrame]): [personnel speech data]

    Returns:
        [pd.DataFrame]: [personnel speech data score]
    """
    for date_range in range_time:
        try:
            date_range = pd.DataFrame(pd.date_range(date_range[0], date_range[1])).reset_index()
        except:
            continue
        date_range.columns = ['index', 'date']
        date_range = date_range['date'].astype(str).tolist()
        if len(staff_speech):
            staff_speech.loc[staff_speech['post_time'].isin(date_range), 'score'] = 1

    staff_speech['post_time'] = staff_speech['post_time'].apply(lambda x: str(x).split()[0])
    staff_score = staff_speech['account'].value_counts()
    staff_score = staff_score.reset_index()
    return staff_score

def proportion(spider_count:int, total_count:int) -> float:

    try:
        result = spider_count / total_count
    except ZeroDivisionError:
        result = 0.0
    finally:
        return result

class Identification:

    def __init__(self, names:list, secret:str):
        # super().__init__(_ConnectMySQL__type='koms.raw')
        self.secret = secret
        self.names = names     # 验证名单
        data = pd.DataFrame(names, columns=['account', 'obj_number', 'obj_types']).astype(str)
        self.read_db(data['account'].tolist(), data['obj_number'][0], data['obj_types'][0])

    def read_db(self, names:list, obj_number:str, obj_type:str):
        self.timeline = pd.DataFrame(Posts.objects.filter(account__in=names).values()).astype(str)
        self.friends = pd.DataFrame(Friends.objects.filter(source_account__in=names).values()).astype(str)
        self.info = pd.DataFrame(Account.objects.filter(object_number=obj_number).values()).astype(str)

        db_type = 'koms.ship' if obj_type == '航母' else 'koms.base'
        self.regular(types=db_type, obj_number=obj_number, obj_type=obj_type)

    def event_extract(self, regrex, case=False):
        prepare_list = locals()
        for column in self.timeline.columns:
            temporary = self.timeline[self.timeline[column].notna()]
            prepare_list[column] = temporary[temporary[column].str.contains(regrex, case=case, regex=True)]
            prepare_list[column]['regrex'] = regrex
            del temporary
        frames = (
            prepare_list['title'], prepare_list['content'], prepare_list['post_attach'], prepare_list['share_title'],
            prepare_list['share_content'], prepare_list['share_post_attach'], prepare_list['share_account_name'],
            prepare_list['post_ranges'], prepare_list['post_title_ranges'], prepare_list['share_account_homepage'],
            prepare_list['share_post_ranges'], prepare_list['share_post_title_ranges']
        )

        return pd.concat(frames, keys=self.timeline.columns).reset_index()

    def merge_case_site(self, objects:pd.DataFrame) -> pd.DataFrame:
        """[summary]

        Args:
            objects ([pd.DataFrame]): [location data]

        Returns:
            [pd.DataFrame]: [merge case site data]
        """

        case = '|'.join(objects[objects['ignore_case'] == 1]['re'].tolist())
        uncase = '|'.join(objects[objects['ignore_case'] == 0]['re'].tolist())

        case = self.event_extract(case).reset_index()
        if uncase:
            uncase = self.event_extract(uncase, case=True).reset_index()
            case = pd.concat([case, uncase])
        return case[['post_time', 'account', 'account_name', 'content', 'account_homepage']]

    def merge_case_event(self, objects:pd.DataFrame) -> pd.DataFrame:
        """[summary]

        Args:
            objects ([pd.DataFrame]): [event data]

        Returns:
            [pd.DataFrame]: [merge case event data]
        """
        case_group = objects.groupby(by=['category'])['re'].apply(list).reset_index()
        case_group.columns = ['category', 're']
        case_group['re'] = case_group['re'].apply(lambda x: '|'.join(x))
        return case_group

    def regular(self, types=None, obj_number=None, obj_type=None):
        print('Starting Regular...'.center(100, '*'))
        obj_con = ConnectMySQL(types=types)
        obj_con.get_cursor()
        
        obj_con.cursor.execute(
            obj_con.fetch_sql(
                ','.join(['site_regexp', 'ignore_case']),
                'site_rule',
                "df=False AND is_apply=True AND tmp='sea' AND (scope='All' OR scope='{}')".format(obj_number)
            )
        )
        sea_rule = obj_con.cursor.fetchall()

        obj_con.cursor.execute(
            obj_con.fetch_sql(
                ','.join(['site_regexp', 'ignore_case']),
                'site_rule',
                "df=False AND is_apply=True AND tmp<>'sea' AND (scope='All' OR scope='{}')".format(obj_number)
            )
        )
        land_rule = obj_con.cursor.fetchall()

        obj_con.cursor.execute(
            obj_con.fetch_sql(
                ','.join(['re_exp', 'category', 'ignore_case']),
                'event_rule',
                "df=False AND is_apply=True AND type='{}' AND (scope='All' OR scope='{}')".format(obj_type, obj_number)
            )
        )
        event_rule = obj_con.cursor.fetchall()

        sea_rule = pd.DataFrame(sea_rule, columns=['re', 'ignore_case'])
        land_rule = pd.DataFrame(land_rule, columns=['re', 'ignore_case'])
        event_rule = pd.DataFrame(event_rule, columns=['re', 'category', 'ignore_case'])
        self.land = self.merge_case_site(land_rule)
        self.sea = self.merge_case_site(sea_rule)
        case = event_rule[event_rule['ignore_case'] == 1]
        uncase = event_rule[event_rule['ignore_case'] == 0]

        event = self.merge_case_event(case)
        if len(uncase):
            event_uncase = self.merge_case_event(uncase)
            event = pd.concat([event, event_uncase])

        event_regrex = {event_name: event_regrex for event_name, event_regrex in zip(event['category'],
                                                                                     event['re'])}
        self.current_datetime = datetime.datetime.now()
        self.timestamp = str(int(time.time()))
        self.event_result = locals()

        for name, regrex in event_regrex.items():
            self.event_result[name] = self.event_extract(regrex=regrex).reset_index()[
                ['post_time', 'account', 'account_name', 'content', 'account_homepage']]

        obj_con.close_con()
        obj_con.close_cursor()

        del sea_rule, land_rule, event_rule

        self.validate(types=types, obj_number=obj_number, obj_type=obj_type)

    def validate(self, types=None, obj_number=None, obj_type=None):
        print('Starting Validate...'.center(100, '*'))
        obj_con = ConnectMySQL(types=types)
        obj_con.get_cursor()
        obj_con.cursor.execute(
            obj_con.fetch_sql(
                ','.join(obj_con.get_deployment_columns()),
                'ship_deployment',
                "df=False AND hull_number='{}'".format(obj_number)
            )
        )
        ship_deploy = pd.DataFrame(obj_con.cursor.fetchall(), columns=obj_con.get_deployment_columns())

        boat_return = ship_deploy[ship_deploy['task_id'] == 'bt_ship_task_0020']
        boat_departure = ship_deploy[ship_deploy['task_id'] == 'bt_ship_task_0021']
        boat_deploy = ship_deploy[ship_deploy['task_id'] == 'bt_ship_task_0005']

        return_start_date, get_off_end_date = time_to_list(boat_return)
        departure_start_date, set_off_end_date = time_to_list(boat_departure)
        deploy_start_date, deploy_end_date = time_to_list(boat_deploy)

        return_range_time = ext_days(return_start_date, get_off_end_date, days=2)
        departure_range_time = ext_days(departure_start_date, set_off_end_date, days=2)
        deploy_range_time = ext_days(deploy_start_date, deploy_end_date, days=2)
        land_range_time = ext_days(ship_deploy[ship_deploy['label'] == 'land']['start_time'].tolist(),
                                   ship_deploy[ship_deploy['label'] == 'land']['end_time'].tolist())
        sea_range_time = ext_days(ship_deploy[ship_deploy['label'] == 'sea']['start_time'].tolist(),
                                  ship_deploy[ship_deploy['label'] == 'sea']['end_time'].tolist())

        self.land['score'] = 0

        for date_range in land_range_time:
            date_range = pd.DataFrame(pd.date_range(date_range[0], date_range[1])).reset_index()
            date_range.columns = ['index', 'date']
            date_range = date_range['date'].astype(str).tolist()

            if not date_range:
                continue

            mark = []
            for idx, row in self.land.iterrows():
                key = '%s-%s-%s' % (row['account'], date_range[0], date_range[-1])
                if row['post_time'] in date_range:
                    if key not in mark:
                        self.land.loc[idx, 'score'] = 1
                        mark.append(key)
                    else:
                        self.land.loc[idx, 'score'] = 0
        obj_con.cursor.execute(
            obj_con.fetch_sql(
                ','.join(obj_con.get_keywords_columns()),
                'keywords',
                "df=False AND is_apply=True AND ship_hull_number='{}'".format(obj_number)
            )
        )
        feature = pd.DataFrame(obj_con.cursor.fetchall(), columns=obj_con.get_keywords_columns())
        feature_columns_case = feature[feature['ignore_case'] == 0]['words'].tolist()
        feature_columns = feature[feature['ignore_case'] == 1]['words'].tolist()

        prepare_list = locals()
        self.info.fillna('', inplace=True)
        for column in self.info.columns:
            if column == 'account':
                continue
            prepare_list[column] = self.info[~self.info[column].str.contains('retired', case=False, regex=True) &
                                        (self.info[column].str.contains('|'.join(feature_columns), case=False, regex=True) |
                                        self.info[column].str.contains('|'.join(feature_columns_case), case=True,
                                                                  regex=True))]

        friends_counts = self.friends[self.friends['account'].isin(self.info['account'].tolist())]
        friends_list = friends_counts['account'].tolist()
        friends_counts = friends_counts.groupby(by=['source_account']).size().reset_index()
        friends_counts.columns = ['account', 'friend_score']

        friends_counts['friend_score'] = friends_counts['friend_score'] * 0.5
        friends_counts['friend_score'] = friends_counts['friend_score'].apply(lambda x: 1 if x >= 1 else x)

        friends_counts.columns = ['account', 'friend_score']
        frames = [prepare_list[i] for i in self.info.columns if i != 'account']
        staff_info = pd.concat(frames, keys=self.info.columns).reset_index().astype(str)
        staff_info['staff_score'] = 1
        staff_info = staff_info[['account', 'staff_score']]
        staff_info.columns = ['account', 'staff_score']

        land_score = self.land[self.land['score'] != 0]['account'].value_counts().reset_index().astype(str)
        land_score.columns = ['account', 'land_score']

        sea_score = vector_score(sea_range_time, self.sea).astype(str)
        sea_score.columns = ['account', 'sea_score']

        person_return = vector_score(return_range_time, self.event_result['回港']).astype(str)
        person_return.columns = ['account', 'return_score']
        
        person_departure = vector_score(departure_range_time, self.event_result['离港']).astype(str)
        person_departure.columns = ['account', 'departure_score']

        person_deploy = vector_score(deploy_range_time, self.event_result['部署']).astype(str)
        person_deploy.columns = ['account', 'deploy_score']

        feature = pd.concat([
            self.event_extract(regrex='|'.join(feature_columns), case=False),
            self.event_extract(regrex='|'.join(feature_columns_case), case=True)]).astype(str)

        feature['post_time'] = feature['post_time'].apply(lambda x: str(x).split()[0])
        speech = feature.groupby(['account'])['post_time'].nunique().reset_index()

        speech.columns = ['account', 'person_score']
        speech = speech[speech['account'].isin(self.info['account'].tolist())].reset_index()

        score = pd.merge(staff_info, land_score, how='outer', on='account')
        score = pd.merge(sea_score, score, how='outer', on='account')
        score = pd.merge(person_return, score, how='outer', on='account')
        score = pd.merge(person_departure, score, how='outer', on='account')
        score = pd.merge(person_deploy, score, how='outer', on='account')
        score['account'] = score['account'].apply(int)
        score = pd.merge(friends_counts, score, how='outer', on='account')
        speech['account'] = speech['account'].apply(int)
        score = pd.merge(speech, score, how='outer', on='account')

        score.fillna(0, inplace=True)
        score['total_score'] = score[score.columns.difference(['account', 'index'])].astype(float).sum(axis=1)
        score = score[score['total_score'] >= 2]
        score = score.drop_duplicates()

        account = pd.DataFrame(self.names, columns=['account', 'obj_number', 'obj_type'])[['account']].astype(int)

        confirm_list =account[account['account'].isin(score['account'])]['account'].tolist()

        package_path = '{}/{}/{}/{}/{}/{}'.format(
            'media', 'system', 'excel', self.current_datetime.year, self.current_datetime.month, self.current_datetime.day,
            self.timestamp)

        if not os.path.exists(package_path):
            os.makedirs(package_path)

        for acc in confirm_list:
            seed = SeedBank.objects.filter(account=acc, batch=self.secret).first()
            seed.confirm = True
            seed.save()
        
        exist_seed = SeedBank.objects.filter(batch=self.secret).values_list('account', flat=True)

        post_count = Posts.objects.filter(secret=self.secret, account__in=list(exist_seed)).count()
        account_count = Account.objects.filter(secret=self.secret, account__in=list(exist_seed)).count()
        friend_count = Friends.objects.filter(secret=self.secret, account__in=list(exist_seed)).count()
        
        print('修改种子库确认名单')

        batch = SpiderLog.objects.filter(secret=self.secret).first()
        batch.tag = 4 if batch.batch == 3 else 0
        batch.seed_count = len(friends_list)

        batch.spider_log = {
            '言论': {
                '总数': post_count, 
                '召回': proportion(post_count, len(friends_list))
            },
            '好友': {
                '总数': friend_count, 
                '召回': proportion(friend_count, len(friends_list))
            },
            '好友': {
                '总数': friend_count, 
                '召回': proportion(friend_count, len(friends_list))
            }                 
        }

        batch.save()

        SeedBank.objects.bulk_create([SeedBank(account=i, object_number=obj_number, batch=batch, object_types=obj_type) for i in friends_list], ignore_conflicts=True)

        print('批量创建种子')
        score.to_excel('{}/{}_score.xlsx'.format(package_path, obj_number), header=True, index=False)

        print('Finished Validate To {}...'.format(self.timestamp).center(100, '*'))


if __name__ == '__main__':
    app = Identification(names=['100001335001140'], obj_number='CVN-71', objects_type='航母')
    app.regular()
    app.validate()

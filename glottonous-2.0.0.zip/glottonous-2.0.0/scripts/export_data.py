#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/04/20 14:46:52
# @Author      :周宇
# @Email       :zhouyu674896488@gmail.com
# @Version     :v1.0
# @File        :export_sql.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


import pymysql
import pandas as pd
import time
import datetime
import os
import zipfile
import shutil
from utils import crypto_aes 

import paramiko  # 用于调用scp命令
from scp import SCPClient

import configparser

from django.conf import settings
from application.service.resources.models import Timeline, TimelineBase, News, Official, Media
# from apps.service.analysis.models import User, Friend, Public, resouce_site, neo4j_all, minio_all, effective

conf = configparser.ConfigParser()
conf.read(os.path.join(getattr(settings, 'BASE_DIR'), 'scripts', 'conf.ini'))


def zip_compress(to_zip, save_zip_name):

    save_zip_dir=os.path.split(os.path.abspath(save_zip_name))[0]
    if not os.path.exists(save_zip_dir):
        os.makedirs(save_zip_dir)
    f = zipfile.ZipFile(os.path.abspath(save_zip_name), 'w', zipfile.ZIP_DEFLATED)
    if not os.path.isdir(os.path.abspath(to_zip)):
        if os.path.exists(os.path.abspath(to_zip)):
            f.write(to_zip)
            f.close()
            print('%s 压缩为 %s' % (to_zip, save_zip_name))
        else:
            print ('%s 文件不存在' % os.path.abspath(to_zip))
    else:
        if os.path.exists(os.path.abspath(to_zip)):
            zipList = []
            for dir,subdirs,files in os.walk(to_zip):
                for fileItem in files:
                    zipList.append(os.path.join(dir,fileItem))
                for dirItem in subdirs:
                    zipList.append(os.path.join(dir,dirItem))

            for i in zipList:
                f.write(i,i.replace(to_zip,''))
            print('%s 压缩为 %s' % (to_zip, save_zip_name))
        else:
            print('%s 文件夹不存在' % os.path.abspath(to_zip))


class EXportSQL:
    
    def __init__(self, types:str='koms.ship'):
        super().__init__()
        self.con = pymysql.connect(
            host        = conf[types]['HOST'],
            user        = conf[types]['USER'],
            password    = conf[types]['PASSWORD'],
            db          = conf[types]['NAME']
        )
        self.secret = conf['Ftp.crypto']['secret']

    def upload_data(self, file_path, remote_path="/var/ftp/pub/", exp='.enc', types:str='Ftp.server'):
        host = conf[types]['HOST']
        port = conf[types]['PORT']
        username = conf[types]['USER']
        password = conf[types]['PASSWORD']

        ssh_client = paramiko.SSHClient()
        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        ssh_client.connect(host, port, username, password, timeout=300, allow_agent=False, look_for_keys=False)
        scpclient = SCPClient(ssh_client.get_transport(), socket_timeout=15.0)
        local_path = file_path + exp
        try:
            scpclient.put(local_path, remote_path)
        except FileNotFoundError as e:
            print(e)
            print("系统找不到指定文件" + local_path)
        else:
            print("文件上传成功")

    def get_data(self, start_date, end_date):
        resouces_social = (Timeline, TimelineBase, Official) # post_time
        resouces_public = (News, Media) # pub_time

        path = os.path.join('export', 'mysqlscript', end_date)
        folder = os.path.exists(path)
        if not folder: os.makedirs(path)  

        for table in resouces_social:
            data = pd.DataFrame(table.objects.filter(post_time__range=(start_date, end_date)).values()).astype(str)   
            data.to_csv(os.path.join(path, '{}.csv'.format(table._meta.db_table)), index=None)
        
        for table in resouces_public:
            data = pd.DataFrame(table.objects.filter(pub_time__range=(start_date, end_date)).values()).astype(str)   
            data.to_csv(os.path.join(path, '{}.csv'.format(table._meta.db_table)), index=None)

        to_path = '{}.zip'.format(path)
        zip_compress(path, to_path)
        shutil.rmtree(path)

        key = crypto_aes.generate_key(self.secret)

        crypto_aes.file_encrypt(to_path, key)
        self.con.close()

        self.upload_data(file_path=to_path)


def run():

    exp = EXportSQL()
    yesterday = datetime.date.today() - datetime.timedelta(days=1)
    now = time.strftime("%Y-%m-%d %H:%M:%S",time.localtime(time.time()))
    exp.get_data(yesterday, now)



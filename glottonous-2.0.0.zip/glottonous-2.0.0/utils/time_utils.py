#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time      : 2021/8/10 16:40
# @Author    : 杜吉平
# @Email     : 18842999418@163.com
# @Version   : v1.0
# @File      : time_utils.py
# @Desc      : 

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司3
import re
import time
import datetime
from pytz import timezone
from tzlocal import get_localzone
from dateutil.parser import parse


class TimeUtils:
    timezone_utc = timezone('UTC')
    timezone_local = get_localzone()

    @staticmethod
    def time_now():
        return datetime.datetime.now()
    
    @staticmethod   
    def time_utc_now():
        return datetime.datetime.utcnow()

    @classmethod
    def time_now_by_tz(cls, src_time):
        return src_time.astimezone(cls.timezone_local)

    @staticmethod
    def time_by_utc_str(utc_str):
        if not utc_str :
            return None
        if re.match(r"\d{4}-\d{1,2}-\d{1,2}T\d{1,2}:\d{1,2}:\d{1,2}\.\d+?Z", utc_str):
            return datetime.datetime.strptime(utc_str, "%Y-%m-%dT%H:%M:%S.%fZ")
        elif re.match(r"\d{4}-\d{1,2}-\d{1,2}T\d{1,2}:\d{1,2}:\d{1,2}Z", utc_str):
            return datetime.datetime.strptime(utc_str, "%Y-%m-%dT%H:%M:%SZ")

    @staticmethod
    def format_datetime(src_time):
        if not src_time:
            return ""
        return src_time.strftime("%Y-%m-%d %H:%M:%S")

    @staticmethod
    def time_now_str():
        return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())


tu = TimeUtils()



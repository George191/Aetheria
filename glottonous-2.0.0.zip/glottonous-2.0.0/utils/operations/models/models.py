#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 10:38
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :models.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


from django.conf import settings
from django.db import models
from django.db.models import SET_NULL
from uuid import uuid4

from utils.operations.fields import CreateDateTimeField, DescriptionField, ModifierCharField, UpdateDateTimeField, SoftDeleteField


class BaseModel(models.Model):
    """
    标准抽象模型模型,可直接继承使用
    """
    description     = DescriptionField()
    update_datetime = UpdateDateTimeField()
    create_datetime = CreateDateTimeField()

    class Meta:
        abstract            = True
        verbose_name        = '基本模型'
        verbose_name_plural = verbose_name


class CoreModel(models.Model):
    """
    核心标准抽象模型模型,可直接继承使用
    增加审计字段, 覆盖字段时, 字段名称请勿修改, 必须统一审计字段名称
    """
    secret          = models.UUIDField(default=uuid4, verbose_name='唯一编号', unique=True, help_text='唯一编号')
    description     = DescriptionField()  # 描述
    creator         = models.ForeignKey(to=settings.AUTH_USER_MODEL, related_query_name='creator_query', null=True,
                                verbose_name='创建者', on_delete=SET_NULL, db_constraint=False, help_text='创建者')
    modifier        = ModifierCharField()
    dept_belong_id  = models.CharField(max_length=64, verbose_name="数据归属部门", null=True, blank=True, help_text='数据归属部门')
    update_datetime = UpdateDateTimeField()
    create_datetime = CreateDateTimeField()
    is_delete       = SoftDeleteField()

    class Meta:
        abstract            = True
        verbose_name        = '核心模型'
        verbose_name_plural = verbose_name

#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time      : 2021/8/16 14:30
# @Author    : dujiping
# @Email     : dujiping@patterntech.cn
# @Version   : v1.0
# @File      : routers.py
# @Desc      : 

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司
from neomodel import NodeSet
from rest_framework.routers import SimpleRouter, DefaultRouter


class Neo4jSimpleRouter(SimpleRouter):

    def get_default_basename(self, viewset):
        """
        If `basename` is not specified, attempt to automatically determine
        it from the viewset.
        """
        queryset = getattr(viewset, 'queryset', None)

        assert queryset is not None, '`basename` argument not specified, and could ' \
            'not automatically determine the name from the viewset, as ' \
            'it does not have a `.queryset` attribute.'

        if hasattr(queryset.model, '_meta'):
            return queryset.model._meta.object_name.lower()
        else:
            return queryset.model.lower()


class Neo4jDefaultRouter(DefaultRouter):

    def get_default_basename(self, viewset):
        """
        If `basename` is not specified, attempt to automatically determine
        it from the viewset.
        """
        queryset = getattr(viewset, 'queryset', None)

        assert queryset is not None, '`basename` argument not specified, and could ' \
            'not automatically determine the name from the viewset, as ' \
            'it does not have a `.queryset` attribute.'

        if isinstance(queryset, NodeSet):
            return queryset.source_class.Meta.app_label.lower()
        else:
            return queryset.model.lower()



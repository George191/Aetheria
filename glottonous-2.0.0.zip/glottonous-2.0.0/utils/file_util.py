#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:14
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :file_util.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


"""
封装文件操作:
  ● 递归读取所有文件目录形成列表
  ● 递归删除空目录
  ● 批量删除文件
"""
import os


def get_all_files(targetDir):
    """
    递归读取所有文件目录形成列表
    :param targetDir:
    :return:
    """
    files = []
    listFiles = os.listdir(targetDir)
    for i in range(0, len(listFiles)):
        path = os.path.join(targetDir, listFiles[i])
        if os.path.isdir(path):
            files.extend(get_all_files(path))
        elif os.path.isfile(path):
            files.append(path)
    return files


def remove_empty_dir(path):
    """
    递归删除空目录
    :param path:
    :return:
    """
    for root, dirs, files in os.walk(path, topdown=False):
        if not files and not dirs:
            os.rmdir(root)


def delete_files(delete_list: list):
    """
    批量删除文件
    :param delete_list:
    :return:
    """
    for file_path in delete_list:
        try:
            os.remove(file_path)
        except(FileNotFoundError):
            pass

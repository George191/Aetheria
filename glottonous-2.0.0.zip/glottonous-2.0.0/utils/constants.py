#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time      : 2021/8/27 15:10
# @Author    : dujiping
# @Email     : dujiping@patterntech.cn
# @Version   : v1.0
# @File      : constants.py
# @Desc      : 

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司

MAJOR_USER_MAX_COUNT = 1

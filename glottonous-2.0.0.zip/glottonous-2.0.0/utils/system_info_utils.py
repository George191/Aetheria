#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:15
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :system_info_utils.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


"""
封装系服务监控相关函数
"""
import psutil as psutil


def get_cpu_info():
    """
    获取cpu所有信息
    hyperthreading：    超线程
    normalhreading：    非超线程
    cpu_times：         用户 系统 空闲时间
    """
    cpu_times = psutil.cpu_times()
    return {
        'hyperthreading': psutil.cpu_count(), 
        'normalhreading': psutil.cpu_count(logical=False),
        'scputimes': {
            'user': cpu_times.user,
            'nice': cpu_times.nice,
            'system': cpu_times.system,
            'idle': cpu_times.idle
        }
    }


def get_memory_info():
    """
    获取内存所有信息
    """
    virtual = psutil.virtual_memory()
    swap = psutil.swap_memory()
    return {
        'svmem': {
            'total': virtual.total,
            'available': virtual.available,
            'percent': virtual.percent,
            'used': virtual.used,
            'free': virtual.free,
            'active': virtual.active,
            'inactive': virtual.inactive,
            'wired': virtual.wired
        },
        'sswap': {
            'total': swap.total,
            'used': swap.used,
            'free': swap.free,
            'percent': swap.percent,
            'sin': swap.sin,
            'sout': swap.sout,
        }
    }


def get_disk_info():
    """
    获取硬盘所有信息
    """
    disk_partitions = psutil.disk_partitions()
    disk_usage = psutil.disk_usage('/')
    disk_io_counters = psutil.disk_io_counters()

    return {
        'sdiskpart': ({
            'device': disk_partition.device,
            'mountpoint': disk_partition.mountpoint,
            'fstype': disk_partition.fstype,
            'opts': disk_partition.opts,
        } for disk_partition in disk_partitions),
        'sdiskusage': {
            'total': disk_usage.total,
            'used': disk_usage.used,
            'free': disk_usage.free,
            'percent': disk_usage.percent
        },
        'sdiskio': {
            'read_count': disk_io_counters.read_count,
            'write_count': disk_io_counters.write_count,
            'read_bytes': disk_io_counters.read_bytes,
            'write_bytes': disk_io_counters.write_bytes,
            'read_time': disk_io_counters.read_time,
            'write_time': disk_io_counters.write_time,
        }
    }


if __name__ == '__main__':
    demo = get_cpu_info()
    print(demo)

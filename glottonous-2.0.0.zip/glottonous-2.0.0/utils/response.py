#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:14
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :response.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


"""
常用的Response以及Django的Response、DRF的Response
"""
from django.http.response import DjangoJSONEncoder, JsonResponse
from rest_framework.response import Response


class OpDRFJSONEncoder(DjangoJSONEncoder):
    """
    重写DjangoJSONEncoder
    (1)默认返回支持中文格式的json字符串
    """

    def __init__(self, *, skipkeys=False, ensure_ascii=True, check_circular=True, allow_nan=True, sort_keys=False,
                 indent=None, separators=None, default=None):
        super().__init__(skipkeys=skipkeys, ensure_ascii=False, check_circular=check_circular,
                         allow_nan=allow_nan, sort_keys=sort_keys, indent=indent, separators=separators,
                         default=default)


class SuccessResponse(Response):
    """
    标准响应成功的返回, SuccessResponse(data)或者SuccessResponse(data=data)
    (1)默认错误码返回200, 不支持指定其他返回码
    """

    def __init__(self, data=None, msg='success', code=200, status=None, template_name=None, headers=None, 
                 exception=False, content_type=None):
        std_data = {
            "code": code,
            "data": data,
            "msg": msg,
            "status": 'success'
        }
        super().__init__(std_data, status, template_name, headers, exception, content_type)


class ErrorResponse(Response):
    """
    标准响应错误的返回,ErrorResponse(msg='xxx')
    (1)默认错误码返回400, 也可以指定其他返回码:ErrorResponse(code=xxx)
    """

    def __init__(self, data=None, msg='error', code=400, status=None, template_name=None, headers=None,
                 exception=False, content_type=None):
        std_data = {
            "code": code,
            "data": data,
            "msg": msg,
            "status": 'error'
        }
        super().__init__(std_data, status, template_name, headers, exception, content_type)


class ErrorJsonResponse(JsonResponse):
    """
    标准响应错误的返回,ErrorResponse(msg='xxx')
    (1)默认错误码返回400, 也可以指定其他返回码:ErrorResponse(code=xxx)
    """

    def __init__(self, data=None, msg='error', code=400, status=None):
        std_data = {
            "code": code,
            "data": data,
            "msg": msg,
            "status": 'error'
        }
        super().__init__(std_data, status)


class AuthResponse(Response):
    """
    标准响应鉴权的返回,AuthResponse(msg='xxx')
    (1)默认错误码返回401, 也可以指定其他返回码:ErrorResponse(code=xxx)
    """

    def __init__(self, data=None, msg='error', code=401, status=None, template_name=None, headers=None,
                 exception=False, content_type=None):
        std_data = {
            "code": code,
            "data": data,
            "msg": msg,
            "status": 'error'
        }
        super().__init__(std_data, status, template_name, headers, exception, content_type)


class NotFoundResponse(Response):
    """
    标准响应未找到的返回,NotFoundResponse(msg='xxx')
    (1)默认错误码返回404, 也可以指定其他返回码:ErrorResponse(code=xxx)
    """

    def __init__(self, data=None, msg='error', code=404, status=None, template_name=None, headers=None,
                 exception=False, content_type=None):
        std_data = {
            "code": code,
            "data": data,
            "msg": msg,
            "status": 'error'
        }
        super().__init__(std_data, status, template_name, headers, exception, content_type)
        
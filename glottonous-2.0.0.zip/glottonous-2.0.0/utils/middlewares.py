#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time      : 2021/8/24 17:32
# @Author    : dujiping
# @Email     : dujiping@patterntech.cn
# @Version   : v1.0
# @File      : middlewares.py
# @Desc      : 

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司

from django.utils.deprecation import MiddlewareMixin
from utils.response import ErrorJsonResponse


class ObjNumberFilter(MiddlewareMixin):

    def process_request(self, request):
        path = request.path
        prefixes = (
            '/service/analysis/',
            # '/service/military/',
            # '/service/resources/',
        )
        if not path.startswith(prefixes):
            return
        if not request.GET.get("obj_number", None):
            return ErrorJsonResponse(data="obj_number must be not None")




#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/04/22 14:58:08
# @Author      :周宇
# @Email       :zhouyu674896488@gmail.com
# @Version     :v1.0
# @File        :ASE.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司

from Crypto.Cipher import AES
from Crypto import Random
from Crypto.Protocol.KDF import PBKDF2
import os

# *** Encryption Functions ***
def encrypt(text, key, key_size=256):
    pad = lambda s: s + b"\1" * (AES.block_size - len(s) % AES.block_size)
    text = pad(text)
    initialization = Random.new().read(16)
    cipher = AES.new(key, AES.MODE_CBC, initialization)
    return initialization + cipher.encrypt(text)

def file_encrypt(file_name, key):
    with open(file_name, 'rb') as input_file:
        plaintext = input_file.read()
    encrypted_text = encrypt(plaintext, key)
    with open(file_name + '.enc', 'wb') as output_file:
        output_file.write(encrypted_text)
    os.remove(file_name)


# *** Decryption Functions ***
def decrypt(encrypted_text, key):
    initialization = encrypted_text[:AES.block_size]
    cipher = AES.new(key, AES.MODE_CBC, initialization)
    plaintext = cipher.decrypt(encrypted_text[AES.block_size:])
    return plaintext.rstrip(b"\1")

def file_decrypt(file_name, key):
    with open(file_name, 'rb') as input_file:
        encrypted_text = input_file.read()
    decrypted_text = decrypt(encrypted_text, key)
    with open(file_name[:-4], 'wb') as output_file:
        output_file.write(decrypted_text)
    # os.remove(file_name)


def generate_key(password):
    salt = b'\x83\xdb\xb9\xd3\xdc"\x1ee\x0e"\x0c\xf0=5\xab_\x18\xd7\xd2\x98\x92Q.\xbd\x9cK\x96\x93-J\x98\xe0'
    return PBKDF2(password, salt, dkLen=32)

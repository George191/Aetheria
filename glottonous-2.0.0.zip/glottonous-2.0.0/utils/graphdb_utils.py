from neo4j import Transaction
from py2neo import Graph, Node, Relationship, NodeMatcher, RelationshipMatcher
from django.conf import settings



class Pyneo4j:
    
    def __init__(self) -> None:
        self.uri = settings.NEO4J_BOLT_URL
        self.user = settings.NEO4J_ACCESS_KEY
        self.password = settings.NEO4J_SECRET_KEY
        self.database = settings.NEO4J_DATABASE
        self.__connect__()
        self.__node_matcher__()
        self.__relation_matcher__()

    def __connect__(self) -> Graph:
        try:
            self.graph = Graph(f'bolt://{self.user}:{self.password}@{self.uri}', name=self.database)
        except:
            raise ConnectionError(f'Cannot connect to IPv4Address(({self.uri}, {self.database}))')

    def __node_matcher__(self) -> NodeMatcher:
        self.node_matcher = NodeMatcher(self.graph)

    def __relation_matcher__(self) -> RelationshipMatcher:
        self.rel_matcher = RelationshipMatcher(self.graph)

    def __begin_transcation__(self) -> Transaction:
        self.tx = self.graph.begin()

    def __end_transcation__(self):
        self.graph.commit(self.tx)
        
    def __create_node__(self, node: str, *args, **kwargs) -> Node:
        return Node(node)

    def __get_node__(self, schema_name: str, secret:str=None, is_root: bool=False, *args, **kwargs) -> any:
        match_classes = self.node_matcher.match(schema_name)
        if secret:
            node = match_classes.where(secret=secret).first()
            assert node, 'The object does not exist, or does not have permission to operate'
        else:
            if is_root:
                node = match_classes.where(is_root=is_root).all()
            else:
                node = match_classes.all()
        return node

    def __get_child_node__(self, schema: str, node_id: str, rel_name: str, *args, **kwargs) -> any:
        node_match = self.node_matcher.match(schema).where(secret=node_id).first()
        return self.rel_matcher.match([node_match], r_type=rel_name).all()

    def __get_relation__(self, schema_name: str='', secret: str=None, *args, **kwargs) -> any:
        match_classes = self.rel_matcher.match(None, r_type=schema_name)
        if secret:
            relation = match_classes.where(secret=secret).first()
            assert relation, 'The object does not exist, or does not have permission to operate'
        else:
            relation = match_classes.all()
        return relation

    def __delete_node__(self, schema_name: str, secret:str, *args, **kwargs) -> Node:
        node = self.__get_node__(schema_name, secret, *args, **kwargs)
        self.graph.delete(node)
        return node

    def __create_relation__(self, entity_from: str, relation: str, entity_to: str) -> Relationship:
        return Relationship(entity_from, relation, entity_to)

    def __update_properties__(self, schema, secret, params, *args, **kwargs) -> Node or Relationship:
        node = self.__get_node__(schema, secret, *args, **kwargs)
        node.update(params)
        self.graph.push(node)
        return node

    def __update_node_schema__(self, old_name: str, new_name: str, require_properties, *args, **kwargs) -> any:
        # 循环方式具体优化
        nodes = self.__get_node__(old_name, *args, **kwargs)
        for node in nodes:
            for key in (key for key in require_properties if key not in node.keys()):
                node[key] = ''
            self.graph.push(node)
        return self.graph.run(f'MATCH (n:{old_name}) REMOVE n:{old_name} SET n:{new_name}').data()

    def __delete_node_schema__(self, instance, *args, **kwargs):
        return self.graph.run(f'match (n:{instance.name}) detach delete n').data()


    def __add_label__(self, label_name: str, node: Node, *args, **kwargs) -> Node:
        # 循环方式具体优化
        node.add_label(label_name)
        self.graph.push(node)
        return node
    
    def __update_label__(self, node_id: str, old_name: str, new_name: str, *args, **kwargs) -> any:
        return self.graph.run(f'MATCH (n:{old_name}) REMOVE n:{old_name} SET n:{new_name} WHERE n.secret={node_id}').data()

    def __delete_label__(self, name: str, node_id: str) -> any:
        return self.graph.run(f'MATCH (n:{name}) REMOVE n:{name} WHERE n.secret={node_id}').data()

    def __delete_relation__(self, schema_name: str, secret:str, *args, **kwargs) -> Node:
        relation = self.__get_relation__(schema_name, secret, *args, **kwargs)
        self.graph.delete(relation)
        return relation

    def __update_relation_schema__(self, old_name: str, new_name: str, require_properties, *args, **kwargs) -> any:
        # 循环方式具体优化
        relations = self.__get_relation__(old_name, *args, **kwargs)
        unique_properties = (key for key in require_properties if key not in rel.keys())
        for rel in relations:
            for key in unique_properties:
                rel[key] = ''
            self.graph.push(rel)
        return self.graph.run(f'MATCH (n) - [r:{old_name}] - (m) create(n)-[r2: {new_name}] - (m) set r2 = r with r delete r').data()

    def __delete_relation_schema__(self, instance, *args, **kwargs):
        return self.graph.run(f'MATCH (n) - [r: {instance.name}] - (m) DELETE r').data()

    def __get_all_nodes__(self, limit_number: int) -> list:
        return self.graph.run(f'MATCH (n) RETURN n limit {limit_number}').data()

    def __get_rel_nodes__(self, to_schema, from_schema, secret):
        # 查询一个表中某个节点与另一个表之前的所有关系，筛选条件为to表的secret
        nodes_rel = self.graph.run(
            f"MATCH p=(n:{to_schema})<-[r]-(m:{from_schema}) where n.secret='{secret}' return m, r, n".format(
                to_schema=to_schema, from_schema=from_schema, secret=secret)).data()
        return nodes_rel

    def __nodes_rel_subordinate__(self, to_schema, from_schema, secret, rel_name):
        """查询当前节点下的一层的关系node"""
        rel_data, neo_data = set(), set()
        result = self.graph.run("""
        MATCH p=(n:{})<-[r:{}]-(m:{}) where n.secret='{}'  return m, r, n
        """.format(to_schema, rel_name, from_schema, secret)).data()

        for node in result:
            rel_data.add((node['n'].get('name'), node['r'].get('name'), node['m'].get('name')))
            neo_data.add(node['m'])

        data = {"neo_data": neo_data, "rel_data": rel_data, "fields": ("_from_name", "rel_name", "_to_name")}
        return data

    def __nodes_rel_nodes__(self, nodes_name, schema_name, fields):
        """一个表中的指定节点相互之间存在的关系"""
        rel_data = set()
        for name in nodes_name:

            for compare_name in nodes_name:
                result = self.graph.run(
                    f"MATCH p=(n:{schema_name})<-[r]-(m:{schema_name}) where n.{fields}='{name}' and "
                    f"m.{fields}='{compare_name}' return m, r, n".format(
                        schema_name=schema_name, name=name, fields=fields, compare_name=compare_name)).data()

                if result:
                    rel_data.add((result[0]['n'].get('name'), result[0]['r'].get('name'), result[0]['m'].get('name')))

        data = {"rel_data": rel_data, "fields": ('_from_name', 'rel_name', '_to_name')}
        return data

    def entity_recursion(self, name, schema_name):
        """实体递归获取实体和对应关系"""
        nodes_rel = self.graph.run(
            f"MATCH p=(n:{schema_name})<-[r]-(m:{schema_name}) where n.name='{name}' return m, r, n".format(
                schema_name=schema_name, name=name)).data()
        for i in nodes_rel:
            if len(neo_data) < numbers:
                rel_data.add((i['n'].get('name'), i['r'].get('name'), i['m'].get('name')))
                neo_data.add(i['m'])
                self.entity_recursion(name=i['m'].get('name'), schema_name=schema_name)
            else:
                break

    def entity_recursion_subordinate(self, name, to_schema, from_schema):
        """实体递归获取实体下级的实体和对应关系"""
        schema_name = to_schema
        nodes_rel = self.graph.run(
            f"MATCH p=(n:{schema_name})<-[r]-(m:{schema_name}) where n.name='{name}' return m, r, n".format(
                schema_name=schema_name, name=name)).data()

        for i in nodes_rel:
            if len(neo_data) < numbers:
                subordinate_nodes_rel = self.__get_rel_nodes__(to_schema=to_schema, from_schema=from_schema,
                                                          secret=i['m']['secret'])
                for node in subordinate_nodes_rel:
                    rel_data.add((node['n'].get('name'), node['r'].get('name'), node['m'].get('name')))
                    neo_data.add(node['m'])

                self.entity_recursion_subordinate(name=i['m'].get('name'), to_schema=to_schema, from_schema=from_schema)
            else:
                break

    def __init_entity_recursion__(self, schema_name, number, secret_list):
        """
        初始化实体递归函数
        @param schema_name: 表名称
        @param number: # 抽取数量
        @return:
        """
        global neo_data, rel_data, numbers
        numbers = number

        neo_data = set()  # 实体
        rel_data = set()  # 关系
        for secret in secret_list:
            root = self.__get_node__(schema_name=schema_name, secret=secret)
            neo_data.add(root)

            self.entity_recursion(name=root.get('name'), schema_name=schema_name)
        data = {"neo_data": neo_data, "rel_data": rel_data, "fields": ("_from_name", "rel_name", "_to_name")}
        return data

    def __init_entity_recursion_subordinate__(self, to_schema, from_schema, number, secret_list):
        """
        初始化实体下级递归函数, {to_schema})<-[r]-(m:{from_schema}
        @param rel_name: 关系名
        @param to_schema: 到...表名称
        @param from_schema: 从..开始..表名称
        @param number: # 抽取数量
        @param secret: # 唯一标识
        @return:
        """
        global neo_data, rel_data, numbers
        numbers = number

        neo_data = set()  # 实体
        rel_data = set()  # 关系

        for secret in secret_list:
            root = self.__get_node__(schema_name=to_schema, secret=secret)
            self.entity_recursion_subordinate(name=root.get('name'), to_schema=to_schema, from_schema=from_schema)

        data = {"neo_data": neo_data, "rel_data": rel_data, "fields": ("_from_name", "rel_name", "_to_name")}
        return data

    def __shortest_path__(self, to_schema, from_schema, to_value, from_value):
        """
        两节点之间关系的最短路径
        @param to_schema: Organization
        @param from_schema: Ship
        @param to_value: 'secret'
        @param from_value: 'secret'
        @return: [(from_schema, rel_name, to_schema),]
        """
        rel_data = set()
        result = self.graph.run("""
            MATCH n=shortestPath((o:%s{sercet:'%s'})-[*]-(b:%s{sercet:'%s'})) return n
        """ % (to_schema, to_value, from_schema, from_value)).data()

        for res in result:
            for i in res['r']:
                rel_data.add(
                    (
                        i.start_node.get('name'), 
                        ','.join(
                            rel.get('name') for rel in i.relationships
                        ), 
                        i.end_node.get('name')
                    )
                )
        return rel_data
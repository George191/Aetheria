#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:13
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :backends.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


import logging

from django.contrib.auth import get_user_model
from django.contrib.auth.backends import ModelBackend
from django.utils import timezone
from django.conf import settings
from rest_framework.authentication import SessionAuthentication as DjangoSessionAuthentication
from system.models.logininfor import LoginInfor

from utils.requests import get_request_ip, get_os, get_browser
from utils.exceptions import GenException
import uuid
from captcha.models import CaptchaStore


logger = logging.getLogger(__name__)
UserModel = get_user_model()


class CustomBackend(ModelBackend):
    """
    Django原生认证方式
    """
    def save_login_infor(self, request, username,  msg='', status=True, session_id=''):
        instance = LoginInfor()
        instance.session_id = session_id
        instance.browser = get_browser(request)
        instance.ipaddr = get_request_ip(request)
        # instance.loginLocation = get_login_location(request)
        instance.msg = msg
        instance.os = get_os(request)
        instance.status = status
        instance.creator = request.user and UserModel.objects.filter(username=username).first()
        instance.save()

    def jarge_captcha(self, request):
        """
        校验验证码
        :param request:
        :return:
        """
        if not settings.CAPTCHA_STATE:  # 未开启验证码则返回 True
            return True
        idKeyC = request.data.get('idKeyC', None)
        idValueC = request.data.get('idValueC', None)
        if not idValueC:
            raise GenException(message='请输入验证码')
        try:
            get_captcha = CaptchaStore.objects.get(hashkey=idKeyC)
            if str(get_captcha.response).lower() == idValueC.lower():  # 如果验证码匹配
                return True
        except:
            pass
        else:
            raise GenException(message='验证码错误')

    def authenticate(self, request, username=None, password=None, **kwargs):
        
        # self.jarge_captcha(request)

        msg = '%s 正在使用本地登录...' % username
        logger.info(msg)
        if username is None:
            username = kwargs.get(UserModel.USERNAME_FIELD)
        try:
            user = UserModel._default_manager.get_by_natural_key(username)
            # user = UserModel.objects.get(Q(username=username) | Q(mobile=username) | Q(email=username))
        except UserModel.DoesNotExist:
            UserModel().set_password(password)
            self.save_login_infor(request, username, '登录失败，密码不正确！', False)
        else:
            if user.check_password(password) and self.user_can_authenticate(user):
                self.save_login_infor(request, username, '登录成功！', session_id=str(uuid.uuid4()))
                user.last_login = timezone.now()
                user.save()
                return user


class SessionAuthentication(DjangoSessionAuthentication):
    """
    Session认证
    """

    def authenticate(self, request):
        """
        Returns a `User` if the request session currently has a logged in user.
        Otherwise returns `None`.
        """
        # Get the session-based user from the underlying HttpRequest object
        user = getattr(request._request, 'user', None)
        # Unauthenticated, CSRF validation not required
        if not user or not user.is_active:
            return None
        # self.enforce_csrf(request)
        # CSRF passed with authenticated user
        return user, None

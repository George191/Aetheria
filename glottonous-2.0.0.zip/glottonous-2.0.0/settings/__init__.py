import platform
from settings.base import *

os_type = platform.system()

if os_type == 'Windows':
  from settings.dev import *
else:
  from settings.prod import *
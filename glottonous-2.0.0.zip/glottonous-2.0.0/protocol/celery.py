#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# @Time        :2021/08/11 11:12
# @Author      :周宇
# @Email       :zhouyu@patterntech.cn
# @Version     :v1.0
# @File        :celery.py
# @Desc        :

# (C)Copyright 2019-2020, 斑图信息科技（青岛）有限公司


import os

import django
from celery import Celery, platforms
from django.conf import settings

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'settings')
django.setup()

app = Celery(f'gluttonous')

app.config_from_object('django.conf:settings')
app.autodiscover_tasks(lambda: settings.INSTALLED_APPS)
platforms.C_FORCE_ROOT = True

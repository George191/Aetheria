=====
Gluttonous
=====

Gluttonous is a High-value target tracking and early warning system.

Detailed documentation is in the "docs" directory.

-----------
Directory Structure Diagram
-----------
 
+----+----------------+----------------+--------------------------------+
| ID | Main directory |  subdirectory  |           description          |
+====+================+================+================================+
| 1  |    db          |                |     - Project database         |
+----+----------------+----------------+--------------------------------+
| 2  |    docs        |                |     - project documentation    |
+----+----------------+----------------+--------------------------------+
| 3  |    media       |                |     - Media resource cache     |
+----+----------------+----------------+--------------------------------+
| 4  |    package     |                |     - Offline dependencies     |
+----+----------------+----------------+--------------------------------+
| 5  |    protocol    |                |     - Project Agreement        |
+----+----------------+----------------+--------------------------------+
| 6  |    router      |                |                                |
+----+----------------+----------------+--------------------------------+
|    |                |     urls.py    |     - Project routing          |
+----+----------------+----------------+--------------------------------+
| 7  |    schema      |                |                                |
+----+----------------+----------------+--------------------------------+
|    |                |      admin     |     - Data management          |
+----+----------------+----------------+--------------------------------+
|    |                |      core      |     - Data collection          |
+----+----------------+----------------+--------------------------------+
|    |                |    forms.py    |                                |
+----+----------------+----------------+--------------------------------+
|    |                | serializers.py |                                |
+----+----------------+----------------+--------------------------------+
|    |                |    tasks.py    |                                |
+----+----------------+----------------+--------------------------------+
|    |                |    urls.py     |                                |
+----+----------------+----------------+--------------------------------+
|    |                |    views.py    |                                |
+----+----------------+----------------+--------------------------------+
|    |    scripts     |                |                                |
+----+----------------+----------------+--------------------------------+
|    |    settings    |                |                                |
+----+----------------+----------------+--------------------------------+
|    |                |    base.py     |     - Base settings            |
+----+----------------+----------------+--------------------------------+
|    |                |    dev.py      |     - Dev settings             |
+----+----------------+----------------+--------------------------------+
|    |                |    prod.py     |     - Prod settings            |
+----+----------------+----------------+--------------------------------+
| 10 |    utils       |                |                                |
+----+----------------+----------------+--------------------------------+
| 11 |    tests       |                |                                |
+----+----------------+----------------+--------------------------------+
| 12 |    target      |                |                                |
+----+----------------+----------------+--------------------------------+

-----------
Quick start
-----------

1. Run `python -m venv .venv` to create environment variables. 

2. Run `source .venv/bin/active` to enter the virtual environment.

3. Run `pip install -r requirements.txt` to installation environment dependencies.

   a. Run `pip wheel --wheel-dir=package -r requirements.txt` to generate offline installation package (requires network)
   b. Run `python setup.py sdist` to package the project.

1. Run `python manage.py makemigrations` to generate data migration files.

2. Run `python manage.py migrate` to reverse database generation from migration files.

3. Run `python manage.py init_permission` to initialize permission data.

4. Run `python manage.py init_military_schema` to generate graph database schema

5. Start the development server and visit http://127.0.0.1:8000/api/v1/

.. 7. Visit http://127.0.0.1:8000/api/v1/ to participate in the poll.

.. 8. minio server ~/mnt/data --console-address ":9001"
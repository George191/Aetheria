import logging
import sys
from typing import List

import structlog
from aiologger import Logger
from aiologger.handlers.base import Handler
from structlog._config import BoundLoggerLazyProxy

from .adapter import BoundLoggerAdapter
from .handlers import ConsoleHandler
from .handlers import LogstashHandler
from .fields import Field

logger = logging.getLogger('aiokafka')
logger.disabled = True

PROXY_LOGGER = Logger()

structlog.configure(
    logger_factory=lambda: PROXY_LOGGER,
    wrapper_class=BoundLoggerAdapter,
    processors=[],
)


def console_handler(level: str = "DEBUG", fields: List[str] = None) -> ConsoleHandler:
    return ConsoleHandler(
        stream=sys.stdout,
        level=getattr(logging, level.upper()),
        formatter=None,
        filter=None,
        fields=fields,
    )

def logstash_handler(host: str = '127.0.0.1', port: int = '9999', level: str = "DEBUG") -> LogstashHandler:
    return LogstashHandler(host=host, port=port, level=getattr(logging, level.upper()))


def add_handler(handler: Handler) -> None:
    PROXY_LOGGER.add_handler(handler)


def get_logger(logger: BoundLoggerLazyProxy = None, **kwargs) -> Logger:
    initial_values = dict()

    if logger:
        initial_values.update(**logger._initial_values)

    initial_values.update(**kwargs)

    return structlog.get_logger(**initial_values)


PROXY_LOGGER.add_handler(console_handler(level='debug',fields=[Field.levelname, Field.timestamp, Field.event, 'include']))

logger = get_logger()